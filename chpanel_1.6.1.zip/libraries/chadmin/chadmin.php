<?php
/**
 * @package		CHAdmin
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

// load lang files
CHLib::loadLanguage('lib_chadminb', __DIR__);

// Autoload library classes
JLoader::discover('CHAdmin', __DIR__);

/**
 * CHAdmin Helper
 */
class CHAdmin
{

	/**
	 * get app
	 */
	public static function getApp()
	{
		$app = JFactory::getApplication();

		// init app
		if (!isset($app->chadmin))
		{
			$app->chadmin = (object) [];
		}

		return $app;
	}

	/**
	 * text
	 */
	public static function text($string)
	{
		return JText::_("LIB_CHADMIN_" . strtoupper($string));
	}

}
