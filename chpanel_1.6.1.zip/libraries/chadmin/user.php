<?php
/**
 * @package		CHAdmin
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * CHAdmin User Helper
 */
class CHAdminUser
{

	/**
	 * Get
	 */
	public static function get()
	{
		// load app  
		$app = CHAdmin::getApp();

		// check if the user has already been loaded
		if (isset($app->chadmin->user))
		{
			return $app->chadmin->user;
		}

		// load joomla user
		$juser = JFactory::getUser();

		// check joomla user
		if ($juser->guest)
		{
			$app->chadmin->user = false;
			return false;
		}

		// load chadmin user
		$user = CHLibDatabase::loadObjectFrom('chadmin_users', $juser->id, 'joomla_id');

		// check chadmin user
		if (!$user || $user->status != 1)
		{
			$app->chadmin->user = false;
			return false;
		}

		// complete user details
		$user->email = $juser->email;
		$user->timezone = $juser->getParam('timezone');
		$user->data = json_decode($user->data);

		// set chadmin user
		$app->chadmin->user = $user;

		return $user;
	}

}
