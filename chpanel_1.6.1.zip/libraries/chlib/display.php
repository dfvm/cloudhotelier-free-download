<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Display Helper
 */
class CHLibDisplay
{

	static private $countries = [];
	static private $languages = [];
	static private $currencies = [];

	/**
	 * Truncate long strings
	 * 
	 * @param string $string
	 * @param int $limit
	 * @param string $break
	 * @param string $pad
	 * 
	 * @return string
	 */
	static function truncate($string, $limit = 100, $break = ' ', $pad = '...')
	{
		if (strlen($string) <= $limit)
		{
			return $string;
		}
		if (false !== ($breakpoint = strpos($string, $break, $limit)))
		{
			if ($breakpoint < strlen($string) - 1)
			{
				$string = substr($string, 0, $breakpoint) . $pad;
			}
		}
		return $string;
	}

	/**
	 * Display an amount in locale format
	 * 
	 * @param float $amount
	 * @param string $currency
	 * @param string $placeholder
	 * @param string $lang
	 * 
	 * @return string
	 */
	static function money($amount, $currency = '', $placeholder = '', $lang = false)
	{
		$format = self::currencyFormat($currency);
		preg_match('/{(.*)}/', $format, $format_parts);
		$amount_format = $format_parts[1];
		$amount_display = $placeholder ? '<span ' . $placeholder . '>' . self::amount($amount, $amount_format) . '</span>' : self::amount($amount, $amount_format);
		return str_replace('code', $currency, str_replace('symbol', self::currencySymbol($currency), preg_replace('/\{[^)]+\}/', $amount_display, $format)));
	}

	/**
	 * Number format an amount
	 * 
	 * @param float $amount
	 * @param string $format
	 * @return string
	 */
	static function amount($amount, $format = 'amount|2|.|,')
	{
		$format_parts = explode('|', $format);
		return number_format($amount, $format_parts[1], $format_parts[2], $format_parts[3]);
	}

	/**
	 * Get the display format for a specific currency
	 */
	static function currencyFormat($currency)
	{
		$formats = [
			'BGN' => '{amount|2|,| } symbol',
			'BRL' => 'symbol {amount|2|,|.}',
			'BYR' => ' {amount|0|,| } symbol',
			'CZK' => '{amount|2|,| } symbol',
			'DKK' => 'symbol{amount|2|,|.}',
			'EUR' => self::currencyFormatsEuro($currency),
			'GBP' => 'symbol{amount|2|.|,}',
			'HRK' => '{amount|2|,|.} symbol',
			'IDR' => 'symbol{amount|0|,|.}',
			'ILS' => '{amount|2|.|,} symbol',
			'IQD' => '{amount|2|/|,} symbol',
			'IRR' => '{amount|2|/|,} symbol',
			'HUF' => '{amount|2|,| } symbol',
			'JPY' => 'symbol{amount|0|.|,}',
			'KRW' => 'symbol{amount|0|.|,}',
			'MXN' => 'symbol{amount|2|.|,} code',
			'NOK' => 'symbol {amount|2|,| }',
			'PLN' => '{amount|2|,| } symbol',
			'RON' => '{amount|2|,|.} symbol',
			'RSD' => '{amount|2|,|.} symbol',
			'RUB' => '{amount|2|,| }symbol',
			'SEK' => '{amount|2|,|.} symbol',
			'THB' => 'symbol{amount|2|.|,} ',
			'TRY' => '{amount|2|,|.} symbol',
			'UAH' => '{amount|2|,| }symbol',
			'USD' => 'symbol{amount|2|.|,}',
			'VND' => '{amount|0|,|.} symbol',
			'ZAR' => 'symbol {amount|2|.|,}',
		];

		return isset($formats[$currency]) ? $formats[$currency] : 'symbol{amount|2|.|} code';
	}

	/**
	 * Get the display format for euros in different locales
	 */
	static function currencyFormatsEuro()
	{
		$language_formats = [
			'fr-CA' => '{amount|2|,| } symbol',
			'fr-FR' => '{amount|2|,| } symbol',
			'fi-FI' => '{amount|2|,| } symbol',
			'ga-IE' => 'symbol{amount|2|.|,}',
			'it-IT' => 'symbol {amount|2|,|.}',
			'nl-NL' => 'symbol {amount|2|,|.}',
			'et-EE' => '{amount|2|,| } symbol',
		];
		$lang = CHLib::lang();
		return isset($language_formats[$lang]) ? $language_formats[$lang] : '{amount|2|,|.} symbol';
	}

	/**
	 * Convert a currency ISO code to display symbol
	 * 
	 * @param type $currency
	 * @param type $sign
	 * 
	 * @return type
	 */
	static function currencySymbol($currency, $sign = true)
	{
		if (!$sign)
		{
			return $currency;
		}
		$signs = (array(
			'AED' => 'د.إ',
			'ARS' => '$',
			'AUD' => '$',
			'BGN' => 'лв',
			'BOB' => '$b',
			'BRL' => 'R$',
			'CAD' => '$',
			'CHF' => 'CHF',
			'CLP' => '$',
			'CNY' => '¥',
			'COP' => '$',
			'CZK' => 'Kč',
			'DKK' => 'kr',
			'EEK' => 'kr',
			'EGP' => '£',
			'EUR' => '€',
			'GBP' => '£',
			'HKD' => '$',
			'HRK' => 'kn',
			'HUF' => 'Ft',
			'IDR' => 'Rp',
			'ILS' => '₪',
			'INR' => '₨',
			'JPY' => '¥',
			'KRW' => '₩',
			'LTL' => 'Lt',
			'MAD' => 'د.م.',
			'MXN' => '$',
			'MYR' => 'RM',
			'NOK' => 'kr',
			'NZD' => '$',
			'PEN' => 'S/.',
			'PHP' => '₱',
			'PKR' => '₨',
			'PLN' => 'zł',
			'RON' => 'lei',
			'RSD' => 'Дин.',
			'RUB' => 'руб',
			'SAR' => '﷼',
			'SEK' => 'kr',
			'SGD' => '$',
			'SKK' => 'Sk',
			'THB' => '฿',
			'TRY' => 'TL',
			'TWD' => 'NT$',
			'UAH' => '₴',
			'USD' => '$',
			'VEF' => 'Bs',
			'VND' => '₫',
			'ZAR' => 'R'
		));

		return isset($signs[$currency]) ? $signs[$currency] : '';
	}

	/**
	 * Display a number in locale format
	 * 
	 * @param float $number
	 * @param mixed $lc
	 * 
	 * @return string
	 */
	static function number($number)
	{
		return number_format($number, 2, CHLib::cleanDebugString(CHLib::string('NUMBER_DECIMAL')), CHLib::cleanDebugString(CHLib::string('NUMBER_THOUSANDS')));
	}

	/**
	 * Convert markdown to html
	 * 
	 * @param type $markdown
	 * @return type
	 */
	static function convertMarkdownToHtml($markdown)
	{
		require_once __DIR__ . '/vendor/parsedown/Parsedown.php';
		return Parsedown::instance()->setBreaksEnabled(true)->text($markdown);
	}

	/**
	 * Convert html to plain text
	 * 
	 * @param type $html
	 * @return type
	 */
	static function convertHtmlToText($html)
	{
		require_once __DIR__ . '/vendor/html2text/Html2Text.php';
		$Html2Text = new \Html2Text\Html2Text($html, array('width' => 0));
		return $Html2Text->getText();
	}

	/**
	 * Countries array
	 * 
	 * @return array
	 */
	static function countries()
	{
		if (self::$countries)
		{
			return self::$countries;
		}

		self::$countries = self::loadJsonList('countries');

		return self::$countries;
	}

	/**
	 * Return the country name
	 */
	static function country($code)
	{
		$countries = self::countries();
		return isset($countries[$code]) ? $countries[$code] : '-';
	}

	/**
	 * Countries array
	 * 
	 * @return array
	 */
	static function languages()
	{
		if (self::$languages)
		{
			return self::$languages;
		}

		self::$languages = self::loadJsonList('languages');

		return self::$languages;
	}

	/**
	 * Return the language name
	 */
	static function language($code)
	{
		$languages = self::languages();
		return isset($languages[$code]) ? $languages[$code] : '-';
	}

	/**
	 * Countries array
	 * 
	 * @return array
	 */
	static function currencies()
	{
		if (self::$currencies)
		{
			return self::$currencies;
		}

		self::$currencies = self::loadJsonList('currencies');

		return self::$currencies;
	}

	/**
	 * Datepicker locale
	 */
	static function datePickerLocale()
	{
		$locale = (object) [];
		$locale->months = [
			JText::_('JANUARY'),
			JText::_('FEBRUARY'),
			JText::_('MARCH'),
			JText::_('APRIL'),
			JText::_('MAY'),
			JText::_('JUNE'),
			JText::_('JULY'),
			JText::_('AUGUST'),
			JText::_('SEPTEMBER'),
			JText::_('OCTOBER'),
			JText::_('NOVEMBER'),
			JText::_('DECEMBER')
		];
		$locale->weekdays = [
			JText::_('SUN'),
			JText::_('MON'),
			JText::_('TUE'),
			JText::_('WED'),
			JText::_('THU'),
			JText::_('FRI'),
			JText::_('SAT')
		];
		return $locale;
	}

	static function loadJsonList($file)
	{
		$lang = CHLib::lang();
		$path0 = __DIR__ . "/language/en-GB/en-GB.lib_chlib.$file.json";
		$path1 = __DIR__ . "/language/$lang/$lang.lib_chlib.$file.json";
		$path2 = JPATH_BASE . "/language/$lang/$lang.lib_chlib.$file.json";
		$path = file_exists($path2) ? $path2 : (file_exists($path1) ? $path1 : $path0);
		return (array) json_decode(file_get_contents($path));
	}

}
