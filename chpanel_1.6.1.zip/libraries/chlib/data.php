<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

// load Joomla Registry
use Joomla\Registry\Registry;

/**
 * Data Helper
 */
class CHLibData
{

	/**
	 * Search an object from a list and return it
	 * 
	 * @param array $list object list
	 * @param string $search value to match
	 * @param string $key object key to match, default is name
	 * 
	 * @return mixed
	 */
	static function loadObject($list, $search, $key = 'id')
	{
		if(!$list){
			return false;
		}
		
		foreach ($list as $item)
		{
			if (isset($item->$key) && $item->$key == $search)
			{
				return $item;
			}
		}

		return false;
	}

	/**
	 * Search an object from a list and return it
	 * 
	 * @param array $list object list
	 * @param string $search value to match
	 * @param string $key object key to match, default is name
	 * 
	 * @deprecated since version 
	 * 
	 * @return mixed
	 */
	static function loadObjectFromList($list, $search, $key = 'name')
	{
		return self::loadObject($list, $search, $key);
	}

	/**
	 * Extract a property array from object list
	 * 
	 * @param array $list object list
	 * @param string $key object key to match, default is id
	 * 
	 * @return mixed
	 */
	static function loadColumn($list, $key = 'id')
	{
		$array = [];

		foreach ($list as $item)
		{
			if (isset($item->$key))
			{
				$array[] = $item->$key;
			}
		}

		return $array;
	}

	/**
	 * Search an object from a associative list and return it
	 * 
	 * @param type $list
	 * @param type $key
	 * @param type $return_if_not_found
	 * @return type
	 */
	static function objectFromAssociativeList($list, $key, $return_if_not_found = null)
	{
		return isset($list[$key]) ? $list[$key] : $return_if_not_found;
	}

	/**
	 * load Value From Object Property
	 * 
	 * @param type $object
	 * @param type $key
	 * @param type $return_if_not_found
	 */
	static function valueFromProperty($object, $key, $return_if_not_found = 0)
	{
		return isset($object->$key) ? $object->$key : $return_if_not_found;
	}

	/**
	 * listMultiply
	 * 
	 * @param array $list
	 * @param float $value
	 * @return array
	 */
	static function listMultiply($list, $value)
	{
		$return = [];
		foreach ($list as $item)
		{
			$return[] = $item * $value;
		}
		return $return;
	}

	/**
	 * listSum
	 * 
	 * @param array $list
	 * @param float $value
	 * @return array
	 */
	static function listSum($list, $value)
	{
		$return = [];
		foreach ($list as $item)
		{
			$return[] = $item + $value;
		}
		return $return;
	}

	/**
	 * Decode Json data form items
	 * 
	 * @param array $items
	 * 
	 * @return array
	 */
	static function decodeItems($items, $field = 'data')
	{
		if (!$items)
		{
			return [];
		}
		foreach ($items as $item)
		{
			$item->$field = json_decode($item->$field);
		}
		return $items;
	}

	/**
	 * Load a json file data
	 * 
	 * @param string $path
	 * @param bool $exit exit if errors
	 * 
	 * @return mixed
	 */
	static function readJsonFile($path, $exit = false)
	{

		if (!file_exists($path))
		{
			if ($exit)
			{
				jexit('Error: json not found at: ' . $path);
			}
			return false;
		}

		$json = json_decode(file_get_contents($path));
		if (!$json)
		{
			if ($exit)
			{
				jexit('Error: check json at: ' . $path);
			}
			return false;
		}

		return $json;
	}

	/**
	 * readYamlFile
	 * 
	 * @param string $path
	 * @param bool $exit exit if errors
	 * 
	 * @return mixed
	 */
	static function readYamlFile($path, $exit = false)
	{
		if (!file_exists($path))
		{
			if ($exit)
			{
				jexit('Error: yaml not found at: ' . $path);
			}
			return false;
		}

		$registry = new Registry;
		$yaml = $registry->loadFile($path, 'yaml');
		if (!$yaml)
		{
			if ($exit)
			{
				jexit('Error: check yaml at: ' . $path);
			}
			return false;
		}

		return $yaml;
	}

}
