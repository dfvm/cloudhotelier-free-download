<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * System Helper
 */
class CHLibSystem
{

	/**
	 * Get info of an installed extension
	 * 
	 * @param string $component
	 * @return object
	 */
	public static function getComponentInfo($component)
	{
		try
		{
			$name = substr($component, 4);
			$xml_path = JPATH_ADMINISTRATOR . "/components/$component/$name.xml";
			$xml_obj = new SimpleXMLElement(file_get_contents($xml_path));
		}
		catch (Exception $e)
		{
			return false;
		}

		return json_decode(json_encode($xml_obj));
	}

	/**
	 * Get version of an installed extension
	 * 
	 * @param string $component
	 * @return string
	 */
	public static function getComponentVersion($component)
	{
		$info = self::getComponentInfo($component);
		return ($info && isset($info->version)) ? $info->version : false;
	}

}
