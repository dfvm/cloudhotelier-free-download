<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Input Get
 */
class CHLibInputGet
{

	/**
	 * Magic method
	 * 
	 * @param type $name
	 * @param type $arguments
	 * @return type
	 */
	static function __callStatic($name, $arguments)
	{
		return JFactory::getApplication()->input->get->get($arguments[0], (isset($arguments[1]) ? $arguments[1] : null), $name);
	}

}
