<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Email Helper
 */
class CHLibEmail
{

	/**
	 * renderEmail
	 * 
	 * @param string $subject
	 * @param string $body
	 * @param string $template
	 * @param string $path
	 * @param array $colors
	 * @return string
	 */
	static function renderEmail($subject, $body, $template, $path, $colors = ['primary' => '#2199e8', 'secondary' => '#777777', 'background' => '#f2f2f2'])
	{
		$layout_html = new JLayoutFile($template, $path);
		$html = $layout_html->render(['subject' => $subject, 'body' => $body]);
		return self::prepareEmail($html, $colors);
	}

	/**
	 * prepareEmail
	 * 
	 * @param string $html
	 * @param array $colors
	 * @return string
	 */
	static function prepareEmail($html, $colors = ['primary' => '#2199e8', 'secondary' => '#777777', 'background' => '#f2f2f2'])
	{
		return self::inlineCSS(self::replaceColors(self::tableProperties($html), $colors));
	}

	/**
	 * replaceColors
	 * 
	 * @param string $html
	 * @param array $colors
	 * @return string
	 */
	static function replaceColors($html, $colors = ['primary' => '#2199e8', 'secondary' => '#777777', 'background' => '#f2f2f2'])
	{
		if (isset($colors['primary']))
		{
			$html = str_replace('#2199e8', $colors['primary'], $html);
			$html = str_replace('#147dc2', self::adjustColorBrightness($colors['primary'], -20), $html);
		}
		if (isset($colors['secondary']))
		{
			$html = str_replace('#777777', $colors['secondary'], $html);
		}
		if (isset($colors['background']))
		{
			$html = str_replace('#f2f2f2', $colors['background'], $html);
		}
		return $html;
	}

	/**
	 * tableProperties
	 * 
	 * @param string $html
	 * @return string
	 */
	static function tableProperties($html)
	{
		return str_replace('<table', '<table align="center" cellpadding="0" cellspacing="0" border="0"', $html);
	}

	/**
	 * sendEmail
	 * 
	 * @param mixed $emails
	 * @param string $subject
	 * @param string $body
	 * @param mixed $options
	 */
	static function sendEmail($emails, $subject, $body, $options = false)
	{
		// check form mail plugins
		JPluginHelper::importPlugin('system');
		$dispatcher = JDispatcher::getInstance();
		$response = $dispatcher->trigger('onCHLibSendEmail', [$emails, $subject, $body, $options]);
		if ($response && $response[0] === true)
		{
			return $response[0];
		}

		// prepare joomla stardard mailer
		$config = JFactory::getConfig();
		$mailer = JFactory::getMailer();

		// mail content
		$mailer->IsHTML(isset($options->html) ? $options->html : true);
		$mailer->Encoding = 'base64';
		$mailer->setSubject($subject);
		$mailer->setBody($body);

		// send emails
		$error = false;
		$recipients = is_array($emails) ? array_unique($emails) : [$emails];
		foreach ($recipients as $recipient)
		{
			if ($recipient)
			{
				// set emails
				$mailer->ClearAddresses();
				$mailer->addRecipient($recipient);

				// set sender
				if (isset($options->from))
				{
					$mailer->From($options->from);
				}

				// form name
				$mailer->FromName = $config->get('fromname', $config->get('sitename'));
				if (isset($options->from_name))
				{
					$mailer->FromName = $options->from_name;
				}

				// add cc copy
				if (isset($options->cc))
				{
					$mailer->addCc($options->cc);
				}

				// add blind copy
				if (isset($options->bcc))
				{
					$mailer->addBcc($options->bcc);
				}

				// set reply
				if (isset($options->reply))
				{
					if (!is_array($options->reply))
					{
						$mailer->addReplyTo($options->reply);
					}
					else
					{
						$mailer->addReplyTo($options->reply[0], $options->reply[1]);
					}
				}

				// try to send email
				try
				{
					$mailer->Send();
				}
				catch (Exception $e)
				{
					CHLib::log(json_encode(['CHLibEmail - send fail', $e, $emails, $subject, $options], JSON_PRETTY_PRINT), 'warning', 'lib_chlib');
					$error = true;
				}
			}
		}

		return $error ? false : true;
	}

	/**
	 * Inline CSS style
	 * 
	 * @param string $html
	 * @param string $css
	 * @return string
	 */
	static function inlineCSS($html, $css = null)
	{
		require_once __DIR__ . '/vendor/emogrifier/Emogrifier.php';
		$emogrifier = new \Pelago\Emogrifier($html, $css);
		return $emogrifier->emogrify();
	}

	/**
	 * 
	 * @param type $hex
	 * @param type $steps
	 * @return type
	 */
	static function adjustColorBrightness($hex, $steps)
	{
		// Steps should be between -255 and 255. Negative = darker, positive = lighter
		$steps = max(-255, min(255, $steps));

		// Normalize into a six character long hex string
		$hex = str_replace('#', '', $hex);
		if (strlen($hex) == 3)
		{
			$hex = str_repeat(substr($hex, 0, 1), 2) . str_repeat(substr($hex, 1, 1), 2) . str_repeat(substr($hex, 2, 1), 2);
		}

		// Split into three parts: R, G and B
		$color_parts = str_split($hex, 2);
		$return = '#';

		foreach ($color_parts as $color)
		{
			$color = hexdec($color); // Convert to decimal
			$color = max(0, min(255, $color + $steps)); // Adjust color
			$return .= str_pad(dechex($color), 2, '0', STR_PAD_LEFT); // Make two char hex code
		}

		return $return;
	}

}
