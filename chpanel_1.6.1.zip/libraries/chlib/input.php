<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Input Helper (similar to old JRequest)
 */
class CHLibInput
{

	/**
	 * Sets a value
	 * 
	 * @param string $name
	 * @param mixed $value
	 * @return void
	 */
	static function set($name, $value)
	{
		return JFactory::getApplication()->input->set($name, $value);
	}

	/**
	 * Magic
	 * 
	 * @param string $name
	 * @param array $arguments
	 * @return mixed
	 */
	static function __callStatic($name, $arguments)
	{
		return JFactory::getApplication()->input->get($arguments[0], (isset($arguments[1]) ? isset($arguments[1]) : null), $name);
	}

}
