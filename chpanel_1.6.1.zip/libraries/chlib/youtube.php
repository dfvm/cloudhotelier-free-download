<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Youtube Helper
 */
class CHLibYoutube
{

	/**
	 * idFromUrl
	 * 
	 * @param string $url
	 */
	static function idFromUrl($url)
	{
		parse_str(parse_url($url, PHP_URL_QUERY), $video_url);
		return isset($video_url['v']) ? $video_url['v'] : false;
	}

}
