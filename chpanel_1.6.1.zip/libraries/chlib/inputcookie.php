<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Input Cookie
 */
class CHLibInputCookie
{

	/**
	 * Magic method
	 * 
	 * @param type $name
	 * @param type $arguments
	 * @return type
	 */
	static function __callStatic($name, $arguments)
	{
		if (!isset($_COOKIE[$arguments[0]]))
		{
			return isset($arguments[1]) ? $arguments[1] : null;
		}
		return JFactory::getApplication()->input->cookie->get($arguments[0], (isset($arguments[1]) ? $arguments[1] : null), $name);
	}

}
