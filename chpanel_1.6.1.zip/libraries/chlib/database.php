<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Database Helper
 */
class CHLibDatabase
{

	/**
	 * Execute query
	 * @param string $query
	 * 
	 * @return mixed
	 */
	static function execute($query)
	{
		return JFactory::getDbo()->setQuery($query)->execute();
	}

	/**
	 * Perform JDatabase loadObject
	 * 
	 * @param array $select
	 * @param string $table
	 * @param string $search
	 * @param mixed $value
	 * 
	 * @return object
	 */
	static function loadObjectList($select, $table, $search, $value)
	{
		$query = self::buildQuery($select, $table, $search, $value);
		return JFactory::getDbo()->setQuery($query)->loadObjectList();
	}

	/**
	 * Perform JDatabase loadObject, less vars
	 * 
	 * @param string $table
	 * @param mixed $value
	 * @param string $search
	 * @param array $select
	 * 
	 * @return object
	 */
	static function loadObjectListFrom($table, $value, $search = 'id', $select = ['*'])
	{
		return self::loadObjectList($select, $table, $search, $value);
	}

	/**
	 * Perform JDatabase loadObject
	 * 
	 * @param array $select
	 * @param string $table
	 * @param string $search
	 * @param mixed $value
	 * 
	 * @return object
	 */
	static function loadObject($select, $table, $search, $value)
	{
		$query = self::buildQuery($select, $table, $search, $value);
		return JFactory::getDbo()->setQuery($query)->loadObject();
	}

	/**
	 * Perform JDatabase loadObject, less vars
	 * 
	 * @param string $table
	 * @param mixed $value
	 * @param string $search
	 * @param array $select
	 * 
	 * @return object
	 */
	static function loadObjectFrom($table, $value, $search = 'id', $select = ['*'])
	{
		return self::loadObject($select, $table, $search, $value);
	}

	/**
	 * Perform JDatabase loadColumn
	 * 
	 * @param string $select
	 * @param string $table
	 * @param string $search
	 * @param mixed $value
	 * 
	 * @return mixed
	 */
	static function loadColumn($select, $table, $search, $value)
	{
		$query = self::buildQuery($select, $table, $search, $value);
		return JFactory::getDbo()->setQuery($query)->loadColumn();
	}

	/**
	 * Perform JDatabase loadResult
	 * 
	 * @param string $select
	 * @param string $table
	 * @param string $search
	 * @param mixed $value
	 * 
	 * @return mixed
	 */
	static function loadResult($select, $table, $search, $value)
	{
		$query = self::buildQuery($select, $table, $search, $value);
		return JFactory::getDbo()->setQuery($query)->loadResult();
	}

	/**
	 * updateObject shortcut
	 * 
	 * @param string $table
	 * @param object $object
	 * @param string $key
	 * 
	 * @return mixed
	 */
	static function insertObject($table, $object, $key = null)
	{
		return JFactory::getDbo()->insertObject('#__' . $table, $object, $key);
	}

	/**
	 * Get the latest inset Id
	 */
	static function insertid()
	{
		return JFactory::getDbo()->insertid();
	}

	/**
	 * updateObject shortcut
	 * 
	 * @param string $table
	 * @param object $object
	 * @param string $key
	 * 
	 * @return mixed
	 */
	static function updateObject($table, $object, $key = 'id')
	{
		$update = is_array($object) ? (object) $object : $object;
		return JFactory::getDbo()->updateObject('#__' . $table, $update, $key);
	}

	/**
	 * build Query
	 * 
	 * @param mixed $select
	 * @param string $table
	 * @param string $search
	 * @param mixed $value
	 * 
	 * @return string
	 */
	static function buildQuery($select, $table, $search, $value)
	{
		$qtable = JFactory::getDbo()->qn("#__$table");
		if (is_array($select))
		{
			$select_fields = [];
			foreach ($select as $select_field)
			{
				$select_fields[] = $select_field == '*' ? '*' : JFactory::getDbo()->qn($select_field);
			}
			$qselect = implode(', ', $select_fields);
		}
		else
		{
			$qselect = JFactory::getDbo()->qn($select);
		}
		$qsearch = JFactory::getDbo()->qn($search);
		if (is_array($value))
		{
			$qvalues = implode(',', array_map([JFactory::getDbo(), 'quote'], $value));
			$q = "$qsearch IN( $qvalues)";
		}
		else
		{
			$qvalue = JFactory::getDbo()->q($value);
			$q = "$qsearch = $qvalue";
		}
		return "SELECT $qselect FROM $qtable WHERE $q";
	}

	/**
	 * Delete records
	 * 
	 * @param string $table
	 * @param string $search WHERE $search = $value
	 * @param mixed $value WHERE $search = $value
	 */
	static function delete($table, $search, $value)
	{
		$qtable = JFactory::getDbo()->qn("#__$table");
		$qsearch = JFactory::getDbo()->qn($search);
		$qvalue = JFactory::getDbo()->q($value);
		return JFactory::getDbo()->setQuery("DELETE FROM $qtable WHERE $qsearch = $qvalue")->query();
	}

	/**
	 * Delete records
	 * 
	 * @param string $table
	 * @param string $search
	 * @param mixed $values
	 */
	static function deleteIn($table, $search, $values)
	{
		$qtable = JFactory::getDbo()->qn("#__$table");
		$qsearch = JFactory::getDbo()->qn($search);
		$qvalues = implode(',', array_map([JFactory::getDbo(), 'quote'], $values));
		return JFactory::getDbo()->setQuery("DELETE FROM $qtable WHERE $qsearch IN (" . $qvalues . ")")->query();
	}

	/**
	 * insertRows
	 * @param string $table
	 * @param array $fields
	 * @param array $rows
	 */
	static function insertRows($table, $fields, $rows)
	{
		$qtable = JFactory::getDbo()->qn("#__$table");
		$qfields = implode(',', array_map([JFactory::getDbo(), 'quoteName'], $fields));
		$qrows = [];
		foreach ($rows as $row)
		{
			$qrows[] = implode(',', array_map([JFactory::getDbo(), 'quote'], $row));
		}
		$qvalues = '(' . implode('),(', $qrows) . ')';
		self::execute("INSERT INTO $qtable ($qfields) VALUES $qvalues");
	}

	/**
	 * deleteRows
	 * @param string $table
	 * @param array $fields
	 * @param array $rows
	 */
	static function deleteRows($table, $fields, $rows)
	{
		$qtable = JFactory::getDbo()->qn("#__$table");
		foreach ($fields as $i => $field)
		{
			$qrows = implode(',', array_map([JFactory::getDbo(), 'quote'], $rows[$i]));
			$conditions[] = JFactory::getDbo()->qn($field) . " IN (" . $qrows . ")";
		}
		$qwhere = implode(' AND ', $conditions);
		return self::execute("DELETE FROM $qtable WHERE $qwhere");
	}

	/**
	 * Repair and optimize a table
	 */
	static function checkTable($table, $level = 1)
	{
		$db = JFactory::getDbo();

		// check table
		$db->setQuery("CHECK TABLE `#__$table`;")->execute();

		// reapir table
		if ($level < 2)
		{
			return;
		}
		$db->setQuery("REPAIR TABLE `#__$table`;")->execute();

		// analize table
		if ($level < 3)
		{
			return;
		}
		$db->setQuery("ANALYZE TABLE `#__$table`;")->execute();

		// optimize table
		if ($level < 4)
		{
			return;
		}
		$db->setQuery("OPTIMIZE TABLE `#__$table`;")->execute();
	}

}
