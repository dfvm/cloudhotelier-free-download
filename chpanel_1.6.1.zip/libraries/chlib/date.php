<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Date Helper
 */
class CHLibDate
{

	/**
	 * Return a JDate object, prevent errors
	 * 
	 * @param string $date_string
	 * 
	 * @return object
	 */
	static function getDate($time = 'now', $default = '0000-00-00')
	{
		try
		{
			$date = new JDate(str_replace('.', '-', str_replace('/', '-', $time)));
		}
		catch (Exception $e)
		{
			$date = new JDate($default);
		}

		return $date;
	}

	/**
	 * 
	 * @param string $date_string
	 * @param mixed $time
	 * @param mixed $timezone
	 * @param bool $timezone_display
	 * 
	 * @return string
	 */
	static function dateToLocale($date_string, $time = false, $timezone = false, $timezone_display = false)
	{
		if (!$date_string)
		{
			return '';
		}

		$date = self::getDate($date_string);
		if ($timezone)
		{
			$date->setTimezone(new DateTimeZone($timezone));
		}

		$time_format = is_string($time) ? $time : self::timeLocale();

		return $date->format(self::dateLocale() . ($time ? " $time_format" : ''), ($timezone ? true : false)) . ($timezone_display ? " ($timezone)" : '');
	}

	/**
	 * Date to locale format
	 * 
	 * @param string $date_string
	 * @param bool $week_day
	 * 
	 * @return string
	 */
	static function dateToDisplay($date_string, $week_day = false)
	{
		if (!$date_string)
		{
			return '';
		}
		$locale = $week_day ? 'LIB_CHLIB_DATE_DISPLAY_WEEKDAY' : 'LIB_CHLIB_DATE_DISPLAY';
		return self::getDate($date_string)->format(CHLib::cleanDebugString(JText::_($locale)));
	}

	/**
	 * Date to locale week day format
	 * 
	 * @param string $date_string
	 * 
	 * @return string
	 */
	static function dateWeekDay($date_string)
	{
		if (!$date_string)
		{
			return '';
		}
		return self::getDate($date_string)->format('w');
	}

	/**
	 * Return locale format (avoid errors on lang debug)
	 * 
	 * @return string
	 */
	static function dateLocale()
	{
		// get date format
		$format = trim(str_replace('*', '', JText::_('LIB_CHLIB_DATE')));

		// check format
		if (in_array($format, [
				'Y-m-d',
				'Y/m/d',
				'Y.m.d',
				'Y m d',
				'd-m-Y',
				'd/m/Y',
				'd.m.Y',
				'd m Y',
				'm-d-Y',
				'm/d/Y',
				'm.d.Y',
				'm d Y',
				]
			))
		{
			return $format;
		}

		return 'd-m-Y';
	}

	/**
	 * Return locale format (avoid errors on lang debug)
	 * 
	 * @return string
	 */
	static function timeLocale()
	{
		// get date format
		$format = trim(str_replace('*', '', JText::_('LIB_CHLIB_TIME')));

		// check format
		if (in_array($format, [
				'H:i',
				'h:i A',
				'h.i A',
				]
			))
		{
			return $format;
		}

		return 'H:i';
	}

	/**
	 * Date to sql format
	 * 
	 * @param string $date_string
	 * @param bool $force_date
	 * 
	 * @return string
	 */
	static function dateToSql($date_string = 'now', $force_date = true)
	{
		if (!$date_string)
		{
			if ($force_date)
			{
				return self::getDate()->format('Y-m-d');
			}
			return '';
		}
		return self::getDate($date_string)->format('Y-m-d');
	}

	/**
	 * Convert a sql date to int for easy compare
	 * 
	 * @param type $date_string
	 */
	static function sqlToInt($date_string)
	{
		return (int) str_replace(':', '', str_replace(' ', '', (str_replace('-', '', $date_string))));
	}

	/**
	 * Check if a date is between a period
	 * 
	 * @param string $start
	 * @param string $end
	 * @param string $date
	 */
	static function inPeriod($start, $end, $date)
	{
		$int_start = self::sqlToInt($start);
		$int_end = self::sqlToInt($end);
		$int_date = self::sqlToInt($date);
		return ($int_start <= $int_date && $int_date <= $int_end);
	}

	/**
	 * Check if a date is between a period
	 * 
	 * @param string $date1
	 * @param string $date2
	 */
	static function isGreater($date1, $date2)
	{
		return self::sqlToInt($date1) > self::sqlToInt($date2);
	}

	/**
	 * Check if a date is between a period
	 * 
	 * @param string $date1
	 * @param string $date2
	 */
	static function isLess($date1, $date2)
	{
		return self::sqlToInt($date1) < self::sqlToInt($date2);
	}

	/**
	 * Get the dates between two given dates
	 * 
	 * @param string $start
	 * @param string $end
	 * @param mixed $weekdays - default false
	 * @param string $include_last - default true
	 * 
	 * @return array
	 */
	public static function datesInPeriod($start, $end, $weekdays = false, $include_last = true)
	{
		if (!$weekdays)
		{
			$weekdays = [0, 1, 2, 3, 4, 5, 6];
		}

		// using new php 5.3 methods to avoid problems with strtotime
		$dates = [];
		$period = new DatePeriod(new DateTime($start), new DateInterval('P1D'), new DateTime($end));
		foreach ($period as $date)
		{
			if (in_array($date->format('w'), $weekdays))
			{
				$dates[] = $date->format('Y-m-d');
			}
		}

		// include also end date
		if ($include_last)
		{
			if (in_array(self::getDate($end)->format('w'), $weekdays))
			{
				$dates[] = $end;
			}
		}
		return $dates;
	}

	/**
	 * Day number between two dates
	 * 
	 * @param string $end
	 * @param string $start
	 * @return int
	 */
	public static function daysDifference($end, $start)
	{
		return (int) ceil((CHLibDate::getDate($end)->toUnix() - CHLibDate::getDate()->toUnix($start)) / 86400);
	}

	/**
	 * Modify Date
	 * 
	 * @param mixed $date
	 * @param string $modify
	 * @return string
	 */
	public static function modifyDate($date = 'now', $modify = '')
	{
		$mdate = self::getDate($date);
		$mdate->modify($modify);
		return $mdate->format('Y-m-d');
	}

	/**
	 * Add to a date
	 * 
	 * @param mixed $date
	 * @param string $add
	 * @return string
	 */
	public static function addToDate($date, $add)
	{
		return self::modifyDate($date, $add);
	}

	/**
	 * Get the stay dates
	 * 
	 * @param type $start
	 * @param type $end
	 */
	public static function stayDates($start, $end)
	{
		return self::datesInPeriod($start, $end, false, false);
	}

	/**
	 * Return weekstart day (avoid errors on lang debug)
	 * 
	 * @return string
	 */
	static function weekStart()
	{
		// get date format
		return (int) trim(str_replace('*', '', JText::_('LIB_CHLIB_WEEKSTART')));
	}

	static function weekDay($date)
	{
		return self::getDate($date)->format('w');
	}

	/**
	 * Get the month object
	 * 
	 * @param type $month_value
	 * 
	 * @return type
	 */
	public static function getMonth($month_value)
	{

		// @todo check month
		$mdate = self::getDate($month_value . '-01');

		// month
		$month = (object) [];
		$month->value = $mdate->format('Y-m');
		$month->start = $mdate->format('Y-m-d');
		$days = $mdate->format('t');
		$month->end = substr($month->start, 0, -2) . $days;
		$month->days = $days;

		// load dates 
		$dates = self::datesInPeriod($month->start, $month->end);

		// build month dates
		$dw = $mdate->format('w');
		$month->dates = [];
		foreach ($dates as $date)
		{
			$day_week = $dw;
			if ($dw == 7)
			{
				$dw = 0;
				$day_week = $dw;
			}
			$dw++;
			$day = new stdClass();
			$day->date = $date;
			$day->day = (int) substr($date, -2, 2);
			$day->day_week = $day_week;
			$month->dates[] = $day;
		}

		return $month;
	}

	/**
	 * Get a month list from current date
	 * 
	 * @return type
	 */
	public static function getMonthsList($n = 20)
	{
		// get months list
		$months = [];
		for ($i = 0; $i <= $n; $i++)
		{
			$date = date('Y-m-d', mktime(0, 0, 0, date("m") + $i, 1, date("Y")));
			$month = CHLibDate::getDate($date);
			$months[$i] = (object) ['value' => $month->format('Y-m'), 'text' => $month->format('F') . ' ' . $month->format('Y')];
		}

		return $months;
	}

	/**
	 * Return time ago string
	 * 
	 * @param mixed $datetime
	 * @param int $min_days
	 * @param bool $week_day
	 * 
	 * @return string
	 */
	static function timeAgo($datetime = 'now', $min_days = 999, $week_day = false)
	{
		$now = JFactory::getDate();
		$ago = JFactory::getDate($datetime);
		$diff = date_diff($now, $ago);

		// return date string
		if ($diff->days > $min_days)
		{
			return self::dateToDisplay($datetime, $week_day);
		}

		$periods = [
			'y' => 'year',
			'm' => 'month',
			'd' => 'day',
			'h' => 'hour',
			'i' => 'minute',
			's' => 'second'
		];

		foreach ($periods as $p => $string)
		{
			if ($diff->$p > 0)
			{
				return CHLib::sprintf('ago', CHLib::numstring($diff->$p, $string));
			}
		}

		return CHLib::string('now');
	}

}
