<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Input Get
 */
class CHLibInputPost
{

	/**
	 * Magic method
	 * 
	 * @param type $name
	 * @param type $arguments
	 * @return type
	 */
	static function __callStatic($name, $arguments)
	{
		return JFactory::getApplication()->input->post->get($arguments[0], (isset($arguments[1]) ? $arguments[1] : null), $name);
	}

	/**
	 * Retrieve email
	 */
	static function email($name, $default = '')
	{
		return filter_var(JFactory::getApplication()->input->post->getString($name, $default), FILTER_VALIDATE_EMAIL);
	}

	/**
	 * Retrieve alias
	 */
	static function alias($name, $default = '')
	{
		return JApplicationHelper::stringURLSafe(JFactory::getApplication()->input->post->get($name, $default, 'raw'));
	}

	/**
	 * Retrieve html
	 */
	static function html($name, $default = '')
	{
		require_once 'vendor/HTMLPurifier/HTMLPurifier.auto.php';
		$config = HTMLPurifier_Config::createDefault();
		$purifier = new HTMLPurifier($config);
		return $purifier->purify(JFactory::getApplication()->input->post->get($name, $default, 'raw'));
	}

	/**
	 * Get an unsigned integer or zero if negative
	 * 
	 * @param type $name
	 * @param type $default
	 * @return type
	 */
	static function intOrZero($name, $default = 0)
	{
		$int = JFactory::getApplication()->input->post->getInt($name, $default);
		return $int < 0 ? 0 : $int;
	}

	/**
	 * Get an unsigned integer or zero if negative
	 * 
	 * @param type $name
	 * @param type $default
	 * @return type
	 */
	static function floatOrZero($name, $default = 0)
	{
		$float = JFactory::getApplication()->input->post->getFloat($name, $default);
		return $float < 0 ? 0 : $float;
	}

}
