<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Ajax Helper
 */
class CHLibAjax
{

	/**
	 * Return error object
	 * 
	 * @param type $message
	 * @param type $data
	 * @return type
	 */
	static function dangerObject($message = 'error', $data = null)
	{
		return (object) ['status' => 'danger', 'message' => $message, 'data' => $data];
	}

	/**
	 * Return success object
	 * 
	 * @param string $message
	 * @param mixed $data
	 * @return object
	 */
	static function successObject($message = 'ok', $data = null)
	{
		return (object) ['status' => 'success', 'message' => $message, 'data' => $data];
	}

	/**
	 * Close connection to browser and redirect to a new page 
	 * Useful to run lenghty processess in the background, like sending email
	 */
	static function closeConnectionRedirect($redirect)
	{
		// init
		self::closeConnectionInit();

		// reset session
		JFactory::getApplication()->getSession()->close();

		// start ob
		ob_start();

		// redirect
		header('Location: ' . $redirect);

		// finish
		self::closeConnectionFinish();
	}

	/**
	 * Close connection to browser with a json output 
	 * Useful to run lenghty processess in the background, like sending email
	 */
	static function closeConnectionJSON($output)
	{
		// init
		self::closeConnectionInit();

		// json content-type header
		header("Content-Type: application/json");

		// start ob
		ob_start();

		// print json
		echo is_string($output) ? $output : json_encode($output);

		// finish
		self::closeConnectionFinish();
	}

	/**
	 * Common close connection init block
	 */
	static function closeConnectionInit()
	{
		// ignore the user's abort
		ignore_user_abort(true);

		// avoid problems with gzip
		@apache_setenv('no-gzip', 1);
		@ini_set('zlib.output_compression', 0);

		// raise time limit
		set_time_limit(0);

		// headers
		header("Connection: close");
		header("Content-Encoding: none");
	}

	/**
	 * Common close connection end block
	 */
	static function closeConnectionFinish()
	{
		// get the ob size, add an extra header
		$size = ob_get_length();
		header("Content-Length: $size", true);

		// send the output buffer and turn output buffering off
		ob_end_flush();
		ob_flush();
		flush();
	}

}
