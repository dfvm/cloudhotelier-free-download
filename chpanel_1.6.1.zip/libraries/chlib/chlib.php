<?php
/**
 * @package		CHLib
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

// load lang files
JFactory::getLanguage()->load('lib_chlib', JPATH_BASE . '/libraries/chlib');
JFactory::getLanguage()->load('lib_chlib', JPATH_BASE, null, true);
//
// Autoload library classes
JLoader::discover('CHLib', __DIR__);

/**
 * CHLib Helper
 */
class CHLib
{

	/**
	 * JRoute shortcut
	 * 
	 * @param string $url the url to route
	 * @param bool $xhtml replace & by &amp;
	 * @param bool $full full or relative url
	 */
	static function route($url, $xhtml = true, $full = false)
	{
		// ssl is a #facepalm JRoute param with 3 possible options 1 for full ssl url, -1 for non full ssl url, and null for a relative url
		// this is a simplified approach that only has 2 possibilities, full url or not.
		$ssl = $full ? (JFactory::getURI()->isSSL() ? 1 : -1) : null;
		return JRoute::_($url, $xhtml, $ssl);
	}

	/**
	 * Get lang shortcut
	 * 
	 * @return string
	 */
	static function lang($long = true)
	{
		return $long ? JFactory::getLanguage()->getTag() : substr(JFactory::getLanguage()->getTag(), 0, 2);
	}

	/**
	 * Load a extension language strings
	 * 
	 * @param string $extension
	 * @param string $fallback_path
	 */
	static function loadLanguage($extension, $fallback_path)
	{
		JFactory::getLanguage()->load($extension, JPATH_ROOT . $fallback_path); // load the component file first
		JFactory::getLanguage()->load($extension, JPATH_BASE, null, true); // override strings with the translation if found
	}

	/**
	 * Jinput shortcut
	 * 
	 * @return object
	 */
	static function input()
	{
		return JFactory::getApplication()->input;
	}

	/**
	 * Html response to a ajax request
	 */
	static function rawExit($html)
	{
		header('HTTP/1.1 200 OK');
		echo $html;
		jexit();
	}

	/**
	 * Ajax exit the app with json output
	 * 
	 * @param object $resp response in body
	 * @param int $status header code
	 * @param bool $pretty pretty json
	 */
	static function ajaxExit($resp, $status = 200, $pretty = true)
	{
		// status list
		$status_headers = [
			200 => 'HTTP/1.1 200 OK',
			400 => 'HTTP/1.1 400 Bad Request',
			403 => 'HTTP/1.1 403 Forbidden',
			404 => 'HTTP/1.1 404 Not Found',
			500 => 'HTTP/1.1 500 Internal Server Error',
		];

		// status header
		if (isset($status_headers[$status]))
		{
			header($status_headers[$status]);
		}

		// json header
		header('Content-Type: application/json');

		// pretty response
		if ($pretty)
		{
			jexit(json_encode($resp, JSON_PRETTY_PRINT));
		}

		// plain response
		jexit(json_encode($resp));
	}

	/**
	 * Generate a random string
	 * 
	 * @return string
	 */
	static function random($length = 32)
	{
		return JUserHelper::genRandomPassword($length);
	}

	/**
	 * get user IP address
	 */
	static function getIp()
	{
		return getenv('HTTP_CLIENT_IP')? :
			getenv('HTTP_X_FORWARDED_FOR')? :
				getenv('HTTP_X_FORWARDED')? :
					getenv('HTTP_FORWARDED_FOR')? :
						getenv('HTTP_FORWARDED')? :
							getenv('REMOTE_ADDR');
	}

	/**
	 * dumpItem
	 * 
	 * @param object $item
	 */
	static function dumpItem($item)
	{
		echo '<pre>';
		echo json_encode($item, JSON_PRETTY_PRINT);
		echo '</pre>';
	}

	/**
	 * Add a log entry
	 * 
	 * @param mixed $entry
	 * @param mixed $priority
	 * @param string $category
	 */
	public static function log($entry, $priority = 'info', $category = '')
	{
		// load JLog
		jimport('joomla.log.log');

		// determine priority
		$priorities = [
			'EMERGENCY' => JLog::EMERGENCY,
			'ALERT' => JLog::ALERT,
			'CRITICAL' => JLog::CRITICAL,
			'ERROR' => JLog::ERROR,
			'WARNING' => JLog::WARNING,
			'NOTICE' => JLog::NOTICE,
			'INFO' => JLog::INFO,
			'DEBUG' => JLog::DEBUG
		];
		$log_priority = in_array(strtoupper($priority), $priorities) ? $priorities[strtoupper($priority)] : JLog::INFO;

		// add logger
		if ($category)
		{
			JLog::addLogger(array('text_file' => $category . '.errors.php'), JLog::ALL, [$category]);
		}

		// add the entry
		JLog::add($entry, $log_priority, $category);
	}

	/**
	 * Normal string
	 */
	static function string($string)
	{
		return JText::_('LIB_CHLIB_' . strtoupper($string));
	}

	/**
	 * Sprintf string
	 */
	static function sprintf()
	{
		$args = func_get_args();
		$args[0] = strtoupper('LIB_CHLIB_' . $args[0]);
		return call_user_func_array(array('JText', "sprintf"), $args);
	}

	/**
	 * Num string
	 * 
	 * @param int $n
	 * @param string $string
	 * @return string
	 */
	static function numstring($n, $string)
	{
		return (int) $n == 1 ? self::string($string . '_1') : self::sprintf($string . '_n', $n);
	}

	/**
	 * Transform a undersocre string to camel case
	 * (Take a variable name converted to a method name)
	 * 
	 * @param type $string
	 * @return type
	 */
	static function underToCamel($string)
	{
		return lcfirst(str_replace(' ', '', ucwords(str_replace('_', ' ', $string))));
	}

	/**
	 * cleanDebugString
	 * 
	 * @param string $string
	 * @return string
	 */
	static function cleanDebugString($string)
	{
		return trim(str_replace('*', '', $string));
	}

}
