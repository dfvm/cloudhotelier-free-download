<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Update ARI
 */
class CHApiAriUpdate extends CHApiAri
{

	private $dates_count;
	private $hotel_rooms_ids;
	private $hotel_rates_ids;
	private $rates_ids;
	private $existing_ari;
	private $existing_ari_rates;
	private $rack_rates;

	/**
	 * Get the response
	 * 
	 * @return object
	 */
	protected function getResponse()
	{
		// check request
		if (!$this->checkRequest())
		{
			return false;
		}

		// execute the update
		return $this->executeUpdate();
	}

	/**
	 * Execute update
	 */
	private function executeUpdate()
	{
		// update ari
		$this->loadInitData();
		$this->saveAri();
		$this->saveAriRates();

		return true;
	}

	/**
	 * Load existing ari data and prepare it to be retrieved
	 * Better performance by using keys instead of looping the full array each time
	 */
	private function loadInitData()
	{
		// build existing_ari using integer date as key
		$this->existing_ari = [];
		$ari = $this->loadAri($this->rooms_ids, $this->dates);
		foreach ($ari as $row)
		{
			$this->existing_ari[(int) $row->room_id][(int) CHLibDate::sqlToInt($row->date)] = $row;
		}

		// build existing_ari_rates using integer date as key
		$this->existing_ari_rates = [];
		$ari_rates = $this->loadAriRates($this->rooms_ids, $this->dates, $this->rates_ids);
		foreach ($ari_rates as $row)
		{
			$this->existing_ari_rates[(int) $row->room_id][(int) $row->rate_id][(int) CHLibDate::sqlToInt($row->date)] = $row;
		}

		$this->rack_rates = [];
		foreach ($this->hotel->rooms as $room)
		{
			$this->rack_rates[$room->id] = $room->rack_rate;
		}
	}

	/**
	 * Save ari
	 */
	private function saveAri()
	{
		$inserts = [];
		$delete_rooms_ids = [];
		foreach ($this->request->rooms as $room)
		{
			// an update is needed?
			$update_room = isset($room->available_units) || isset($room->master_rate);

			// prepare inserts
			foreach ($this->dates as $i => $date)
			{
				// get the existing value for the room in the current date
				$existing = $this->existingAri($room->id, $date);

				// if the value exists and no update needed, nothing to do
				if ($existing && !$update_room)
				{
					continue;
				}

				// fill the inserts with the update values or default values if needed
				$units = isset($room->available_units) ? $room->available_units[$i] : ($existing ? $existing->units : 0);
				$rate = isset($room->master_rate) ? $room->master_rate[$i] : ($existing ? $existing->rate : $this->getRoomRackRate($room->id));
				$inserts[] = [$room->id, $date, $units, $rate];

				// add the room id to the deletion array
				$delete_rooms_ids[] = $room->id;
			}
		}

		// nothing to do
		if (!$inserts)
		{
			return;
		}

		// delete and insert new rows
		CHLibDatabase::deleteRows('chpanel_ari', ['room_id', 'date'], [array_unique($delete_rooms_ids), $this->dates]);
		CHLibDatabase::insertRows('chpanel_ari', ['room_id', 'date', 'units', 'rate'], $inserts);

		return;
	}

	/**
	 * Save ari rates
	 */
	private function saveAriRates()
	{
		$inserts = [];
		$delete_rooms_rates_ids = [];
		foreach ($this->request->rooms as $room)
		{
			// build room rates array
			$rates = $this->builSaveAriRates($room);

			// delete rooms ids
			$delete_rooms_rates_ids[$room->id] = [];

			foreach ($rates as $rate)
			{
				// delete rates ids
				$delete_rooms_rates_ids[$room->id][] = $rate->id;

				// prepare inserts
				foreach ($this->dates as $i => $date)
				{
					$existing = $this->existingAriRates($room->id, $rate->id, $date);

					// default values will be provided when saving new data
					$available = isset($rate->available) ? ($rate->available[$i] ? 1 : 0) : ($existing ? $existing->available : 1);
					$minstay = isset($rate->minstay) ? $rate->minstay[$i] : ($existing ? $existing->minstay : 1);
					$anticipation = isset($rate->anticipation) ? $rate->anticipation[$i] : ($existing ? $existing->anticipation : 0);
					$inserts[] = [$room->id, $rate->id, $date, $available, $minstay, $anticipation];
				}
			}
		}

		// nothing to do
		if (!$inserts)
		{
			return;
		}

		// delete existing rows
		foreach ($delete_rooms_rates_ids as $room_id => $rates_ids)
		{
			CHLibDatabase::deleteRows(
				'chpanel_ari_rates'
				, ['room_id', 'rate_id', 'date']
				, [[$room_id], array_unique($rates_ids), $this->dates]
			);
		}

		// insert new rows
		CHLibDatabase::insertRows(
			'chpanel_ari_rates'
			, ['room_id', 'rate_id', 'date', 'available', 'minstay', 'anticipation']
			, $inserts
		);

		return;
	}

	/**
	 * builSaveAriRates
	 */
	private function builSaveAriRates($room)
	{
		$save_rates = [];

		foreach ($this->hotel->rates as $rate)
		{
			// check rate room
			if ($rate->id != 1 && !in_array($room->id, $rate->rooms))
			{
				continue;
			}

			// add the rate
			if (isset($room->rates))
			{
				foreach ($room->rates as $room_rate)
				{
					if ($rate->id == $room_rate->id)
					{
						$save_rates[] = $room_rate;
					}
				}
			}
		}

		return $save_rates;
	}

	/**
	 * Check the request
	 */
	private function checkRequest()
	{
		// check hotel and dates
		if (!$this->checkHotelAndDates(true))
		{
			return false;
		}

		// check rooms
		$this->dates_count = count($this->dates);
		if (!$this->checkRooms())
		{
			$this->errors[] = (object) ['code' => 'ARIGET_INCORRECT_ROOMS'];
			return false;
		}

		return true;
	}

	/**
	 * Check the request rooms
	 */
	private function checkRooms()
	{
		// check rooms array
		if (!$this->request->rooms || !is_array($this->request->rooms))
		{
			return false;
		}

		// load hotel rooms and rates ids
		$this->hotel_rooms_ids = CHLibData::loadColumn($this->hotel->rooms);
		$this->hotel_rates_ids = CHLibData::loadColumn($this->hotel->rates);
		if (!$this->hotel_rooms_ids)
		{
			return false;
		}

		// check rooms and build rooms_ids array
		$this->rooms_ids = [];
		foreach ($this->request->rooms as $room)
		{
			// check room
			if (!$this->checkRoom($room))
			{
				$this->warnings[] = (object) ['code' => "ARIGET_ROOM_{$room->id}_FAIL"];
				return false;
			}
		}

		return true;
	}

	/**
	 * Check room properties
	 * 
	 * @param object $room
	 * @return boolean
	 */
	private function checkRoom($room)
	{
		// check room belongs to hotel
		if (!isset($room->id) || !in_array($room->id, $this->hotel_rooms_ids))
		{
			return false;
		}

		// check properties
		$properties = [];
		foreach (['available_units', 'master_rate'] as $property)
		{
			if (isset($room->$property))
			{
				if (!$this->checkPropertiesArray($room->$property))
				{
					$this->warnings[] = (object) ['code' => "ARIGET_ROOM_{$room->id}_INCORRECT_" . strtoupper($property)];
					return false;
				}
				$properties[] = $property;
			}
		}


		// check room rates propeties
		if (isset($room->rates))
		{
			foreach ($room->rates as $rate)
			{
				if (!$this->checkRoomRate($rate))
				{
					return false;
				}
			}
			$properties[] = 'rates';
		}

		// the room should have properties
		if (!$properties)
		{
			return false;
		}

		// build rooms_ids
		$this->rooms_ids[] = $room->id;

		return true;
	}

	/**
	 * Check a room rate
	 * 
	 * @param object $rate
	 * @return boolean	 
	 */
	private function checkRoomRate($rate)
	{
		// check the rate belongs to hotel
		if (!isset($rate->id) || !in_array($rate->id, $this->hotel_rates_ids))
		{
			return false;
		}

		// check properties
		$properties = [];
		foreach (['available', 'minstay', 'anticipation'] as $property)
		{
			if (isset($rate->$property))
			{
				if (!$this->checkPropertiesArray($rate->$property))
				{
					$this->warnings[] = (object) ['code' => "ARIGET_RATE_{$rate->id}_INCORRECT_" . strtoupper($property)];
					return false;
				}
				$properties[] = $property;
			}
		}

		// the rate should have properties
		if (!$properties)
		{
			return false;
		}

		// build rooms_ids
		$this->rates_ids[] = $rate->id;

		return true;
	}

	/**
	 * Check properties array
	 * 
	 * @param mixed $array
	 * @return boolean
	 */
	private function checkPropertiesArray($array)
	{
		if (!is_array($array) || count($array) != $this->dates_count)
		{
			return false;
		}

		return true;
	}

	/**
	 * Get existing Ari
	 * 
	 * @param object $room_id
	 * @param string $date
	 * @return mixed
	 */
	private function existingAri($room_id, $date)
	{
		// return item if present, no need to loop again
		return
			isset($this->existing_ari[(int) $room_id][(int) CHLibDate::sqlToInt($date)]) ?
			$this->existing_ari[(int) $room_id][(int) CHLibDate::sqlToInt($date)] :
			false;
	}

	/**
	 * Get existing Ari
	 * 
	 * @param int $room_id
	 * @param int $rate_id
	 * @param string $date
	 * @return mixed
	 */
	private function existingAriRates($room_id, $rate_id, $date)
	{
		// return item if present, no need to loop again
		return
			isset($this->existing_ari_rates[(int) $room_id][(int) $rate_id][(int) CHLibDate::sqlToInt($date)]) ?
			$this->existing_ari_rates[(int) $room_id][(int) $rate_id][(int) CHLibDate::sqlToInt($date)] :
			false;
	}

	/**
	 * Get a room master rate
	 */
	private function getRoomRackRate($room_id)
	{
		return isset($this->rack_rates[$room_id]) ? $this->rack_rates[$room_id] : 0;
	}

}
