<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Search Results
 */
class CHApiSearch extends CHApiBase
{

	private $dates;
	private $booking_date;
	private $nights;
	private $anticipation;
	private $messages;
	private $hotels;
	private $hotels_data;
	private $rooms_data;
	private $rates_data;
	private $discounts_data;
	private $extras_data;
	private $ari;
	private $ari_rates;
	private $unit;
	private $guests;
	private $hotel;
	private $currency_conversion;
	private $hotel_data;
	private $room;
	private $room_party;
	private $room_data;
	private $single;

	/**
	 * Load the response
	 * 
	 * @return object
	 */
	protected function getResponse()
	{
		// check request
		if (!$this->checkRequest())
		{
			return false;
		}

		// return response object
		return (object) [
				'search_date' => $this->booking_date,
				'dates' => $this->dates,
				'nights' => $this->nights,
				'anticipation' => $this->anticipation,
				'available_hotels' => $this->loadAvailableHotels(),
				'messages' => $this->messages,
				'month_ari' => $this->attachMonthAri(),
				'inventory' => $this->attachInventory(),
		];
	}

	/**
	 * Check the request data
	 */
	protected function checkRequest()
	{
		// get the booking dates
		$this->dates = CHLibDate::stayDates($this->request->start_date, $this->request->end_date);
		if (!$this->dates)
		{
			$this->errors[] = (object) ['code' => 'SEARCH_INVALID_REQUEST_DATES'];
			return false;
		}

		// check check-in date is not in the past
		$this->booking_date = CHLibDate::dateToSql(false);
		if (CHlibDate::isLess($this->request->start_date, $this->booking_date))
		{
			$this->errors[] = (object) ['code' => 'SEARCH_CHECKIN_IN_PAST'];
			return false;
		}

		// load the hotels data
		$this->hotels = $this->loadInventory($this->request->hotels_ids);
		if (!$this->hotels)
		{
			$this->errors[] = (object) ['code' => 'SEARCH_INVALID_REQUEST_HOTELS'];
			return false;
		}

		// calculate nights, anticipation
		$this->nights = count($this->dates);
		$this->anticipation = CHLibDate::daysDifference($this->request->start_date, CHLibDate::getDate()->format('Y-m-d'));

		// month_ari & inventory
		$this->request->month_ari = isset($this->request->month_ari) ? $this->request->month_ari : 1;
		$this->request->inventory = isset($this->request->inventory) ? $this->request->inventory : 1;

		// init messages 
		$this->messages = (object) ['hotel' => [], 'unit' => [], 'room' => []];

		return true;
	}

	/**
	 * load the hotels of the response
	 */
	private function loadAvailableHotels()
	{
		// load base data 
		$this->loadBaseData();

		// init results
		$available_hotels = [];
		foreach ($this->hotels as $hotel)
		{
			// assign to global for later use
			$this->hotel = $hotel;
			$this->currency_conversion = $this->currencyConversion($hotel->currency, $this->request->currency);

			// init hotel, checks come later
			$available_hotel = (object) [
					'id' => $hotel->id,
					'reference' => $hotel->reference,
					'currency' => $hotel->currency,
					'currency_conversion' => $this->currency_conversion,
					'age_adult' => $hotel->age_adult,
					'age_child' => $hotel->age_child,
					'age_boards_adult' => $hotel->age_boards_adult,
			];

			// load boards
			$available_hotel->boards = $this->loadHotelBoards();

			// load search units
			$available_hotel->search_units = $this->loadSearchUnits($available_hotel);

			// check units
			if (!$available_hotel->search_units || count($available_hotel->search_units) != count($this->request->party))
			{
				$this->loadMessagesHotel();
				continue;
			}

			// check units in multiple room request
			if (count($this->request->party) > 1)
			{
				if (!$this->checkMultipleUnits($available_hotel->search_units))
				{
					continue;
				}
			}

			// add the hotel to the available_hotels list
			$available_hotels[] = $available_hotel;
		}

		return $available_hotels;
	}

	/**
	 * Load base data
	 */
	private function loadBaseData()
	{
		// get the ids
		$ids = ['hotels' => [], 'rooms' => [], 'rates' => [], 'discounts' => [], 'extras' => []];
		foreach ($this->hotels as $hotel)
		{
			$ids['hotels'][] = $hotel->id;
			foreach ($ids as $item => $item_ids)
			{
				if ($item == 'hotels')
				{
					continue;
				}
				$ids[$item] = array_merge($ids[$item], CHLibData::loadColumn($hotel->{$item}));
			}
		}

		// load the data
		$this->hotels_data = $this->getItemsData('hotels', $ids['hotels']);
		$this->rooms_data = $this->getItemsData('rooms', $ids['rooms']);
		$this->rates_data = $this->getItemsData('rates', $ids['rates']);
		$this->discounts_data = $this->getItemsData('discounts', $ids['discounts']);
		$this->extras_data = $this->getItemsData('extras', $ids['extras']);

		// load ari and ari_rates
		$this->ari = $this->loadAri($ids['rooms'], $this->dates);
		$this->ari_rates = $this->loadAriRates($ids['rooms'], $this->dates);
	}

	/**
	 * Load the available boards for a hotel
	 */
	private function loadHotelBoards()
	{
		// init data
		$hotel_data = $this->loadFromData('hotels', $this->hotel->id);
		if (!$hotel_data)
		{
			return (object) [];
		}

		// asign hotel_data to global var for later user
		$this->hotel_data = $hotel_data;

		// the boards array
		$boards_array = ['ro', 'bb', 'hb', 'fb', 'ai'];

		// build the available boards base
		$base_boards = (object) [];
		foreach ($boards_array as $board)
		{
			if ($hotel_data->{"board_$board"})
			{
				$base_boards->$board = (object) [
						'adult' => array_fill(0, $this->nights, (float) CHLibData::valueFromProperty($hotel_data, "adult_$board", 0)),
						'child' => array_fill(0, $this->nights, (float) CHLibData::valueFromProperty($hotel_data, "child_$board", 0))
				];
			}
		}

		// check periods overrides
		$periods = CHLibData::loadObjectFromList($hotel_data->periods, 'boards')->rows;
		if (!$periods)
		{
			// check that available boards where found
			if (!get_object_vars($base_boards))
			{
				$this->addError('warnings', 'SEARCH_BOARDS_NOT_FOUND_BASE', 'hotel', $hotel->id);
			}
			return $base_boards;
		}

		// build the overrides arrays
		$available_boards = (object) [];
		$rates_adult = (object) [];
		$rates_child = (object) [];
		foreach ($boards_array as $board)
		{
			// default values
			$default_board = $hotel_data->{"board_$board"};
			$default_adult = (float) CHLibData::valueFromProperty($hotel_data, "adult_$board", 0);
			$default_child = (float) CHLibData::valueFromProperty($hotel_data, "child_$board", 0);

			// board arrays
			$available_boards->$board = $this->loadPeriodsStayValues("board_$board", $periods, $default_board);
			$rates_adult->$board = $this->loadPeriodsStayValues("adult_$board", $periods, $default_adult, 'float', 0);
			$rates_child->$board = $this->loadPeriodsStayValues("child_$board", $periods, $default_child, 'float', 0);
		}

		// build the overrided object
		$boards = (object) [];
		foreach ($boards_array as $board)
		{
			// check the board is available for all dates
			if (array_sum($available_boards->$board) < $this->nights)
			{
				continue;
			}

			$boards->{$board} = (object) [
					'adult' => $rates_adult->$board,
					'child' => $rates_child->$board,
			];
		}

		// check that available boards where found
		if (!get_object_vars($boards))
		{
			$this->addError('warnings', 'SEARCH_BOARDS_NOT_FOUND_PERIODS', 'hotel', $hotel->id);
		}

		return $boards;
	}

	/**
	 * Load Search Units
	 * 
	 * @param object $available_hotel
	 */
	private function loadSearchUnits($available_hotel)
	{
		$search_units = [];
		foreach ($this->request->party as $i => $party)
		{
			// set the unit index, and guests
			$this->unit = $i;
			$this->guests = $party->adults + count($party->children);

			// init unit
			$unit = (object) ['party' => $this->loadUnitParty($party, $available_hotel)];
			$unit->boards_amounts = $this->loadBoardsAmounts($unit->party, $available_hotel);
			$unit->available_rooms = $this->loadAvailableRooms($unit->party, $unit->boards_amounts);

			// load search messages for the unit
			$this->loadMessagesUnit();

			// check unit
			if (!$unit->available_rooms)
			{
				continue;
			}

			// add the unit
			$search_units[] = $unit;
		}

		return $search_units;
	}

	/**
	 * loadUnitParty
	 * 
	 * @param type $party
	 * @param type $hotel_object
	 * @return type
	 */
	private function loadUnitParty($party, $hotel_object)
	{
		$unit_party = (object) [
				'room_adults' => $party->adults,
				'room_children' => 0,
				'room_babies' => 0,
				'boards_adults' => $party->adults,
				'boards_children' => 0,
		];

		if (!isset($party->children) || !$party->children)
		{
			return $unit_party;
		}

		foreach ($party->children as $child_age)
		{
			// rooms party
			if ($child_age >= $hotel_object->age_adult)
			{
				$unit_party->room_adults ++;
			}
			elseif ($child_age >= $hotel_object->age_child)
			{
				$unit_party->room_children ++;
			}
			else
			{
				$unit_party->room_babies ++;
			}

			// boards party
			if ($child_age >= $hotel_object->age_boards_adult)
			{
				$unit_party->boards_adults ++;
			}
			elseif ($child_age >= $hotel_object->age_child)
			{
				$unit_party->boards_children ++;
			}
		}

		return $unit_party;
	}

	/**
	 * loadBoardsAmounts
	 * 
	 * @param type $party
	 * @param type $available_hotel
	 * @return type
	 */
	private function loadBoardsAmounts($party, $available_hotel)
	{
		$boards_amounts = (object) [];

		foreach ($available_hotel->boards as $board => $rates)
		{
			$boards_amounts->$board = (object) [
					'adults' => CHLibData::listMultiply($rates->adult, $party->boards_adults),
					'children' => CHLibData::listMultiply($rates->child, $party->boards_children)
			];
		}

		return $boards_amounts;
	}

	/**
	 * loadAvailableRooms
	 * 
	 * @param type $party
	 * @param type $boards_amounts
	 */
	private function loadAvailableRooms($party, $boards_amounts)
	{
		// init rooms load
		$available_rooms = [];
		foreach ($this->hotel->rooms as $room)
		{

			// asign room_data to global var for later user
			$this->room = $room;
			$this->room_party = $party;
			$this->room_data = $this->loadFromData('rooms', $room->id);

			// check adults only
			if ($this->hotel->adults_only && ($party->room_children || $party->room_babies))
			{
				$this->addError('notices', 'SEARCH_PARTY_ADULTS_ONLY', 'room', $room->id, $this->unit);
				continue;
			}

			// check if party fits to the room
			if (!$this->checkPartyFitRoom($party))
			{
				$this->addError('notices', 'SEARCH_PARTY_DONT_FIT_ROOM', 'room', $room->id, $this->unit);
				continue;
			}

			// init room, other checks come later
			$available_room = (object) [
					'id' => $room->id,
					'reference' => $room->reference,
					'smoking' => $this->room_data->smoking,
					'bed_preference' => $this->room_data->bed_preference,
					'room_party' => $this->loadRoomParty($party, $this->room_data),
					'available_units' => $this->loadAvailableUnits()
			];

			// check availability
			if (!$available_room->available_units)
			{
				$this->addError('notices', 'SEARCH_ROOM_NOT_AVAILABLE', 'room', $room->id, $this->unit);
				continue;
			}

			// get the room rates
			$available_room->rates = $this->loadRoomRates($available_room, $boards_amounts);

			// check the rates
			if (!$available_room->rates)
			{
				$this->addError('notices', 'SEARCH_ROOM_NO_RATES', 'room', $room->id, $this->unit);
				continue;
			}

			// load the extras
			$available_room->extras = $this->loadRoomExtras($available_room);

			// add the room
			$available_rooms[] = $available_room;
		}

		return $available_rooms;
	}

	/**
	 * checkPartyFitRoom
	 * 
	 * @param type $party
	 * @return boolean
	 */
	private function checkPartyFitRoom($party)
	{

		$mincheck = true;
		$check1 = true;
		$check2 = true;
		$noparty2 = $this->room_data->party_max_2_adults == 0;

		// check adults
		$adultsp = $party->room_adults;
		$adultsr1 = (int) $this->room_data->party_max_adults;
		$adultsr2 = (int) $this->room_data->party_max_2_adults;
		if ($adultsp > $adultsr1)
		{
			$check1 = false;
		}
		if ($adultsp > $adultsr2)
		{
			$check2 = false;
		}

		// check children
		$childrenp = $adultsp + $party->room_children;
		$childrenr1 = (int) $this->room_data->party_max_adults + (int) $this->room_data->party_max_children;
		$childrenr2 = (int) $this->room_data->party_max_2_adults + (int) $this->room_data->party_max_2_children;
		if ($childrenp > $childrenr1)
		{
			$check1 = false;
		}
		if ($childrenp > $childrenr2)
		{
			$check2 = false;
		}

		// check babies
		$babiesp = $childrenp + $party->room_babies;
		$babiesr1 = $childrenr1 + (int) $this->room_data->party_max_babies;
		$babiesr2 = $childrenr2 + (int) $this->room_data->party_max_2_babies;
		if ($babiesp > $babiesr1)
		{
			$check1 = false;
		}
		if ($babiesp > $babiesr2)
		{
			$check2 = false;
		}

		// check minimum 
		if ($babiesp < $this->room_data->party_min)
		{
			$mincheck = false;
		}

		if (!$mincheck || (!$check1 && (!$check2 || $noparty2)))
		{
			return false;
		}

		return true;
	}

	/**
	 * loadRoomParty
	 * 
	 * @param type $party
	 * @return type
	 */
	private function loadRoomParty($party)
	{
		$room_party = (object) [];

		// standard occupation
		$room_party->standard = ($party->room_adults < $this->room_data->party_standard) ? $party->room_adults : (int) $this->room_data->party_standard;

		// extra adults
		$room_party->extra_adults = max(($party->room_adults - $room_party->standard), 0);

		// extra children
		$free_children = max(($room_party->standard - $party->room_adults), 0);
		$room_party->extra_children = max($party->room_children - $free_children, 0);

		// extra babies
		$free_babies = max(($room_party->standard - $party->room_adults - $party->room_children), 0);
		$room_party->extra_babies = max($party->room_babies - $free_babies, 0);

		return $room_party;
	}

	/**
	 * loadAvailableUnits
	 * 
	 * @param object $room
	 * @return int
	 */
	private function loadAvailableUnits()
	{
		$units = [];
		foreach ($this->ari as $row)
		{
			if ($row->room_id == $this->room->id)
			{
				$units[] = (int) $row->units;
			}
		}

		// check ari
		if (count($units) < $this->nights)
		{
			$this->addError('warning', 'SEARCH_ARI_INCOMPLETE', 'room', $this->room->id);
			return 0;
		}

		return min($units);
	}

	/**
	 * loadRoomRates
	 * 
	 * @param object $available_room
	 * @param object $boards_amounts
	 * @return array
	 */
	private function loadRoomRates($available_room, $boards_amounts)
	{
		// load room master rate
		$master_rate = $this->loadRoomMasterRate();

		// init rates array
		$rates = [];

		foreach ($this->hotel->rates as $rate)
		{
			// master rate
			if ($rate->id == 1)
			{
				// rate_data obtained form the hotel master_rate
				$rate_data = $this->hotel_data;
			}
			else
			{
				// rate_data obtained from the rates table
				$rate_data = $this->loadFromData('rates', $rate->id);

				// check if the rate applies to the current room
				if (!in_array($available_room->id, $rate_data->rooms))
				{
					continue;
				}
			}

			// check rate_ari to see if the rate is available, and minstay and anticipation are correct
			if (!$this->checkRateAri($rate))
			{
				continue;
			}

			// check the rate settings to see if it applies
			if (!$this->checkRateApply($rate, $rate_data, $boards_amounts))
			{
				continue;
			}

			// build the rate and add it to the list
			$room_rate = $this->buildRoomRate($rate, $rate_data, $available_room, $boards_amounts, $master_rate);
			if (!$room_rate)
			{
				continue;
			}

			// check rate standard amount (avoid 0 amount bookings)
			$standard = array_sum($room_rate->rate_amounts->standard);
			$single = array_sum($room_rate->rate_amounts->single);
			if (!$standard && !$single)
			{
				$this->addError('warning', 'SEARCH_RATE_AMOUNT_ZERO', 'rate', $rate->id, $this->unit);
				continue;
			}

			// add the rate
			$rates[] = $room_rate;
		}

		// reorder rates
		usort($rates, function($a, $b)
		{
			return array_sum($a->rate_amounts->standard) > array_sum($b->rate_amounts->standard);
		});

		return $rates;
	}

	/**
	 * loadRoomMasterRate
	 * 
	 * @param type $room
	 * @return int
	 */
	private function loadRoomMasterRate()
	{
		$rate = [];
		foreach ($this->ari as $row)
		{
			if ($row->room_id == $this->room->id)
			{
				$rate[] = (float) $row->rate;
			}
		}

		// check rates
		if (count($rate) < $this->nights)
		{
			$this->addError('warning', 'SEARCH_ARI_INCOMPLETE', 'room', $this->room->id);
			return array_fill(0, $this->nights, (float) $this->room->rack_rate);
		}

		return $rate;
	}

	/**
	 * checkRateAri
	 * 
	 * @param type $room
	 * @param type $rate
	 * @return bool
	 */
	private function checkRateAri($rate)
	{
		$available = [];
		$minstay = [];
		$anticipation = [];
		foreach ($this->ari_rates as $row)
		{
			if ($row->room_id == $this->room->id && $row->rate_id == $rate->id)
			{
				$available[] = (int) $row->available;
				$minstay[] = (int) $row->minstay;
				$anticipation[] = (int) $row->anticipation;
			}
		}

		// check rates
		if (count($available) < $this->nights)
		{
			$this->addError('warnings', 'SEARCH_ARI_RATE_INCOMPLETE', 'ari_rate', "{$this->room->id}_{$rate->id}");
			return false;
		}

		// check rate is available
		if (array_sum($available) < $this->nights)
		{
			$this->addError('notices', 'SEARCH_ARI_RATE_NOT_AVAILABLE', 'ari_rate', "{$this->room->id}_{$rate->id}");
			return false;
		}

		// check minstay
		if ($this->nights < max($minstay))
		{
			$this->addError('notices', 'SEARCH_ARI_RATE_MINSTAY', 'ari_rate', "{$this->room->id}_{$rate->id}", $this->unit, max($minstay));
			return false;
		}

		// check anticipation
		if ($this->anticipation < min($anticipation))
		{
			$this->addError('notices', 'SEARCH_ARI_RATE_ANTICIPATION', 'ari_rate', "{$this->room->id}_{$rate->id}", $this->unit, min($anticipation));
			return false;
		}

		return true;
	}

	/**
	 * checkRateApply
	 * 
	 * @param type $rate
	 * @param type $rate_data
	 * @param type $boards_amounts
	 * @return boolean
	 */
	private function checkRateApply($rate, $rate_data, $boards_amounts)
	{
		// check stay_max
		if ($this->nights > $rate_data->stay_max)
		{
			$this->addError('notices', 'SEARCH_RATE_STAY_MAX', 'rate', $rate->id, $this->unit, $rate_data->stay_max);
			return false;
		}

		// check anticipation_max
		if ($this->anticipation > $rate_data->anticipation_max)
		{
			$this->addError('notices', 'SEARCH_RATE_ANTICIPATION_MAX', 'rate', $rate->id, $this->unit, $rate_data->anticipation_max);
			return false;
		}

		// master rate checks done
		if ($rate->id == 1)
		{
			return true;
		}

		// check party min and max
		if ($this->guests < $rate_data->party_min || ($rate_data->party_max > 0 && $this->guests > $rate_data->party_max))
		{
			$this->addError('notices', 'SEARCH_RATE_PARTY', 'rate', $rate->id, $this->unit, [$rate_data->party_min, $rate_data->party_max]);
			return false;
		}

		// check rate boards
		$rate_boards = false;
		foreach ($boards_amounts as $board => $amounts)
		{
			if (in_array($board, $rate_data->boards))
			{
				$rate_boards = true;
			}
		}
		if (!$rate_boards)
		{
			$this->addError('notices', 'SEARCH_RATE_BOARDS', 'rate', $rate->id, $this->unit);
			return false;
		}

		// check week days
		$apply_nights = count(CHLibDate::datesInPeriod($this->request->start_date, $this->request->end_date, $rate_data->weekdays, false));
		if ($apply_nights != $this->nights)
		{
			$this->addError('notices', 'SEARCH_RATE_WEEKDAYS', 'rate', $rate->id, $this->unit);
			return false;
		}

		// check booking period applies
		$booking_periods = CHLibData::loadObjectFromList($rate_data->periods, 'booking')->rows;
		$booking_period_applies = $this->loadPeriodsDateValue('start', $booking_periods, null);
		if (is_null($booking_period_applies))
		{
			$this->addError('notices', 'SEARCH_RATE_DOES_NOT_APPLY', 'rate', $rate->id, $this->unit);
			return false;
		}

		return true;
	}

	/**
	 * buildRoomRate
	 * 
	 * @param type $rate
	 * @param type $rate_data
	 * @param type $available_room
	 * @param type $boards_amounts
	 * @param type $master_rate
	 * @return type,
	 */
	private function buildRoomRate($rate, $rate_data, $available_room, $boards_amounts, $master_rate)
	{
		// init rate base object
		$conditions = $this->buildRateConditions($rate_data);
		$deposit = $this->buildRateDeposit($rate_data);
		$cancellation_policy = $this->buildRateCancellation($rate_data);
		$deadline = $this->buildRateDeadline($rate_data);
		$room_rate = (object) [
				'id' => $rate->id,
				'reference' => $rate->reference,
				'conditions' => $conditions,
				'deposit_type' => $rate_data->deposit_type,
				'deposit_calculation' => $deposit,
				'deposit_min' => (float) $rate_data->deposit_min,
				'cancellation_policy' => $cancellation_policy,
				'cancellation_deadline' => $deadline,
				'free_cancellation' => $this->calculateFreeCancellation($conditions, $deadline),
				'rate_amounts' => $this->buildRateAmounts($rate, $rate_data, $master_rate, $available_room->room_party),
				'discounts' => [],
				'amounts' => (object) []
		];

		// check rate is ok
		if (!$room_rate->rate_amounts)
		{
			return false;
		}

		// get the rate discounts
		$room_rate->discounts = $this->loadRateDiscounts($room_rate, $boards_amounts);

		// build teh amounts
		$room_rate->amounts = $this->buildAmounts($room_rate, $boards_amounts);

		return $room_rate;
	}

	/**
	 * buildRateConditions
	 */
	private function buildRateConditions($rate_data)
	{
		$periods = CHLibData::loadObjectFromList($rate_data->periods, 'rate')->rows;
		if (!$periods)
		{
			return $rate_data->conditions;
		}
		$dates_conditions = $this->loadPeriodsStayValues('conditions', $periods, $rate_data->conditions);
		return $this->calculateWorstConditions($dates_conditions);
	}

	/**
	 * buildRateDeposit
	 */
	private function buildRateDeposit($rate_data)
	{
		$periods = CHLibData::loadObjectFromList($rate_data->periods, 'rate')->rows;
		if (!$periods)
		{
			return (float) $rate_data->deposit;
		}
		$calcs = $this->loadPeriodsStayValues('deposit', $periods, $rate_data->deposit, 'float');

		return $calcs ? max($calcs) : $rate_data->deposit;
	}

	/**
	 * buildRateCancellation
	 * @param type $rate_data
	 * @return type
	 */
	private function buildRateCancellation($rate_data)
	{
		$periods = CHLibData::loadObjectFromList($rate_data->periods, 'rate')->rows;
		if (!$periods)
		{
			return 0;
		}
		$cancellation_policies = $this->loadPeriodsStayValues('cancellation_policy', $periods, 0, 'int', true);
		return end($cancellation_policies);
	}

	/**
	 * calculateWorstConditions
	 * 
	 * @param type $conditions_array
	 */
	private function calculateWorstConditions($conditions_array)
	{
		$conditions_scale = [
			'pay_at_hotel' => 0,
			'deposit_refundable' => 1,
			'prepay_refundable' => 2,
			'deposit_non_refundable' => 3,
			'prepay_non_refundable' => 4
		];

		$conditions = [];
		foreach ($conditions_array as $condition)
		{
			$conditions[] = $conditions_scale[$condition];
		}

		return array_flip($conditions_scale)[max($conditions)];
	}

	/**
	 * buildRateDeadline
	 * 
	 * @param type $rate_data
	 * @return string
	 */
	private function buildRateDeadline($rate_data)
	{
		$periods = CHLibData::loadObjectFromList($rate_data->periods, 'rate')->rows;
		if ($periods)
		{
			$dates_deadlines = $this->loadPeriodsStayValues('deadline', $periods, $rate_data->deadline, 'int');
		}
		return $this->calculateDeadline($periods ? max($dates_deadlines) : $rate_data->deadline);
	}

	/**
	 * calculateDeadline
	 * 
	 * @param int $days
	 * @return string
	 */
	private function calculateDeadline($days)
	{
		if (!$days)
		{
			return $this->booking_date;
		}
		return CHLibDate::dateToSql(strtotime("-$days days", strtotime($this->request->start_date . ' 12:00')));
	}

	/**
	 * calculateFreeCancellation
	 * 
	 * @param type $conditions
	 * @param type $deadline
	 * @return type
	 */
	private function calculateFreeCancellation($conditions, $deadline)
	{
		$free_cancellation_conditions = ['pay_at_hotel', 'deposit_refundable', 'prepay_refundable'];
		return (
			in_array($conditions, $free_cancellation_conditions) &&
			!CHLibDate::isGreater($this->booking_date, $deadline)
			);
	}

	/**
	 * buildRateAmounts
	 * 
	 * @param type $rate
	 * @param type $rate_data
	 * @param type $master_rate
	 * @param type $room_party
	 * @return type
	 */
	private function buildRateAmounts($rate, $rate_data, $master_rate, $room_party)
	{
		// standard occupation rates
		$base_rates = (object) ['standard' => $this->calculateStandardRate($rate, $rate_data, $master_rate)];

		// check standard rate is ok
		if (!$base_rates->standard)
		{
			return false;
		}

		// default party rates values
		$party_rates = ['extra_adult', 'extra_child', 'extra_baby', 'single'];
		$party_rates_values = (object) [];
		foreach ($party_rates as $party_rate)
		{
			$party_rates_values->$party_rate = array_fill(0, $this->nights, (float) $this->room_data->{"rate_{$party_rate}"});
		}

		// get day by period overrides party rates values
		$periods = CHLibData::loadObjectFromList($this->room_data->periods, 'rate')->rows;
		if ($periods)
		{
			foreach ($party_rates as $party_rate)
			{
				$party_rates_values->$party_rate = $this->loadPeriodsStayValues("rate_$party_rate", $periods, $this->room_data->{"rate_{$party_rate}"}, 'float');
			}
		}

		// build party rates values
		foreach ($party_rates as $party_rate)
		{
			// apply date by date calculation
			foreach ($this->dates as $i => $date)
			{
				$party_rate_value = (float) $party_rates_values->{$party_rate}[$i];
				// percent
				if ($this->room_data->{"use_{$party_rate}"} == 'percent')
				{
					$base_rates->{$party_rate}[$i] = $base_rates->standard[$i] * $party_rate_value / 100;
				}
				// absolute value single
				else if ($party_rate == 'single')
				{
					$base_rates->{$party_rate}[$i] = $base_rates->standard[$i] + $party_rate_value;
				}
				// absolute value extra
				else
				{
					$base_rates->{$party_rate}[$i] = $party_rate_value;
				}
			}
		}

		// determine if party rates to apply are standard or single-use
		$this->single = ($room_party->standard == 1 && (count(array_filter($base_rates->single)) == $this->nights)) && !$room_party->extra_children && !$room_party->extra_babies;

		// multiply base_rates per each room party and return 
		return (object) [
				'standard' => CHLibData::listMultiply($base_rates->standard, (int) !$this->single),
				'extra_adults' => CHLibData::listMultiply($base_rates->extra_adult, $room_party->extra_adults),
				'extra_children' => CHLibData::listMultiply($base_rates->extra_child, $room_party->extra_children),
				'extra_babies' => CHLibData::listMultiply($base_rates->extra_baby, $room_party->extra_babies),
				'single' => CHLibData::listMultiply($base_rates->single, (int) $this->single),
		];
	}

	/**
	 * calculateStandardRate
	 * 
	 * @param type $rate
	 * @param type $rate_data
	 * @param type $master_rate
	 */
	private function calculateStandardRate($rate, $rate_data, $master_rate)
	{
		// master rate
		if ($rate->id == 1)
		{
			return $master_rate;
		}

		// default values
		$percents = array_fill(0, $this->nights, 0);
		$absolutes = array_fill(0, $this->nights, 0);

		// load the periods depending on the calculation period value (stay dates or booking dates)
		$periods = CHLibData::loadObjectFromList($rate_data->periods, $rate_data->period)->rows;

		// values based on the stay date
		if ($rate_data->period == 'stay')
		{
			$percents = array_filter($this->loadPeriodsStayValues('percent', $periods, 0, 'float', 0));
			$absolutes = array_filter($this->loadPeriodsStayValues('absolute', $periods, 0, 'float', 0));
		}

		// values based on the booking date
		if ($rate_data->period == 'booking')
		{
			$percent = $this->loadPeriodsDateValue('percent', $periods, 0, 'float');
			$absolute = $this->loadPeriodsDateValue('absolute', $periods, 0, 'float');
			$percents = array_filter(array_fill(0, $this->nights, (float) $percent));
			$absolutes = array_filter(array_fill(0, $this->nights, (float) $absolute));
		}

		// check percents
		if (count($percents) != $this->nights && $rate_data->calculation != 'absolute')
		{
			$this->addError('warnings', 'SEARCH_RATE_CALCULATION_PERIODS', 'rate', $rate->id, $this->unit);
			return [];
		}

		// check absoultes
		if (count($absolutes) != $this->nights && $rate_data->calculation != 'percent')
		{
			$this->addError('warnings', 'SEARCH_RATE_CALCULATION_PERIODS', 'rate', $rate->id, $this->unit);
			return [];
		}

		// calculate standard values
		$standard = [];
		foreach ($master_rate as $i => $master)
		{
			if ($rate_data->calculation == 'percent')
			{
				$standard[] = $master * $percents[$i] / 100;
			}

			if ($rate_data->calculation == 'absolute')
			{
				$standard[] = $master - $absolutes[$i];
			}

			if ($rate_data->calculation == 'percent_absolute')
			{
				$standard[] = ($master * $percents[$i] / 100) - $absolutes[$i];
			}

			if ($rate_data->calculation == 'absolute_percent')
			{
				$standard[] = ($master - $absolutes[$i]) * $percents[$i] / 100;
			}
		}

		return $standard;
	}

	/**
	 * loadRateDiscounts
	 * 
	 * @param type $room_rate
	 * @param type $boards_amounts
	 * @return type
	 */
	private function loadRateDiscounts($room_rate, $boards_amounts)
	{
		// init discounts list
		$rate_discounts = [];
		foreach ($this->hotel->discounts as $discount)
		{
			// load discount data
			$discount_data = $this->loadFromData('discounts', $discount->id);
			$discount_data->id = $discount->id;

			// check the discount settings to see if applies
			if (!$this->checkDiscountApply($discount_data, $room_rate, $boards_amounts))
			{
				continue;
			}

			// build the discount and add it to the list
			$rate_discount = $this->buildRateDiscount($discount, $discount_data, $room_rate, $boards_amounts);
			if ($rate_discount)
			{
				$rate_discounts[] = $rate_discount;
			}
		}

		return $rate_discounts;
	}

	/**
	 * checkDiscountApply
	 * 
	 * @param type $discount_data
	 * @param type $room_rate
	 * @return boolean
	 */
	private function checkDiscountApply($discount_data, $room_rate, $boards_amounts)
	{
		// check room
		if (!in_array($this->room->id, $discount_data->rooms))
		{
			return false;
		}

		// check rate
		if (!in_array($room_rate->id, $discount_data->rates))
		{
			return false;
		}

		// check booking period applies
		$booking_periods = CHLibData::loadObjectFromList($discount_data->periods, 'booking')->rows;
		$booking_period_applies = $this->loadPeriodsDateValue('start', $booking_periods, null);
		if (is_null($booking_period_applies))
		{
			$this->addError('notices', 'SEARCH_DISCOUNT_DOES_NOT_APPLY', 'discount', $discount_data->id, $this->unit);
			return false;
		}

		// common apply checks
		$check_anticipation = $discount_data->type != 'last_minute';
		if (!$this->checkApply($discount_data, $check_anticipation))
		{
			$this->addError('notices', 'SEARCH_DISCOUNT_DOES_NOT_APPLY', 'discount', $discount_data->id, $this->unit);
			return false;
		}

		// inverse check last minute anticipation_min, do not check max_anticipation
		if ($discount_data->type == 'last_minute' && $this->anticipation > $discount_data->anticipation_min)
		{
			return false;
		}

		// check last minute
		// check exclude periods
		$periods = CHLibData::loadObjectFromList($discount_data->periods, 'excludes')->rows;
		$excluded_dates = array_filter($this->loadPeriodsStayValues('start', $periods, 0, 'int', 0));
		if (count($excluded_dates))
		{
			return false;
		}

		// check promo_code
		if ($discount_data->type == 'promo_code' && $discount_data->promo_code != $this->request->promo_code)
		{
			return false;
		}

		// check boards to apply
		$apply_boards = 0;
		foreach ($boards_amounts as $board => $amounts)
		{
			if (in_array($board, $discount_data->boards))
			{
				$apply_boards = true;
			}
		}
		if (!$apply_boards)
		{
			return false;
		}

		// check week days
		$apply_nights = count(CHLibDate::datesInPeriod($this->request->start_date, $this->request->end_date, $discount_data->weekdays, false));
		if (!$apply_nights || ($discount_data->match == 'full' && $apply_nights != $this->nights))
		{
			return false;
		}

		return true;
	}

	/**
	 * buildRateDiscount
	 * 
	 * @param type $discount
	 * @param type $discount_data
	 * @param type $room_rate
	 * @return mixed
	 */
	private function buildRateDiscount($discount, $discount_data, $room_rate, $boards_amounts)
	{
		// discount base
		$rate_discount = (object) [
				'id' => $discount->id,
				'reference' => $discount->reference,
				'type' => $discount_data->type,
				'promo_code' => ($discount_data->type == 'promo_code' ? $discount_data->promo_code : null),
				'combinable' => $discount_data->combinable,
		];

		// calculate the amounts
		$rate_discount->discount_amounts = $this->buildDiscountAmounts($discount_data, $room_rate, $boards_amounts);
		if (!$rate_discount->discount_amounts)
		{
			return false;
		}

		// sum the amounts to get the amount per board
		$rate_discount->amounts = (object) [];
		foreach ($rate_discount->discount_amounts as $board => $amounts)
		{
			$rate_discount->amounts->$board = 0;
			foreach ($amounts as $key => $values)
			{
				$rate_discount->amounts->$board += array_sum($values);
			}
		}

		return $rate_discount;
	}

	/**
	 * buildDiscountAmounts
	 * 
	 * @param type $discount_data
	 * @param type $room_rate
	 * @return mixed
	 */
	private function buildDiscountAmounts($discount_data, $room_rate, $boards_amounts)
	{
		// load the periods 
		// based on the discount period setting
		$periods = CHLibData::loadObjectFromList($discount_data->periods, $discount_data->period)->rows;
		if (!$periods)
		{
			return false;
		}

		// get the discount values for stay setting 
		if ($discount_data->period == 'stay')
		{
			$values = $this->loadPeriodsStayValues('value', $periods, 0, 'float', 0);
		}

		// get the discount values for booking setting 
		if ($discount_data->period == 'booking')
		{
			$value = $this->loadPeriodsDateValue('value', $periods, null, 'float', 0);
			if (!$value)
			{
				// no value, no discount to apply
				return false;
			}
			$values = array_fill(0, $this->nights, (float) $value);
		}

		// check the weekdays to apply
		foreach ($this->dates as $i => $date)
		{
			if (!in_array(CHLibDate::weekDay($date), $discount_data->weekdays))
			{
				$values[$i] = 0;
			}
		}

		// no values, no discount to apply
		if (!array_filter($values))
		{
			return false;
		}

		// check if values meet the discount match setting when full stay is selected
		if ($discount_data->match == 'full' && count(array_filter($values)) != $this->nights)
		{
			return false;
		}

		// Discount values are OK, let's build the amounts object
		$amounts = (object) [];

		// calculation method
		$calculation = isset($discount_data->calculation) ? $discount_data->calculation : 'percent';

		// calculate amounts foreach board
		foreach ($boards_amounts as $board => $board_amounts)
		{
			// check if the discount applies to the board
			if (!in_array($board, $discount_data->boards))
			{
				continue;
			}

			// init board data
			$amounts->$board = (object) [];

			// build the party amounts
			foreach ($room_rate->rate_amounts as $party => $rates)
			{
				$amounts->$board->$party = [];
				foreach ($this->dates as $i => $date)
				{
					if ($calculation == 'percent')
					{
						// round values with 2 decimals, 
						// no more decimals are needed as they are only going to be sumed form now on
						$amounts->$board->{$party}[$i] = round($rates[$i] * $values[$i] / 100, 2);
					}

					if ($calculation == 'absolute_night')
					{
						$amounts->$board->{$party}[$i] = $party == 'standard' ? $values[$i] : 0;
					}

					if ($calculation == 'absolute_person_night')
					{
						$discount_amount = $values[$i] * $this->room_party->room_adults + ($values[$i] * $this->room_party->room_children * $discount_data->children_value / 100);
						$amounts->$board->{$party}[$i] = $party == 'standard' ? round($discount_amount, 2) : 0;
					}
				}
			}

			// default board discounts = 0
			$amounts->$board->board_adults = array_fill(0, $this->nights, 0);
			$amounts->$board->board_children = array_fill(0, $this->nights, 0);

			// nothing more to do
			if ($discount_data->apply != 'boards' || $calculation != 'percent')
			{
				continue;
			}

			// calculate boards discounts
			foreach ($this->dates as $i => $date)
			{
				$amounts->$board->board_adults[$i] = round($board_amounts->adults[$i] * $values[$i] / 100, 2);
				$amounts->$board->board_children[$i] = round($board_amounts->children[$i] * $values[$i] / 100, 2);
			}
		}

		// check boards to apply
		return $amounts;
	}

	/**
	 * buildAmounts
	 * 
	 * @param type $room_rate
	 * @param type $available_room
	 * @param type $boards_amounts
	 */
	private function buildAmounts($room_rate, $boards_amounts)
	{
		// init amounts data object
		$amounts = (object) [];

		// calculate amounts data for each board
		foreach ($boards_amounts as $board => $board_amounts)
		{
			$amounts->$board = (object) [
					'rate' => $this->calculateAmount($room_rate->rate_amounts, $board_amounts),
					'discount' => 0,
					'amount' => 0,
					'currency_rate' => 0,
					'currency_discount' => 0,
					'currency_amount' => 0,
					'discounts_applied' => []
			];
			$amounts->$board->discounts_applied = $this->loadDiscountsToApply($board, $room_rate->discounts);
			$amounts->$board->discount = $this->calculateDiscount($amounts->$board->discounts_applied);
			$amounts->$board->amount = $amounts->$board->rate - $amounts->$board->discount;
			$amounts->$board->currency_rate = round($amounts->$board->rate * $this->currency_conversion, 2);
			$amounts->$board->currency_discount = round($amounts->$board->discount * $this->currency_conversion, 2);
			$amounts->$board->currency_amount = round($amounts->$board->amount * $this->currency_conversion, 2);
		}

		return $amounts;
	}

	/**
	 * calculateAmount
	 */
	private function calculateAmount($rate_amounts, $board_amounts)
	{
		return $this->single ?
			(array_sum($rate_amounts->single) + array_sum($board_amounts->adults)) :
			(array_sum($rate_amounts->standard) +
			array_sum($rate_amounts->extra_adults) +
			array_sum($rate_amounts->extra_children) +
			array_sum($rate_amounts->extra_babies) +
			array_sum($board_amounts->adults) +
			array_sum($board_amounts->children));
	}

	/**
	 * loadDiscountsToApply
	 * 
	 * @param type $board
	 * @param type $discounts
	 */
	private function loadDiscountsToApply($board, $discounts)
	{
		// determine the discounts to be applied depending on each discount combinability		
		$combinable = [];
		$combinable_sum = 0;
		$non_combinable = [];
		$non_combinable_amount = 0;
		$exclusive = false;
		$exclusive_amount = 0;

		foreach ($discounts as $discount)
		{
			// check if the discount is available for the board
			if (!isset($discount->amounts->$board))
			{
				continue;
			}

			// init discount
			$appliable_discount = (object) [
					'id' => $discount->id,
					'amount' => $discount->amounts->$board,
					'currency_amount' => round($discount->amounts->$board * $this->currency_conversion, 2)
			];

			// get all the combinable discounts
			if ($discount->combinable == 'combinable')
			{
				$combinable[] = $appliable_discount;
				$combinable_sum += $appliable_discount->amount;
			}

			// look for the largest non-combinable discount
			if ($discount->combinable == 'non_combinable' && $appliable_discount->amount > $non_combinable_amount)
			{
				$non_combinable_amount = $appliable_discount->amount;
				$non_combinable = [$appliable_discount];
			}

			// look for the largest exclusive discount
			if ($discount->combinable == 'exclusive' && $appliable_discount->amount > $exclusive_amount)
			{
				$exclusive_amount = $appliable_discount->amount;
				$exclusive = $appliable_discount;
			}
		}

		// exclusive discount is the largest
		if ($exclusive_amount > ($combinable_sum + $non_combinable_amount))
		{
			return [$exclusive];
		}

		return array_merge($combinable, $non_combinable);
	}

	/**
	 * calculateAmount
	 */
	private function calculateDiscount($discounts_applied)
	{
		// total amount
		$discount_amount = 0;

		// sum all discounts appliable to the board
		foreach ($discounts_applied as $discount)
		{
			$discount_amount += $discount->amount;
		}

		return $discount_amount;
	}

	/**
	 * loadRoomExtras
	 * @param object $available_room
	 */
	private function loadRoomExtras($available_room)
	{
		$extras = [];

		foreach ($this->hotel->extras as $extra)
		{
			// load the data
			$extra_data = $this->loadFromData('extras', $extra->id);

			// check room
			if (!in_array($available_room->id, $extra_data->rooms))
			{
				continue;
			}

			// common apply checks
			if (!$this->checkApply($extra_data))
			{
				continue;
			}

			// load extra rates
			$periods = CHLibData::loadObjectFromList($extra_data->periods, 'rates')->rows;
			$rates = $this->loadPeriodsStayValues('amount', $periods, null, 'float');
			$filtered_rates = array_filter($rates, function($v)
			{
				return !is_null($v);
			});

			// check all stay dates are covered
			if (count($filtered_rates) < $this->nights)
			{
				continue;
			}

			// do not take i account babyes for extras
			$people = $available_room->room_party->standard + $available_room->room_party->extra_adults + $available_room->room_party->extra_children;

			// init extra
			$room_extra = (object) [
					'id' => $extra->id,
					'reference' => $extra->reference,
					'type' => $extra_data->type,
					'max_units' => $extra_data->max_units,
					'price_type' => $extra_data->price_type,
					'price_display' => 0,
					'extra_amounts' => [],
					'amount' => 0
			];

			// calculate amounts
			if ($extra_data->price_type == 'unit')
			{
				$room_extra->extra_amounts = max($rates);
				$room_extra->amount = max($rates);
				$room_extra->price_display = max($rates);
			}

			if ($extra_data->price_type == 'night')
			{
				$room_extra->extra_amounts = $rates;
				$room_extra->amount = array_sum($rates);
				$room_extra->price_display = $room_extra->amount / $this->nights;
			}

			if ($extra_data->price_type == 'person')
			{
				$room_extra->extra_amounts = max($rates) * $people;
				$room_extra->amount = max($rates) * $people;
				$room_extra->price_display = max($rates);
			}

			if ($extra_data->price_type == 'person_night')
			{
				$room_extra->extra_amounts = CHLibData::listMultiply($rates, $people);
				$room_extra->amount = array_sum($rates) * $people;
				$room_extra->price_display = array_sum($rates) / $this->nights;
			}

			// free extras
			if ($room_extra->type == 'included')
			{
				$room_extra->extra_amounts = [0];
				$room_extra->amount = 0;
				$room_extra->price_display = 0;
			}

			// currency amounts
			$room_extra->currency_amount = round($room_extra->amount * $this->currency_conversion, 2);
			$room_extra->currency_price_display = round($room_extra->price_display * $this->currency_conversion, 2);

			// add the extra to the list
			$extras[] = $room_extra;
		}

		return $extras;
	}

	/**
	 * 
	 * @param type $extra
	 */
	private function calculateExtraAmount($extra)
	{
		return $extra;
	}

	/**
	 * loadMessagesUnit 
	 */
	private function loadMessagesUnit()
	{
		/*
		 * Look in the notice codes to find a message to display
		 * 
		 * SEARCH_PARTY_DONT_FIT_ROOM - Party don't fit rooms
		 * SEARCH_PARTY_ADULTS_ONLY - Adults only hotel
		 * SEARCH_ROOM_NOT_AVAILABLE - Sold out or no availability found 
		 * SEARCH_ARI_RATE_MINSTAY - Not enough minstay 
		 * SEARCH_ARI_RATE_ANTICIPATION - Not enough anticipation 
		 */

		// init vars
		$number_of_rooms = count($this->hotel->rooms);
		$room_errors = [ 'fit' => 0, 'availability' => 0, 'adults_only' => 0];
		$room_rate_notices = [];

		// look for notices
		foreach ($this->notices as $notice)
		{
			// check hotel
			if ($notice->data->hotel_id != $this->hotel->id || $notice->data->unit != $this->unit)
			{
				continue;
			}

			// fit errors
			if ($notice->code == 'SEARCH_PARTY_DONT_FIT_ROOM')
			{
				$room_errors['fit'] ++;
				$this->addMessageRoom($notice->data->ref_id, 'fit');
				continue;
			}

			// availability
			if ($notice->code == 'SEARCH_ROOM_NOT_AVAILABLE')
			{
				$room_errors['availability'] ++;
				$this->addMessageRoom($notice->data->ref_id, 'availability');
				continue;
			}

			// adults only
			if ($notice->code == 'SEARCH_PARTY_ADULTS_ONLY')
			{
				$room_errors['adults_only'] ++;
				$this->addMessageRoom($notice->data->ref_id, 'adults_only');
				continue;
			}

			// minstay and anticipation errors
			if (in_array($notice->code, ['SEARCH_ARI_RATE_MINSTAY', 'SEARCH_ARI_RATE_ANTICIPATION']))
			{
				if (!isset($room_rate_notices[$notice->data->room_id]))
				{
					$room_rate_notices[$notice->data->room_id] = [];
				}
				$room_rate_notices[$notice->data->room_id][] = $notice;
			}
		}

		// check if a room error was found
		foreach ($room_errors as $type => $count)
		{
			// no absolute error
			if ($count != $number_of_rooms)
			{
				continue;
			}

			$this->messages->unit[] = (object) [
					'hotel_id' => $this->hotel->id,
					'unit' => $this->unit,
					'type' => $type,
					'code' => 'ERROR_UNIT_' . strtoupper($type),
					'data' => null
			];
			return;
		}

		// check room rates errors
		$unique_types = [];
		$min_minstay = 999;
		$min_anticipation = 999;
		foreach ($room_rate_notices as $room_id => $notices)
		{
			$minstay = 999;
			$anticipation = 999;
			$types = [];

			// merge notices by type
			foreach ($notices as $notice)
			{
				if ($notice->code == 'SEARCH_ARI_RATE_MINSTAY')
				{
					$types[] = 'minstay';
					$minstay = min($minstay, $notice->data->data);
					$min_minstay = min($min_minstay, $minstay);
				}

				if ($notice->code == 'SEARCH_ARI_RATE_ANTICIPATION')
				{
					// update anticipation
					$types[] = 'anticipation';
					$anticipation = min($anticipation, $notice->data->data);
					$min_anticipation = min($min_anticipation, $anticipation);
				}
			}

			// add room messages if needed
			$unique_types = array_unique($types);
			foreach (['minstay', 'anticipation'] as $type)
			{
				if (in_array($type, $unique_types))
				{
					$this->addMessageRoom($notice->data->ref_id, $type, $type == 'minstay' ? $minstay : $anticipation);
				}
			}
		}

		// a dominating reason found for the unit
		if (count($unique_types) == 1)
		{
			$unit_error_type = $unique_types[0];
			$this->messages->unit[] = (object) [
					'hotel_id' => $this->hotel->id,
					'unit' => $this->unit,
					'type' => $unit_error_type,
					'code' => 'ERROR_UNIT_' . strtoupper($unit_error_type),
					'data' => $unit_error_type == 'minstay' ? $min_minstay : $min_anticipation
			];
			return;
		}

		// no dominating reason found, add 'other' message
		$this->messages->unit[] = (object) [
				'hotel_id' => $this->hotel->id,
				'unit' => $this->unit,
				'type' => 'other',
				'code' => 'ERROR_UNIT_OTHER',
				'data' => null
		];

		return;
	}

	/**
	 * loadMessagesHotel
	 */
	private function loadMessagesHotel()
	{
		// check unit messages
		if (!$this->messages->unit)
		{
			return;
		}

		// init vars
		$errors = ['availability' => 0, 'minstay' => 0, 'anticipation' => 0, 'fit' => 0, 'adults_only' => 0];
		$minstay = 999;
		$anticipation = 999;

		// look for messages
		foreach ($this->messages->unit as $message)
		{
			if ($message->hotel_id != $this->hotel->id)
			{
				continue;
			}
			foreach ($errors as $type => $count)
			{
				if ($message->type == $type)
				{
					$errors[$type] ++;
					if ($type == 'minstay')
					{
						$minstay = min($message->data, $minstay);
					}
					if ($type == 'anticipation')
					{
						$anticipation = min($message->data, $anticipation);
					}
				}
			}
		}

		// look for same type messages
		$types = [];
		foreach ($errors as $type => $count)
		{
			if ($count)
			{
				$types[] = $type;
			}
		}

		$unique_types = array_unique($types);
		if (count($unique_types) == 1)
		{
			$type = $unique_types[0];
			$this->messages->hotel[] = (object) [
					'hotel_id' => $this->hotel->id,
					'type' => $type,
					'code' => 'ERROR_HOTEL_' . strtoupper($type),
					'data' => ($type == 'minstay' ? $minstay : ($type == 'anticipation' ? $anticipation : null))
			];
			return;
		}

		// no definitve error found, add 'other' message
		$this->messages->hotel[] = (object) [
				'hotel_id' => $this->hotel->id,
				'type' => 'other',
				'code' => 'ERROR_HOTEL_OTHER',
				'data' => null
		];

		return;
	}

	/**
	 * addMessageRoom
	 * 
	 * @param int $room_id
	 * @param string $type
	 */
	private function addMessageRoom($room_id, $type, $data = null)
	{
		$this->messages->room[] = (object) [
				'hotel_id' => $this->hotel->id,
				'room_id' => $room_id,
				'unit' => $this->unit,
				'code' => 'ERROR_ROOM_' . strtoupper($type),
				'data' => $data
		];
	}

	/**
	 * checkMultipleUnits
	 * @todo check different assignation orders
	 * 
	 * @param type $search_units
	 */
	private function checkMultipleUnits($search_units)
	{
		$available_units = [];
		foreach ($search_units as $unit)
		{
			$room_found = 0;
			foreach ($unit->available_rooms as $room)
			{
				// set room id availability
				if (!isset($available_units[$room->id]))
				{
					$available_units[$room->id] = $room->available_units;
				}

				// available room found
				if ($available_units[$room->id] > 0)
				{
					$available_units[$room->id] --;
					$room_found = true;
					break;
				}
			}

			// no available room found
			if (!$room_found)
			{
				$this->messages->hotel[] = (object) [
						'hotel_id' => $this->hotel->id,
						'type' => 'other',
						'code' => 'ERROR_HOTEL_AVAILABILITY_MULTI',
						'data' => null
				];
				return false;
			}
		}
		return true;
	}

	/**
	 * attachMonthAri
	 */
	private function attachMonthAri()
	{
		// check is needed
		if (!$this->request->month_ari || count($this->request->hotels_ids) > 1)
		{
			return false;
		}

		// get start and end dates for the request
		$month = substr($this->request->start_date, 0, -3);
		$start = $month . '-01';
		$end = $month . '-' . CHLibDate::getDate($start)->format('t');

		// get ari
		$request = (object) [
				'hotel_id' => $this->request->hotels_ids[0],
				'dates' => CHLibDate::datesInPeriod($start, $end),
				'currency' => $this->request->currency,
				'force' => false
		];

		// no errors should occur here
		return (new CHApiAriGet($request))->get()->response;
	}

	/**
	 * attachInventory
	 */
	private function attachInventory()
	{

		if (!$this->request->inventory)
		{
			return false;
		}

		// no errors should occur here
		return (new CHApiInventory($this->request->hotels_ids))->get()->response;
	}

	/*
	 * Utils
	 * --------------------
	 */

	/**
	 * Check common apply rules for discounts, extras, etc.
	 * @param object $data
	 * @return boolean
	 */
	private function checkApply($data, $check_anticipation = true)
	{
		// check party
		if ($this->guests < $data->party_min || ($data->party_max > 0 && $this->guests > $data->party_max))
		{
			return false;
		}

		// check stay 
		if ($this->nights < $data->stay_min || $this->nights > $data->stay_max)
		{
			return false;
		}

		// check anticipation 
		if (!$check_anticipation)
		{
			return true;
		}

		if ($this->anticipation < $data->anticipation_min || $this->anticipation > $data->anticipation_max)
		{
			return false;
		}

		return true;
	}

	/**
	 * addError
	 * 
	 * @param type $type
	 * @param type $code
	 * @param type $ref
	 * @param type $ref_id
	 * @param type $unit
	 * @param type $data
	 */
	private function addError($type, $code, $ref, $ref_id, $unit = null, $data = null)
	{
		$this->{$type}[] = (object) [
				'code' => $code,
				'data' => (object) [
					'hotel_id' => $this->hotel->id,
					'room_id' => $this->room->id,
					'ref' => $ref,
					'ref_id' => (int) $ref_id,
					'unit' => $unit,
					'data' => $data
				]
		];
	}

	/**
	 * Load From Data
	 * 
	 * @param string $list
	 * @param int $id
	 * @return mixed
	 */
	private function loadFromData($list, $id)
	{
		$data_list = $list . '_data';
		if (!isset($this->{$data_list}[$id]))
		{
			$this->errors[] = (object) ['code' => 'SEARCH_CORRUPTED_DATA'];
			return false;
		}
		return $this->{$data_list}[$id];
	}

	/**
	 * loadPeriodsStayValues
	 * 
	 * @param type $value
	 * @param type $periods
	 * @param type $default
	 * @param type $type
	 * @param type $force
	 * @return type
	 */
	private function loadPeriodsStayValues($value, $periods, $default, $type = false, $force = null)
	{
		$values = [];
		foreach ($this->dates as $i => $date)
		{
			$values[$i] = $default;
			foreach ($periods as $period)
			{
				if (CHLibDate::inPeriod($period->start, $period->end, $date))
				{
					if (isset($period->$value))
					{
						$values[$i] = $period->$value;
						if ($type)
						{
							settype($values[$i], $type);
						}
					}
					else
					{
						$values[$i] = $force;
					}
				}
			}
		}
		return $values;
	}

	/**
	 * loadPeriodsDateValue
	 * 
	 * @param type $value
	 * @param type $periods
	 * @param type $default
	 * @param type $type
	 * @return type
	 */
	private function loadPeriodsDateValue($value, $periods, $default = null, $type = false)
	{
		$val = $default;
		foreach ($periods as $period)
		{
			if (CHLibDate::inPeriod($period->start, $period->end, $this->booking_date))
			{
				if (isset($period->$value))
				{
					$val = $period->$value;
					if ($type)
					{
						settype($val, $type);
					}
				}
			}
		}
		return $val;
	}

}
