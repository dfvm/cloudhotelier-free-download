<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Status Booking
 */
class CHApiBookingStatus extends CHApiBookingUpdate
{

	/**
	 * Update a Booking
	 */
	protected function getResponse()
	{
		// confirmed
		if (10 <= $this->request->status && $this->request->status < 20)
		{
			$this->request->confirmed = CHLibDate::getDate()->toSql();
		}

		// cancelled
		if (30 <= $this->request->status && $this->request->status < 40)
		{
			$this->request->cancelled = CHLibDate::getDate()->toSql();
		}

		// perform the update
		return parent::getResponse();
	}

}
