<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

// Autoload library classes
JLoader::discover('CHApi', __DIR__);

/**
 * CH Api Lib
 */
class CHApi
{

	/**
	 * Get Inventory
	 */
	public static function inventory_get($request)
	{
		return (new CHApiInventory($request))->get();
	}

	/**
	 * Get ARI
	 */
	public static function ari_get($request)
	{
		return (new CHApiAriGet($request))->get();
	}

	/**
	 * Update ARI
	 */
	public static function ari_update($request)
	{
		return (new CHApiAriUpdate($request))->get();
	}

	/**
	 * Search Results
	 */
	public static function search_results($request)
	{
		return (new CHApiSearch($request))->get();
	}

	/**
	 * Add a booking
	 */
	public static function booking_add($request)
	{
		return (new CHApiBookingAdd($request))->get();
	}

	/**
	 * Get a booking
	 */
	public static function booking_get($request)
	{
		return (new CHApiBookingGet($request))->get();
	}

	/**
	 * Get a booking
	 */
	public static function booking_update($request)
	{
		return (new CHApiBookingUpdate($request))->get();
	}

	/**
	 * Cancel a booking
	 */
	public static function booking_status($request)
	{
		return (new CHApiBookingStatus($request))->get();
	}

	/**
	 * Confirm a booking
	 */
	public static function booking_confirm($request)
	{
		return (new CHApiBookingStatus($request))->get();
	}

	/**
	 * Cancel a booking
	 */
	public static function booking_cancel($request)
	{
		return (new CHApiBookingStatus($request))->get();
	}

}
