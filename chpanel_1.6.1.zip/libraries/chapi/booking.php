<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
//
defined('_JEXEC') or die();

/**
 * Booking
 */
abstract class CHApiBooking extends CHApiBase
{

	protected $booking;

	/**
	 * obtainNewBookingId
	 */
	protected function obtainNewBookingId()
	{
		CHLibDatabase::insertObject('chpanel_bookings', (object) ['status' => 00]);
		return (int) CHLibDatabase::insertid();
	}

	/**
	 * obtainNewBookingId
	 */
	protected function obtainNewChargeId()
	{
		CHLibDatabase::insertObject('chpanel_bookings_charges', (object) []);
		return (int) CHLibDatabase::insertid();
	}

	/**
	 * saveBooking
	 */
	protected function storeBooking()
	{
		// a conservative check
		if (!isset($this->booking))
		{
			return false;
		}

		// raw data
		$object = (object) [
				'data' => json_encode($this->booking, JSON_PRETTY_PRINT)
		];

		// fields for indexation
		foreach ([
		'id',
		'status',
		'created',
		'confirmed',
		'modified',
		'cancelled',
		'voucher',
		'start_date',
		'end_date',
		'nights',
		'promo_code',
		'language',
		'currency',
		'customer_first_name',
		'customer_last_name',
		'customer_email',
		'customer_phone',
		'customer_country',
		'customer_currency',
		'customer_newsletter',
		'confirmation_method',
		'pay_full',
		'amount_board',
		'amount_rate',
		'amount_discount_board',
		'amount_discount_rate',
		'amount_discount',
		'amount_stay',
		'amount_extras',
		'amount_total',
		'deposit_amount',
		'deposit_status',
		] as $field)
		{
			$object->$field = $this->booking->$field;
		}

		// hotel_id
		$object->hotel_id = $this->booking->hotel->id;
		$object->hotel_reference = $this->booking->hotel->reference;

		// rooms
		$rooms_ids = [];
		$rooms_references = [];
		$rooms_objects = [];
		$discounts_objects = [];
		$extras_objects = [];
		foreach ($this->booking->rooms as $i => $room)
		{
			// rooms ids
			$rooms_ids[] = $room->id;
			$rooms_references[] = $room->reference;

			// rooms objects
			$rooms_objects[] = (object) [
					'booking_id' => $this->booking->id,
					'room_unit' => $i,
					'id' => $room->id,
					'reference' => $room->reference,
					'room_adults' => $room->party->room_adults,
					'room_children' => $room->party->room_children,
					'room_babies' => $room->party->room_babies,
					'boards_adults' => $room->party->boards_adults,
					'boards_children' => $room->party->boards_children,
					'board' => $room->board,
					'rate_id' => $room->rate->id,
					'rate_reference' => $room->rate->reference,
					'rate_conditions' => $room->rate->conditions,
					'amount_board' => $room->amount_board,
					'amount_rate' => $room->amount_rate,
					'amount_discount_board' => $room->amount_discount_board,
					'amount_discount_rate' => $room->amount_discount_rate,
					'amount_discount' => $room->amount_discount,
					'amount_stay' => $room->amount_stay,
					'amount_extras' => $room->amount_extras,
					'amount_total' => $room->amount_total,
					'deposit_amount' => $room->deposit_amount
			];

			// discounts objects
			foreach ($room->discounts as $discount)
			{
				$discounts_objects[] = (object) [
						'booking_id' => $this->booking->id,
						'room_unit' => $i,
						'room_id' => $room->id,
						'id' => $discount->id,
						'reference' => $discount->reference,
						'type' => $discount->type,
						'amount_board' => $discount->amount_board,
						'amount_rate' => $discount->amount_rate,
						'amount' => $discount->amount,
				];
			}

			// extras objects
			foreach ($room->extras as $extra)
			{
				$extras_objects[] = (object) [
						'booking_id' => $this->booking->id,
						'room_unit' => $i,
						'room_id' => $room->id,
						'id' => $extra->id,
						'type' => $extra->type,
						'reference' => $extra->reference,
						'units' => $extra->units,
						'amount' => $extra->amount,
				];
			}
		}
		$object->rooms = count($rooms_ids);
		$object->rooms_ids = implode(',', $rooms_ids);
		$object->rooms_references = implode(',', $rooms_references);

		// confirmation plugin
		$object->confirmation_plugin = isset($this->booking->confirmation_data->plugin) ? $this->booking->confirmation_data->plugin : null;

		// app info
		foreach (['id', 'ip', 'user_id', 'user_ip', 'user_session_id'] as $field)
		{
			$object->{"app_$field"} = $this->booking->app->$field;
		}
		$object->app_user_ip2long = (int) sprintf('%u', ip2long($this->booking->app->user_ip));

		// tracking info
		if ($this->booking->tracking)
		{
			$object->tracking_referer = $this->booking->tracking->referer ? parse_url($this->booking->tracking->referer, PHP_URL_HOST) : '';
			$object->tracking_referer = $this->booking->tracking->referer_first_visit ? parse_url($this->booking->tracking->referer_first_visit, PHP_URL_HOST) : $object->tracking_referer;
			foreach (['gclid', 'aid', 'said', 'utm_source', 'utm_medium', 'utm_term', 'utm_content', 'utm_campaign'] as $field)
			{
				$object->{"tracking_$field"} = $this->booking->tracking->$field ? $this->booking->tracking->$field : '';
				$object->{"tracking_$field"} = $this->booking->tracking->{$field . '_first_visit'} ? $this->booking->tracking->{$field . '_first_visit'} : $this->booking->tracking->$field;
			}
		}

		// confirmation charge
		if (isset($this->booking->confirmation_data->deposit_charge))
		{
			$this->storeCharge($this->booking->confirmation_data->deposit_charge);
		}

		// update booking row
		CHLibDatabase::updateObject('chpanel_bookings', $object);

		// delete booking rows
		CHLibDatabase::delete('chpanel_bookings_rooms', 'booking_id', $this->booking->id);
		CHLibDatabase::delete('chpanel_bookings_discounts', 'booking_id', $this->booking->id);
		CHLibDatabase::delete('chpanel_bookings_extras', 'booking_id', $this->booking->id);

		// instert the rooms rows
		foreach ($rooms_objects as $room_object)
		{
			CHLibDatabase::insertObject('chpanel_bookings_rooms', $room_object);
		}

		// instert the discounts rows
		foreach ($discounts_objects as $discount_object)
		{
			CHLibDatabase::insertObject('chpanel_bookings_discounts', $discount_object);
		}

		// instert the extras rows
		foreach ($extras_objects as $extra_object)
		{
			CHLibDatabase::insertObject('chpanel_bookings_extras', $extra_object);
		}
	}

	/**
	 * storeCharge
	 */
	protected function storeCharge($charge)
	{
		$object = (object) [
				'id' => $charge->id,
				'booking_id' => $charge->booking_id,
				'created' => $charge->created,
				'plugin' => $charge->plugin,
				'plugin_charge_id' => $charge->plugin_charge_id,
				'amount' => $charge->amount,
				'data' => json_encode($charge->data, JSON_PRETTY_PRINT)
		];
		CHLibDatabase::updateObject('chpanel_bookings_charges', $object);
	}

}
