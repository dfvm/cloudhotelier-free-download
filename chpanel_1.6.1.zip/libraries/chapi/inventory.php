<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Inventory
 */
class CHApiInventory extends CHApiBase
{

	/**
	 * Get the response
	 */
	public function getResponse()
	{
		// get the response
		$data = $this->loadInventory($this->request);

		// check data
		if (!$data)
		{
			$this->errors[] = (object) ['code' => 'INVENTORY_NO_HOTELS_FOUND'];
		}

		return $data;
	}

}
