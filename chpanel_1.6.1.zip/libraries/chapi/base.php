<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * API Base abstract
 */
abstract class CHApiBase
{

	protected $request;
	protected $response;
	protected $errors;
	protected $warnings;
	protected $notices;
	protected $db;

	/**
	 * Constructor
	 */
	function __construct($request)
	{
		// store request
		$this->request = $request;

		// init properties
		$this->response = (object) [];
		$this->errors = [];
		$this->warnings = [];
		$this->notices = [];

		// load helpers
		$this->db = JFactory::getDbo();
	}

	/**
	 * Get the data
	 */
	public function get($method = null)
	{
		// clean the house 
		$this->abortExpiredBookings();

		// build the data object
		$data = (object) ['request' => $this->request];

		// load the response
		$data->response = $method ? $this->{$method}() : $this->getResponse();

		// load the errors
		$data->errors = (object) [
				'errors' => $this->errors,
				'warnings' => $this->warnings,
				'notices' => $this->notices
		];

		return $data;
	}

	/**
	 * Abort Old Bookings
	 */
	protected function abortExpiredBookings()
	{
		// expire processing bookings older than 15 minutes
		$time = new JDate(strtotime("-15 minutes"));
		$expire_time = $time->toSql();

		// get expired bookings
		$query = $this->db->getQuery(true)
			->select('a.id, a.start_date, a.end_date, a.rooms_ids, a.data')
			->from('#__chpanel_bookings AS a')
			->where('a.status >= 40')
			->where('a.status < 50')
			->where('a.created < ' . $this->db->quote($expire_time));
		$expired_bookings = $this->db->setQuery($query)->loadObjectList();
		if (!$expired_bookings)
		{
			return;
		}

		// perform the abort
		foreach ($expired_bookings as $booking)
		{
			// update availability table
			$rooms_ids = explode(',', $booking->rooms_ids);
			foreach ($rooms_ids as $room_id)
			{
				$query = $this->db->getQuery(true)
					->update('#__chpanel_ari AS a')
					->set('a.units = (a.units + 1)')
					->where('a.room_id = ' . (int) $room_id)
					->where('a.date >= ' . $this->db->quote($booking->start_date))
					->where('a.date < ' . $this->db->quote($booking->end_date));
				$this->db->setQuery($query)->execute();
			}

			// update the booking details
			$modified = CHLibDate::getDate()->toSql();
			$data = json_decode($booking->data);
			$data->status = 52;
			$data->modified = $modified;
			$query = $this->db->getQuery(true)
				->update('#__chpanel_bookings AS a')
				->set('a.modified = ' . $this->db->q($modified))
				->set('a.status = 52')
				->set('a.data = ' . $this->db->q(json_encode($data)))
				->where("a.id = $booking->id");
			$this->db->setQuery($query)->execute();
		}
	}

	/**
	 * Load the response data
	 */
	protected function getResponse()
	{
		return (object) [];
	}

	/**
	 * Load Inventory
	 */
	protected function loadInventory($hotel_ids = [])
	{
		// query inventory table
		$qids = implode(',', array_map('intval', $hotel_ids));
		$query = $this->db->getQuery(true)
			->select('a.data')
			->from("#__chpanel_inventory AS a")
			->where("a.hotel_id IN ($qids)");
		$items = $this->db->setQuery($query)->loadColumn();

		// check items
		if (!$items)
		{
			return [];
		}

		// decode result
		$result = [];
		foreach ($items as $item)
		{
			$result[] = json_decode($item);
		}
		return $result;
	}

	/**
	 * Load ari
	 */
	protected function loadAri($rooms_ids, $dates)
	{
		if (!$rooms_ids)
		{
			return false;
		}

		$qids = implode(',', array_map('intval', $rooms_ids));
		$qdates = implode(',', array_map(array($this->db, 'quote'), $dates));
		$query = $this->db->getQuery(true)
			->select('a.*')
			->from('#__chpanel_ari AS a')
			->where("a.room_id IN ($qids)")
			->where("a.date IN ($qdates)")
			->order('a.date');

		return $this->db->setQuery($query)->loadObjectList();
	}

	/**
	 * Load ari_rates
	 */
	protected function loadAriRates($rooms_ids, $dates, $rates_ids = null)
	{
		if (!$rooms_ids)
		{
			return false;
		}

		$qids = implode(',', array_map('intval', $rooms_ids));
		$qdates = implode(',', array_map(array($this->db, 'quote'), $dates));

		$query = $this->db->getQuery(true)
			->select('a.*')
			->from('#__chpanel_ari_rates AS a')
			->where("a.room_id IN ($qids)")
			->where("a.date IN ($qdates)")
			->order('a.date');

		if ($rates_ids)
		{
			$qrates_ids = implode(',', array_map('intval', $rates_ids));
			$query->where("a.rate_id IN ($qrates_ids)");
		}

		return $this->db->setQuery($query)->loadObjectList();
	}

	/**
	 * Get a list of hotels
	 * 
	 * @param array $hotels_ids
	 * @return array
	 */
	protected function getHotels($hotels_ids, $status = 1)
	{
		// check ids
		if (!is_array($hotels_ids) || !$hotels_ids)
		{
			return array();
		}

		// load hotels
		$query = $this->db->getQuery(true)
			->select('a.*')
			->from("#__chpanel_hotels AS a")
			->where('a.id IN(' . implode(',', $hotels_ids) . ')')
			->where("a.status = $status");

		// return
		return CHLibData::decodeItems($this->db->setQuery($query)->loadObjectList());
	}

	/**
	 * Get a hotel from db
	 * 
	 * @param type $hotel_id
	 * @return mixed
	 */
	protected function getHotel($hotel_id)
	{
		$hotels = $this->getHotels(array($hotel_id));
		if (!$hotels)
		{
			return false;
		}

		return $hotels[0];
	}

	/**
	 * Get Items Data
	 * 
	 * @param type $table
	 * @param type $ids
	 */
	protected function getItemsData($table, $ids)
	{
		if (!$ids)
		{
			return [];
		}

		$data = [];
		$qids = implode(',', array_map('intval', $ids));
		$query = $this->db->getQuery(true)->select('a.id, a.data')->from("#__chpanel_$table AS a")->where("a.id IN ($qids)");
		$rows = $this->db->setQuery($query)->loadObjectList();
		foreach ($rows as $row)
		{
			$data[$row->id] = json_decode($row->data);
		}
		return $data;
	}

	/**
	 * Get the transalted field
	 * 
	 * @param type $field
	 * @param type $data
	 * @param type $lang
	 */
	protected function loadTranslation($field, $data, $lang)
	{
		if (!isset($data->$field))
		{
			CHLib::log(json_encode([$field, $data, $lang], JSON_PRETTY_PRINT), 'debug', 'lib_chapi');
			return '';
		}
		$text = $data->$field;
		if (!isset($data->translations->$lang))
		{
			return $text;
		}
		if ($data->translations->$lang->$field)
		{
			return $data->translations->$lang->$field;
		}
		return $text;
	}

	/**
	 * currencyConversion
	 * 
	 * @param string $from
	 * @param string $to
	 * 
	 * @return float
	 */
	protected function currencyConversion($from, $to)
	{
		// load helper
		jimport('joomla.application.helper');

		// load currency conversion file
		$xrates = CHLibData::readJsonFile(JPATH_CACHE . '/' . JApplicationHelper::getHash('chapi-xrates'));
		if (!$xrates)
		{
			$this->warnings[] = (object) ['code' => 'BASE_CURRENCY_CONVERSION_NOT_FOUND'];
			return 1;
		}

		// check currency conversion
		if (!isset($xrates->rates) || !isset($xrates->rates->$from) || !isset($xrates->rates->$to))
		{
			$this->warnings[] = (object) ['code' => 'BASE_CURRENCY_CONVERSION_NOT_FOUND'];
			return 1;
		}

		return $xrates->rates->$to / $xrates->rates->$from;
	}

	/**
	 * loadPlugin
	 */
	protected function loadPlugin($name)
	{
		$data = JPATH_BASE . "/plugins/chpanel/$name/$name.json";
		$helper = JPATH_BASE . "/plugins/chpanel/$name/$name.php";
		if (!is_file($data) || !is_file($helper))
		{
			return false;
		}
		require_once $helper;
		JFactory::getLanguage()->load("plg_chpanel_$name", JPATH_BASE . "/plugins/chpanel/$name");
		return CHLibData::readJsonFile($data);
	}

}
