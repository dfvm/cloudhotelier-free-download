<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Booking Get
 */
class CHApiBookingGet extends CHApiBooking
{

	/**
	 * Get a booking info
	 */
	protected function getResponse()
	{
		$booking = false;
		$booking_data = CHLibDatabase::loadResult('data', 'chpanel_bookings', 'id', $this->request->booking_id);
		if ($booking_data)
		{
			$booking = json_decode($booking_data);
		}

		if (!$booking_data || !$booking)
		{
			$this->errors[] = (object) [
					'code' => 'BOOKING_ADD_NO_SEARCH_RESULTS',
					'data' => null
			];
			return false;
		}

		// check free cancellation based on the cancellation deadline
		if ($booking->free_cancellation)
		{
			$booking->free_cancellation = CHLibDate::sqlToInt($booking->cancellation_deadline) >= CHLibDate::sqlToInt(CHLibDate::dateToSql()) ? 1 : 0;				
		}

		return $booking;
	}

}
