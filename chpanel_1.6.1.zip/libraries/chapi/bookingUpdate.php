<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Booking Update
 */
class CHApiBookingUpdate extends CHApiBooking
{

	/**
	 * Update a Booking
	 */
	protected function getResponse()
	{
		// load booking details
		$this->booking = $this->loadCurrentBooking();
		if (!$this->booking)
		{
			return false;
		}

		// update booking values
		$this->booking->modified = CHLibDate::getDate()->toSql();
		foreach ($this->request as $field => $value)
		{
			$this->booking->$field = $value;
		}

		// save the booking
		$this->storeBooking();

		return $this->booking;
	}

	/**
	 * loadCurrentBooking
	 */
	private function loadCurrentBooking()
	{
		$booking_data = CHApi::booking_get((object) ['booking_id' => $this->request->id]);
		if (!$booking_data->response)
		{
			$this->errors[] = (object) [
					'code' => 'BOOKING_UPDATE_BOOKING_NOT_FOUND',
					'data' => null
			];
			return false;
		}

		return $booking_data->response;
	}

}
