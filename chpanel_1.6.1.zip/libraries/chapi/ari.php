<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * API Ari abstract
 */
abstract class CHApiAri extends CHApiBase
{

	protected $dates;
	protected $hotel;
	protected $ari;
	protected $ari_rates;

	/**
	 * Check hotel and dates
	 * 
	 * @param type $check_dates
	 * @return boolean
	 */
	protected function checkHotelAndDates($check_dates = false)
	{
		// get the hotel
		$inventory = $this->loadInventory([$this->request->hotel_id]);
		if (!$inventory)
		{
			$this->errors[] = (object) ['code' => 'ARI_HOTEL_NOT_FOUND'];
			return false;
		}
		$this->hotel = $inventory[0];

		// get the dates
		$this->dates = $this->request->dates;
		if (!$this->dates || !is_array($this->dates))
		{
			$this->errors[] = (object) ['code' => 'ARI_INCORRECT_DATES'];
			return false;
		}

		if (!$check_dates)
		{
			return true;
		}

		// check no date is in the past or too much in the future
		$max_date = CHLibDate::getDate(strtotime('+3 years'));
		$int_today = CHLibDate::sqlToInt(CHLibDate::dateToSql());
		$int_max_future = CHLibDate::sqlToInt($max_date);
		foreach ($this->dates as $date)
		{
			$int_date = CHLibDate::sqlToInt($date);
			if ($int_date < $int_today)
			{
				$this->errors[] = (object) ['code' => 'ARI_INCORRECT_DATES_PAST'];
				return false;
			}

			if ($int_date > $int_max_future)
			{
				$this->errors[] = (object) ['code' => 'ARI_INCORRECT_DATES_FUTURE', 'data' => (object) ['max_date' => $max_date->format(CHLibDate::dateLocale())]];
				return false;
			}
		}

		return true;
	}

}
