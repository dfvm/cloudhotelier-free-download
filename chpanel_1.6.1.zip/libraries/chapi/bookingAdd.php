<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Booking Add
 */
class CHApiBookingAdd extends CHApiBooking
{

	private $search_response;
	private $available_hotel;
	private $hotel_info;
	private $charge;
	private $token_plugin;

	/**
	 * Add a new booking
	 */
	protected function getResponse()
	{
		// check availability
		$search_results = $this->getSearchResults();
		if (!$search_results->response->available_hotels)
		{
			$this->errors[] = (object) [
					'code' => 'BOOKING_ADD_NO_SEARCH_RESULTS',
					'data' => null
			];
			return false;
		}

		// build the booking object
		$this->search_response = $search_results->response;
		if (!$this->buildBooking())
		{
			$this->booking = false;
			return false;
		}

		// save the booking
		$this->storeBooking();

		// save the charge if needed
		if ($this->charge)
		{
			$this->saveCharge();
		}

		// update available units
		foreach ($this->booking->rooms as $room)
		{
			$query = $this->db->getQuery(true)
				->update('#__chpanel_ari AS a')
				->set('a.units = (a.units - 1)')
				->where('a.room_id = ' . (int) $room->id)
				->where('a.units > 0')
				->where('a.date >= ' . $this->db->quote($this->booking->start_date))
				->where('a.date < ' . $this->db->quote($this->booking->end_date));
			$this->db->setQuery($query)->execute();
		}

		return $this->booking;
	}

	/**
	 * getSearchResults
	 */
	private function getSearchResults()
	{
		$search = (object) [];
		foreach (['start_date', 'end_date', 'lang', 'currency', 'promo_code'] as $field)
		{
			$search->$field = $this->request->$field;
		}
		$search->hotels_ids = [$this->request->hotel_id];
		$search->party = [];
		foreach ($this->request->rooms as $room)
		{
			$search->party[] = $room->party;
		}
		$search->month_ari = false;

		// init api request
		return CHApi::search_results($search);
	}

	/**
	 * buildBooking
	 */
	private function buildBooking()
	{
		// prepare short access
		$this->available_hotel = $this->search_response->available_hotels[0];
		$this->hotel_info = $this->search_response->inventory[0];
		$now = CHLibDate::getDate()->toSql();
		$never = '0000-00-00 00:00:00';

		// load booking status
		$booking_status = $this->loadBookingStatus();
		if (!$booking_status)
		{
			return false;
		}

		// init booking object
		$this->booking = (object) [
				'id' => $this->obtainNewBookingId(),
				'status' => $booking_status,
				'created' => $now,
				'modified' => $never,
				'confirmed' => ((10 <= $booking_status && $booking_status < 20) ? $now : $never),
				'cancelled' => $never,
				'voucher' => $this->obtainVoucher(),
				'start_date' => $this->request->start_date,
				'end_date' => $this->request->end_date,
				'nights' => $this->search_response->nights,
				'promo_code' => '',
				'language' => $this->request->lang,
				'currency' => $this->hotel_info->currency,
				'customer_first_name' => $this->request->customer_first_name,
				'customer_last_name' => $this->request->customer_last_name,
				'customer_email' => $this->request->customer_email,
				'customer_phone' => $this->request->customer_phone,
				'customer_country' => $this->request->customer_country,
				'customer_currency' => $this->request->currency,
				'customer_currency_conversion' => $this->available_hotel->currency_conversion,
				'customer_checkin_time' => $this->request->customer_checkin_time,
				'customer_requests' => $this->request->customer_requests,
				'customer_newsletter' => $this->request->customer_newsletter,
				'hotel' => (object) [],
				'rooms' => [],
				'pay_full' => $this->request->pay_full,
				'confirmation_method' => $this->request->confirmation_method,
				'confirmation_data' => $this->request->confirmation_data,
				'free_cancellation' => 1,
				'cancellation_deadline' => '',
				'amount_board' => 0,
				'amount_rate' => 0,
				'amount_discount_board' => 0,
				'amount_discount_rate' => 0,
				'amount_discount' => 0,
				'amount_stay' => 0,
				'amount_extras' => 0,
				'amount_total' => 0,
				'deposit_amount' => 0,
				'deposit_status' => 0,
				'cancellation' => (object) [],
		];

		// build the hotel object, exclude fields not needed to store with the booking
		foreach ($this->hotel_info as $field => $value)
		{
			if (in_array($field, ['slug', 'description', 'accomodation_type', 'languages', 'size_units', 'amenities', 'translations', 'photos', 'rooms', 'rates', 'discounts', 'extras']))
			{
				continue;
			}
			$this->booking->hotel->$field = $this->hotel_info->$field;
		}

		// add the translations for text strings in the language of the reservation 
		foreach (['title', 'info', 'conditions_text', 'email', 'phone', 'website', 'street', 'zip', 'city', 'region'] as $field)
		{
			$this->booking->hotel->{"translation_$field"} = $this->booking->hotel->$field;
			if (
				isset($this->hotel_info->translations->{$this->request->lang}) &&
				isset($this->hotel_info->translations->{$this->request->lang}->$field) &&
				$this->hotel_info->translations->{$this->request->lang}->$field
			)
			{
				$this->booking->hotel->{"translation_$field"} = $this->hotel_info->translations->{$this->request->lang}->$field;
			}
		}

		// build booking rooms
		if (!$this->buildBookingRooms())
		{
			return false;
		}

		// check multiple room availability
		if (!$this->checkMultiRoom())
		{
			$this->errors[] = (object) [
					'code' => 'BOOKING_ADD_MULTIPLE_ROOM_FAILED',
					'data' => null
			];
			return false;
		}

		// attach app info
		$this->booking->app = $this->request->app;
		$this->booking->app->user_ip = $this->request->user_ip;
		$this->booking->app->user_id = $this->request->user_id;
		$this->booking->app->user_session_id = $this->request->user_session_id;

		// attach tracking info
		$this->booking->tracking = $this->request->tracking;

		// launch card tokenization confirmation plugin
		if (in_array($this->booking->confirmation_method, ['token_iframe', 'token_js']))
		{
			return $this->processTokenConfirmation();
		}

		return true;
	}

	/**
	 * Load booking status depending on confirmation method
	 */
	private function loadBookingStatus()
	{
		// directly confirmed 
		if (in_array($this->request->confirmation_method, ['request_confirmed', 'card_data', 'token_iframe', 'token_js']))
		{
			return 11;
		}

		// pending, booking request
		if ($this->request->confirmation_method == 'request_pending')
		{
			return 21;
		}

		// processing, card details not collected
		if (in_array($this->request->confirmation_method, ['card_redirect', 'card_iframe']))
		{
			return 41;
		}

		// processing, online payment pending
		if (in_array($this->request->confirmation_method, ['deposit_redirect', 'deposit_iframe']))
		{
			return 42;
		}

		// no other state is possible for new bookings
		$this->errors[] = (object) [
				'code' => 'BOOKING_ADD_INVALID_CONFIRMATION_METHOD',
				'data' => null
		];

		return false;
	}

	/**
	 * obtainVoucher
	 */
	private function obtainVoucher()
	{
		jimport('joomla.user.helper');
		return strtoupper(JUserHelper::genRandomPassword(6));
	}

	/**
	 * buildBookingRooms
	 */
	private function buildBookingRooms()
	{
		// load rooms data
		$booking_deadline = 00000000;
		foreach ($this->request->rooms as $i => $request_room)
		{
			// load the unit details
			$search_unit = $this->available_hotel->search_units[$i];

			// check board
			if (!isset($search_unit->boards_amounts->{$request_room->board}))
			{
				$this->errors[] = (object) [
						'code' => 'BOOKING_ADD_BOARD_NOT_AVAILABLE',
						'data' => (object) ['unit' => $i, 'board' => $request_room->board]
				];
				return false;
			}

			// load the available room details
			$available_room = CHLibData::loadObject($search_unit->available_rooms, $request_room->id);
			if (!$available_room)
			{
				$this->errors[] = (object) [
						'code' => 'BOOKING_ADD_ROOM_NOT_AVAILABLE',
						'data' => (object) ['unit' => $i, 'room_id' => $request_room->id]
				];
				return false;
			}

			// load the rate to be applied
			$available_room_rate = CHLibData::loadObject($available_room->rates, $request_room->rate_id);
			if (!$available_room_rate)
			{
				$this->errors[] = (object) [
						'code' => 'BOOKING_ADD_ROOM_RATE_NOT_AVAILABLE',
						'data' => (object) ['unit' => $i, 'room_id' => $request_room->id, 'rate_id' => $request_room->rate_id]
				];
				return false;
			}

			// check rate board
			if (!isset($available_room_rate->amounts->{$request_room->board}))
			{
				$this->errors[] = (object) [
						'code' => 'BOOKING_ADD_ROOM_RATE_BOARD_NOT_AVAILABLE',
						'data' => (object) ['unit' => $i, 'room_id' => $available_room->id, 'rate_id' => $available_room_rate->id, 'board' => $request_room->board]
				];
				return false;
			}

			// load room and rate info
			$room_info = CHLibData::loadObject($this->hotel_info->rooms, $available_room->id);
			$rate_info = CHLibData::loadObject($this->hotel_info->rates, $available_room_rate->id);

			// init room object
			$room = (object) [];
			foreach (['id', 'reference', 'title', 'image', 'info'] as $field)
			{
				$room->$field = $room_info->$field;
			}

			// party and guest info
			$room->party = $search_unit->party;
			$room->party->request = $request_room->party;
			$room->guest = $request_room->guest;
			$room->bed = $request_room->bed;
			$room->smoking = $request_room->smoking;

			// board info
			$room->board = $request_room->board;
			$room->board_amounts = $search_unit->boards_amounts->{$room->board};

			// init rate, discounts and extras
			$room->rate = (object) [];
			$room->discounts = [];
			$room->extras = [];

			// rate details
			foreach (['id', 'reference', 'title'] as $field)
			{
				$room->rate->$field = $rate_info->$field;
			}
			$cancellation_policy_text = "cancellation_policy_text_{$available_room_rate->cancellation_policy}";

			// conditions and cancellation policy
			$room->rate->conditions = $available_room_rate->conditions;
			$room->rate->cancellation_policy = $available_room_rate->cancellation_policy;
			$room->rate->cancellation_policy_text = $rate_info->$cancellation_policy_text;
			$room->rate->cancellation_deadline = $available_room_rate->cancellation_deadline;
			$room->rate->free_cancellation = $available_room_rate->free_cancellation;

			// rate amounts detail
			$room->rate->rate_amounts = $available_room_rate->rate_amounts;

			// translations
			$room->rate->translation_title = $this->loadTranslation('title', $rate_info, $this->request->lang);
			$room->rate->translation_cancellation_policy_text = $this->loadTranslation('cancellation_policy_text_' . $available_room_rate->cancellation_policy, $rate_info, $this->request->lang);

			// discounts 
			$room_amount_discount_board = 0;
			$room_amount_discount_rate = 0;
			foreach ($available_room_rate->amounts->{$request_room->board}->discounts_applied as $discount_applied)
			{
				// get discount info
				$discount_detail = CHLibData::loadObject($available_room_rate->discounts, $discount_applied->id);
				$discount_info = CHLibData::loadObject($this->hotel_info->discounts, $discount_applied->id);

				// build discount object
				$discount = (object) [];
				foreach (['id', 'reference', 'title', 'type', 'promo_code', 'combinable'] as $field)
				{
					$discount->$field = isset($discount_detail->$field) ? $discount_detail->$field : (isset($discount_info->$field) ? $discount_info->$field : null);
				}

				// amount detail
				$discount->discount_amounts = $discount_detail->discount_amounts->{$request_room->board};

				// amounts
				$discount->amount_board = array_sum($discount->discount_amounts->board_adults) + array_sum($discount->discount_amounts->board_children);
				$discount->amount_rate = $discount_applied->amount - $discount->amount_board;
				$discount->amount = $discount_applied->amount;

				// room discount
				$room_amount_discount_board += $discount->amount_board;
				$room_amount_discount_rate += $discount->amount_rate;

				// translations
				$discount->translation_title = $this->loadTranslation('title', $discount_info, $this->request->lang);

				// add the discount
				$room->discounts[] = $discount;
			}

			// add the extras
			$room_amount_extras = 0;
			$room->extras = [];
			foreach ($available_room->extras as $available_extra)
			{
				// get the requested units
				$requested = CHLibData::loadObject($request_room->extras, $available_extra->id);

				// extra is not selected
				if (!$requested || !$requested->units)
				{
					// check if the extra should have been selected
					if (!$available_extra->type == 'optional')
					{
						$this->errors[] = (object) [
								'code' => 'BOOKING_ADD_SPECIAL_EXTRA_NOT_REQUESTED',
								'data' => (object) ['unit' => $i, 'room_id' => $available_room->id, 'extra_id' => $available_extra->id]
						];
						return false;
					}
					continue;
				}

				// load info
				$extra_detail = CHLibData::loadObject($available_room->extras, $available_extra->id);
				$extra_info = CHLibData::loadObject($this->hotel_info->extras, $available_extra->id);

				// check max units
				if ($requested->units > $extra_detail->max_units)
				{
					$this->errors[] = (object) [
							'code' => 'BOOKING_ADD_SPECIAL_EXTRA_MAX_UNITS',
							'data' => (object) ['unit' => $i, 'room_id' => $available_room->id, 'extra_id' => $available_extra->id]
					];
					return false;
				}

				// init extra object
				$extra = (object) [];
				foreach (['id', 'reference', 'title', 'image', 'info'] as $field)
				{
					$extra->$field = $extra_info->$field;
				}

				// details
				$extra->type = $extra_detail->type;
				$extra->max_units = $extra_detail->max_units;
				$extra->price_type = $extra_detail->price_type;
				$extra->extra_amounts = $extra_detail->extra_amounts;
				$extra->units = $requested->units;

				// amount
				$extra->amount = $requested->units * $extra_detail->amount;

				// translations
				$extra->translation_title = $this->loadTranslation('title', $extra_info, $this->request->lang);
				$extra->translation_info = $this->loadTranslation('info', $extra_info, $this->request->lang);

				// add the extra to the room
				$room->extras[] = $extra;

				// sum to the room extras amount
				$room_amount_extras += $extra->amount;
			}

			// amounts
			$room->amount_board = array_sum($room->board_amounts->adults) + array_sum($room->board_amounts->children);
			$room->amount_rate = $available_room_rate->amounts->{$request_room->board}->rate - $room->amount_board;
			$room->amount_discount_board = $room_amount_discount_board;
			$room->amount_discount_rate = $room_amount_discount_rate;
			$room->amount_discount = $room_amount_discount_board + $room_amount_discount_rate;
			$room->amount_stay = $available_room_rate->amounts->{$request_room->board}->amount;
			$room->amount_extras = $room_amount_extras;
			$room->amount_total = $room->amount_stay + $room->amount_extras;

			// deposit calculation
			$room->deposit_type = $available_room_rate->deposit_type;
			$room->deposit_calculation = $available_room_rate->deposit_calculation;
			$room->deposit_min = $available_room_rate->deposit_min;
			$room->deposit_amount = $this->request->pay_full ? $room->amount_total : $this->calculateDeposit($room->amount_stay, $available_room_rate);

			// translations
			$room->translation_title = $this->loadTranslation('title', $room_info, $this->request->lang);
			$room->translation_info = $this->loadTranslation('info', $room_info, $this->request->lang);

			// update booking amounts
			foreach (['board', 'rate', 'discount_board', 'discount_rate', 'discount', 'stay', 'extras', 'total'] as $field)
			{
				$this->booking->{"amount_$field"} += $room->{"amount_$field"};
			}

			// booking deposit
			$this->booking->deposit_amount += $room->deposit_amount;

			// free_cancellation 
			if (!$room->rate->free_cancellation)
			{
				$this->booking->free_cancellation = 0;
			}

			// deadline
			$rate_deadline = CHLIbdate::sqlToInt($room->rate->cancellation_deadline);
			if ($rate_deadline > $booking_deadline)
			{
				$booking_deadline = $rate_deadline;
				$this->booking->cancellation_deadline = $room->rate->cancellation_deadline;
			}

			// add the room to the booking
			$this->booking->rooms[] = $room;
		}

		return true;
	}

	/**
	 * calculateDeposit
	 */
	private function calculateDeposit($amount, $rate)
	{
		// no deposit needed
		if ($rate->conditions == 'pay_at_hotel')
		{
			return 0;
		}

		// return the full amount
		if (in_array($rate->conditions, ['prepay_refundable', 'prepay_non_refundable']))
		{
			return $amount;
		}

		// calculate the deposit
		$deposit = 0;
		if ($rate->deposit_type == 'percent')
		{
			$deposit = $amount * $rate->deposit_calculation / 100;
		}

		if ($rate->deposit_type == 'absolute')
		{
			$deposit = $rate->deposit_calculation;
		}

		if ($rate->deposit_type == 'nights')
		{
			$slice = $rate->deposit_calculation > $this->search->nights ? $this->search->nights : $rate->deposit_calculation;
			$deposit = array_sum(array_slice($rate->rate_amounts->standard, 0, $slice));
		}

		// check minimum deposit
		if ($deposit < $rate->deposit_min)
		{
			$deposit = $rate->deposit_min;
		}

		// check maximum deposit
		if ($deposit > $amount)
		{
			$deposit = $amount;
		}

		return $deposit;
	}

	/**
	 * checkMultiRoom
	 */
	private function checkMultiRoom()
	{
		// nothing to check
		if (count($this->booking->rooms) == 1)
		{
			return true;
		}

		// build the availability array
		$multi_availability = [];
		foreach ($this->available_hotel->search_units as $search_unit)
		{
			foreach ($search_unit->available_rooms as $room)
			{
				if (!isset($multi_availability[$room->id]))
				{
					$multi_availability[$room->id] = $room->available_units;
				}
			}
		}

		// check multi availability
		foreach ($this->booking->rooms as $room)
		{
			// does not exist
			if (!isset($multi_availability[$room->id]) || $multi_availability[$room->id] < 1)
			{
				return false;
			}

			// reduce 1 unit
			$multi_availability[$room->id] --;
		}

		return true;
	}

	/**
	 * processTokenConfirmation
	 */
	private function processTokenConfirmation()
	{
		// get the raw hotel data
		$hotel_data = $this->getHotel($this->booking->hotel->id);

		// load the plugin
		$this->token_plugin = $this->loadPlugin($this->booking->confirmation_data->plugin);
		if (!$this->token_plugin)
		{
			$this->errors[] = (object) [
					'code' => 'BOOKING_ADD_TOKEN_PLUGIN_NOT_FOUND',
					'data' => (object) ['plugin' => $this->booking->confirmation_data->plugin]
			];
			return false;
		}

		// create the token plugin customer
		$this->booking->confirmation_data->customer = $this->processTokenCrateCustomer($hotel_data->data);
		if (!$this->booking->confirmation_data->customer)
		{
			return false;
		}

		// create a charge if a deposit is needed for confirmation
		if ($this->booking->deposit_amount)
		{
			$this->booking->confirmation_data->deposit_charge = $this->processTokenChargeDeposit($hotel_data->data);
			if (!$this->booking->confirmation_data->deposit_charge)
			{
				return false;
			}
		}

		return true;
	}

	/**
	 * processTokenCrateCustomer
	 */
	private function processTokenCrateCustomer($hotel_data)
	{
		// create the customer
		$helper = $this->token_plugin->helper;
		$plugin_response = $helper::createCustomer($hotel_data, $this->booking);

		// an error occurred
		if (!$plugin_response->data)
		{
			$this->errors[] = (object) [
					'code' => $plugin_response->error,
					'data' => $plugin_response->error_data
			];
			return false;
		}

		return $plugin_response->data;
	}

	/**
	 * processTokenChargeDeposit
	 */
	private function processTokenChargeDeposit($hotel_data)
	{

		// create the customer
		$helper = $this->token_plugin->helper;
		$plugin_response = $helper::chargeCustomer($hotel_data, $this->booking->confirmation_data->customer, $this->booking->deposit_amount, $this->booking->currency, ['booking_id' => $this->booking->id]);

		// an error occurred
		if (!$plugin_response->data)
		{
			$this->errors[] = (object) [
					'code' => $plugin_response->error,
					'data' => $plugin_response->error_data
			];
			return false;
		}

		// set deposit status to payed
		$this->booking->deposit_status = 1;

		// generate the charge object
		return (object) [
				'id' => $this->obtainNewChargeId(),
				'booking_id' => $this->booking->id,
				'created' => $this->booking->created,
				'plugin' => $this->token_plugin->name,
				'plugin_charge_id' => $plugin_response->data->id,
				'amount' => $this->booking->deposit_amount,
				'data' => $plugin_response->data
		];
	}

}
