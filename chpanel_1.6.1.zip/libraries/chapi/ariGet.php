<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Get ARI
 */
class CHApiAriGet extends CHApiAri
{

	private $rooms_ids;
	private $conversion;

	/**
	 * Get the response
	 */
	protected function getResponse()
	{
		// check request
		if (!$this->checkRequest())
		{
			return false;
		}

		// force results
		if (!isset($this->request->force))
		{
			$this->request->force = true;
		}

		// load ari
		$this->loadRoomsIds();
		$this->ari = $this->loadAri($this->rooms_ids, $this->dates);
		$this->ari_rates = $this->loadAriRates($this->rooms_ids, $this->dates);

		// load currency and exchange conversion rate
		$currency = isset($this->request->currency) ? $this->request->currency : $this->hotel->currency;
		$this->conversion = $this->currencyConversion($this->hotel->currency, $currency);

		// build response
		return (object) [
				'dates' => $this->dates,
				'currency' => $currency,
				'hotel_currency' => $this->hotel->currency,
				'hotel_currency_conversion' => $this->conversion,
				'rooms' => $this->loadRoomsData()
		];
	}

	/**
	 * Check the request
	 */
	private function checkRequest()
	{
		// check hotel and dates
		if (!$this->checkHotelAndDates())
		{
			return false;
		}

		// check rooms
		if (!$this->hotel->rooms)
		{
			$this->errors[] = (object) ['code' => 'ARIGET_ROOMS_NOT_FOUND'];
			return false;
		}

		return true;
	}

	/**
	 * Load rooms ids
	 */
	private function loadRoomsIds()
	{
		$this->rooms_ids = CHLibData::loadColumn($this->hotel->rooms);
	}

	/**
	 * Load the rooms data
	 */
	private function loadRoomsData()
	{
		$rooms = [];
		foreach ($this->hotel->rooms as $hotel_room)
		{
			// new room object
			$room = (object) [
					'id' => $hotel_room->id,
					'reference' => $hotel_room->reference,
					'available_units' => [],
					'master_rate' => [],
					'rates' => $this->getRoomRates($hotel_room->id),
			];

			// build ari
			foreach ($this->dates as $date)
			{
				// get room ari
				$ari = $this->getAri($hotel_room->id, $date);

				// available units
				$room->available_units[] = $ari ? (int) $ari->units : ($this->request->force ? 0 : -1);

				// master rate
				$master_rate = $ari ? (float) $ari->rate : ($this->request->force ? (float) $hotel_room->rack_rate : 0);
				$room->master_rate[] = round($master_rate * $this->conversion, 2);

				// set rates ari
				foreach ($room->rates as $rate)
				{
					$ari_rate = $this->getAriRate($room->id, $rate->id, $date);
					$rate->available[] = $ari_rate ? (int) $ari_rate->available : 0;
					$rate->minstay[] = $ari_rate ? (int) $ari_rate->minstay : 1;
					$rate->anticipation[] = $ari_rate ? (int) $ari_rate->anticipation : 0;
				}
			}

			$rooms[] = $room;
		}

		return $rooms;
	}

	/**
	 * get Room Rates
	 * 
	 * @param int $room_id
	 * @return array
	 */
	private function getRoomRates($room_id)
	{
		$mrate = $this->hotel->rates[0];

		$master_rate = (object) [
				'id' => 1,
				'reference' => $mrate->reference,
				'available' => [],
				'minstay' => [],
				'anticipation' => [],
		];

		$rates = [];
		foreach ($this->hotel->rates as $i => $rate)
		{
			if (!$i)
			{
				$rates[] = $master_rate;
				continue;
			}
			if (in_array($room_id, $rate->rooms))
			{
				$new_rate = clone($master_rate);
				$new_rate->id = (int) $rate->id;
				$new_rate->reference = $rate->reference;
				$rates[] = $new_rate;
			}
		}

		return $rates;
	}

	/**
	 * Get the room ari
	 * 
	 * @param int $room_id
	 * @param string $date
	 * @return mixed
	 */
	private function getAri($room_id, $date)
	{
		foreach ($this->ari as $ari)
		{
			if ($ari->date == $date && $ari->room_id == $room_id)
			{
				return $ari;
			}
		}
		return false;
	}

	/**
	 * Get the rate ari
	 * 
	 * @param int $room_id
	 * @param int $rate_id
	 * @param string $date
	 * @return mixed
	 */
	private function getAriRate($room_id, $rate_id, $date)
	{
		foreach ($this->ari_rates as $ari)
		{
			if ($ari->date == $date && $ari->room_id == $room_id && $ari->rate_id == $rate_id)
			{
				return $ari;
			}
		}
		return false;
	}

}
