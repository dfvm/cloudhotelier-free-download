<?php
/**
 * @package		CHAssets
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * CloudHotelier Assets Helper
 */
class CHAssets
{

	/**
	 * Attach chassets to global application object if not present
	 */
	static function getApp()
	{

		// get joomla app and return if chassets is already loaded
		$app = JFactory::getApplication();
		if (isset($app->chassets))
		{
			return $app;
		}

		// init chassets
		$app->chassets = (object) [
				'styles' => [],
				'scripts' => [],
				'uikit_components' => [],
				'style_declarations' => [],
				'script_declarations' => []
		];

		return $app;
	}

	/**
	 * Add a style to the document
	 * 
	 * @param string $media
	 * @param string $style
	 */
	static function style($media, $style)
	{
		$app = self::getApp();
		$app->chassets->styles[] = (object) ['media' => $media, 'style' => $style];
	}

	/**
	 * Add a script to the document
	 * @param string $media
	 * @param string $script
	 */
	static function script($media, $script)
	{
		$app = self::getApp();
		$app->chassets->scripts[] = (object) ['media' => $media, 'script' => $script];
	}

	/**
	 * Add a uikit component
	 * @param string $component
	 */
	static function uikit_component($component)
	{
		$app = self::getApp();

		// htmleditor extra assets
		if (in_array($component, ['htmleditor', 'htmleditor-comment', 'htmleditor-text', 'htmleditor-advanced']))
		{
			$app->chassets->uikit_components[] = 'htmleditor';

			// load assets
			CHAssets::style(false, 'media/chassets/htmleditor/codemirror/lib/codemirror.css');
			CHAssets::script(false, 'media/chassets/htmleditor/codemirror/lib/codemirror.js');
			CHAssets::script(false, 'media/chassets/htmleditor/codemirror/mode/markdown/markdown.js');
			CHAssets::script(false, 'media/chassets/htmleditor/codemirror/addon/mode/overlay.js');
			CHAssets::script(false, 'media/chassets/htmleditor/codemirror/mode/xml/xml.js');
			CHAssets::script(false, 'media/chassets/htmleditor/codemirror/mode/gfm/gfm.js');
			CHAssets::script(false, 'media/chassets/htmleditor/marked/lib/marked.js');
			if ($component == 'htmleditor')
			{
				CHAssets::script(false, 'media/chassets/htmleditor/ch.htmleditor.basic.js');
			}
			else
			{
				$type = explode('-', $component);
				CHAssets::script(false, "media/chassets/htmleditor/ch.htmleditor.{$type[1]}.js");
			}
		}
		elseif ($component == 'grid')
		{
			CHAssets::script(false, 'media/chassets/grid/ch.grid.js');
		}
		else
		{
			$app->chassets->uikit_components[] = $component;
		}
	}

	/**
	 * Add uikit components
	 * @param array $components
	 */
	static function uikit_components($components = [])
	{
		foreach ($components as $component)
		{
			self::uikit_component($component);
		}
	}

	/**
	 * Add a inline style declaration to the document
	 * @param string $code
	 */
	static function style_declaration($code)
	{
		$app = self::getApp();
		$app->chassets->style_declarations[] = $code;
	}

	/**
	 * Add a inline script declaration to the document
	 * @param string $code
	 */
	static function script_declaration($code)
	{
		$app = self::getApp();
		$app->chassets->script_declarations[] = $code;
	}

}
