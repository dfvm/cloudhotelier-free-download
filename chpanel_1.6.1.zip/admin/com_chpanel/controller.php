<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * CHPanel Main Controller
 */
class CHPanelController extends JControllerLegacy
{

	/**
	 * Display the view
	 */
	public function display($cachable = false, $urlparams = false)
	{
		CHLib::input()->set('view', CHLib::input()->get('view', 'users'));
		parent::display($cachable, $urlparams);
	}

}
