<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * CHPanel Helper
 */
class CHPanelHelper
{

	/**
	 * Return component views
	 */
	public static function getViews()
	{
		return array('users');
	}

	/**
	 * Create Submenu
	 */
	public static function addSubmenu($vName)
	{

		foreach (self::getViews() as $view)
		{
			JHtmlSidebar::addEntry(JText::_('COM_CHPANEL_VIEW_' . strtoupper($view)), 'index.php?option=com_chpanel&view=' . $view, $vName == $view);
		}
	}

	/**
	 * Toolbar Helper
	 */
	public static function getToolbar($view = '', $show = false, $title = false)
	{

		// set view
		$view = $view ? $view : JRequest::getWord('view', 'panel');

		// view type
		if (substr($view, -1) == 's' || $view == 'panel')
		{
			$controller = substr($view, 0, -1);
			$controller_list = $view;
			$list = true;
			self::addSubmenu($view);
		}
		else
		{
			$controller = $view;
			$controller_list = $view . 's';
			$list = false;
		}

		// load assets
		JHtml::_('behavior.framework');
		JHtml::_('behavior.formvalidation');
		JHtml::_('bootstrap.framework');

		// page title
		$title = $title ? $title : $title = 'CloudHotelier Panel Pro: ' . JText::_('COM_CHPANEL_VIEW_' . strtoupper($view));
		JToolBarHelper::title($title, $view);
		JFactory::getDocument()->setTitle('CHPanel: ' . $title);

		// buttons
		if ($list && $view != 'panel')
		{

			// new item
			JToolBarHelper::custom($controller . '.edit', 'new.png', 'new_f2.png', 'JTOOLBAR_NEW', false);

			// publish state
			JToolBarHelper::custom($controller_list . '.publish', 'publish.png', 'publish_f2.png', 'JTOOLBAR_PUBLISH', true);
			JToolBarHelper::custom($controller_list . '.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);

			// delete / trash
			if ($show)
			{
				JToolBarHelper::custom($controller_list . '.delete', 'delete.png', 'delete_f2.png', 'JTOOLBAR_DELETE', true);
			}
			else
			{
				JToolBarHelper::trash($controller_list . '.trash', 'JTOOLBAR_TRASH');
			}
		}

		if ($view == 'panel')
		{
			JToolBarHelper::preferences('com_chpanel');
		}

		if (!$list)
		{
			JToolBarHelper::apply($controller . '.apply', 'JTOOLBAR_APPLY');
			JToolBarHelper::save($controller . '.save');
			JToolBarHelper::cancel($controller . '.cancel');
			JRequest::setVar('hidemainmenu', true);
		}
	}

	/**
	 * ControlGroup for param
	 * @param type $params
	 * @param type $field
	 * @return type
	 */
	public static function getControlGroup($params, $field, $multiple = false)
	{
		return '<div class="control-group"><div class="control-label">' . $params['jform_params_' . $field]->label . '</div><div class="controls">' . $params['jform_params_' . $field]->input . '</div></div>';
	}

}
