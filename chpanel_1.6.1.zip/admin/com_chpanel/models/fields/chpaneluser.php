<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

// import formfield 
jimport('joomla.form.formfield');

/**
 * CHPanelUser
 */
class JFormFieldCHPanelUser extends JFormField
{

	/**
	 * CHPanelUser form field type
	 */
	protected $type = 'CHPanelUser';

	/**
	 * Generate input
	 */
	public function getInput()
	{

		// get options
		$db = JFactory::getDbo();
		$query = 'SELECT `id`, `last_name` AS `value` FROM `#__chpanel_users` ORDER BY `last_name`';
		$items = $db->setQuery($query)->loadObjectList();

		// generate select
		$default = new stdClass();
		$default->id = '';
		$default->value = JText::_('COM_CHPANEL_ANY_SELECT_USER');
		return JHtml::_('select.genericlist', array_merge(array($default), $items), $this->name, 'class="inputbox"', 'id', 'value', $this->value, $this->id);
	}

}
