<?php
/**
 * @package		CHClient
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

// require formfield
jimport('joomla.form.formfield');
JFormHelper::loadFieldClass('text');

/**
 * CloudHotelier License Key
 */
class JFormFieldCHLicense extends JFormFieldText
{

	/**
	 * The field type
	 */
	protected $type = 'CHLicense';
	private $extension = 'COM_CHPANEL';

	/**
	 * Get the data and render the select
	 */
	public function getInput()
	{
		$db = JFactory::getDbo();

		// get the extension id
		$query_extension = $db->getQuery(true)
			->select('extension_id')
			->from($db->qn('#__extensions'))
			->where($db->qn('name') . ' = ' . $db->q($this->extension));
		$extension_id = $db->setQuery($query_extension)->loadResult();
		if (!$extension_id)
		{
			// return input
			return parent::getInput();
		}

		// load the update site id
		$query_update_site = $db->getQuery(true)
			->select('update_site_id')
			->from($db->qn('#__update_sites_extensions'))
			->where($db->qn('extension_id') . ' = ' . $db->q($extension_id));
		$update_site_id = $db->setQuery($query_update_site)->loadResult();
		if (!$update_site_id)
		{
			// return input
			return parent::getInput();
		}

		// set extra_query to the the update site
		$update_site = (object) [
				'update_site_id' => $update_site_id,
				'extra_query' => 'license_key=' . urlencode($this->value),
				'enabled' => 1,
				'last_check_timestamp' => 0
		];
		$db->updateObject('#__update_sites', $update_site, 'update_site_id');

		// flush updates cache
		$query_delete = $db->getQuery(true)
			->delete($db->qn('#__updates'))
			->where($db->qn('update_site_id') . ' = ' . $db->q($update_site_id));
		$db->setQuery($query_delete)->execute();

		// return input
		return parent::getInput();
	}

}
