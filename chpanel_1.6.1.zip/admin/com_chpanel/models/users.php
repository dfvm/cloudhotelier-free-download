<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * Users Model
 */
class CHPanelModelUsers extends JModelList
{

	/**
	 * Constructor
	 */
	public function __construct($config = [])
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'a.id',
				'a.created',
				'a.state'
			);
		}

		parent::__construct($config);
	}

	/**
	 * State
	 */
	protected function populateState($ordering = null, $direction = null)
	{

		$filters = array('search');

		foreach ($filters as $filter)
		{
			$var = $this->getUserStateFromRequest($this->context . '.filter.' . $filter, 'filter_' . $filter);
			$this->setState('filter.' . $filter, $var);
		}

		parent::populateState('a.created', 'DESC');
	}

	/**
	 * Filters
	 */
	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');
		return parent::getStoreId($id);
	}

	/**
	 * Query
	 */
	protected function getListQuery()
	{

		// main query
		$query = $this->_db->getQuery(true);
		$query->select('a.*');
		$query->from('#__chpanel_users AS a');

		// join over the users
		$query->select('b.name AS title, b.email, b.registerDate, b.lastvisitDate');
		$query->join('LEFT', '#__users AS b ON b.id = a.joomla_id');

		// only active users
		$query->where('b.block = 0');
		
		// super administrators only
		$query->where('a.type = 1');

		// filter by search in name
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $this->_db->Quote('%' . $this->_db->escape($search, true) . '%');
				$query->where('(a.name LIKE ' . $search . ' OR a.surname LIKE ' . $search . ' OR b.name LIKE ' . $search . ' OR b.email LIKE ' . $search . ')');
			}
		}

		// add the list ordering clause
		$orderCol = $this->state->get('list.ordering');
		$orderDirn = $this->state->get('list.direction');
		$query->order($this->_db->escape($orderCol . ' ' . $orderDirn));

		return $query;
	}

}
