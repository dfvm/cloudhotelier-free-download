<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * User Model
 */
class CHPanelModelUser extends JModelAdmin
{

	/**
	 * Get the table
	 */
	public function getTable($type = 'User', $prefix = 'CHPanelTable', $config = [])
	{
		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * get the form
	 */
	public function getForm($data = [], $loadData = true)
	{
		$form = $this->loadForm('com_chpanel.user', 'user', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}

	/**
	 * Get the data that should be injected to the form
	 */
	protected function loadFormData()
	{
		$data = JFactory::getApplication()->getUserState('com_chpanel.edit.user.data', []);
		if (empty($data))
		{
			$data = $this->getItem();
		}

		return $data;
	}

	/**
	 * Override get Item Method to Join J! User
	 */
	public function getItem($pk = null)
	{

		if (!isset($this->item))
		{

			$pk = (!empty($pk)) ? $pk : (int) $this->getState($this->getName() . '.id');

			if ($pk > 0)
			{
				// main query
				$query = $this->_db->getQuery(true);
				$query->select('a.*')->from('#__chpanel_users AS a');
				$query->select('b.email');
				$query->leftJoin('#__users AS b ON b.id = a.joomla_id');
				$query->where("a.id = $pk");
				$this->_db->setQuery($query);
				$result = $this->_db->loadAssoc();
				$this->item = JArrayHelper::toObject($result, 'JObject');
			}
			else
			{
				$this->item = parent::getItem();
			}
		}

		return $this->item;
	}

	/**
	 * Extend save method to add J! User actions
	 */
	public function save($data)
	{
		// get the table
		$table = $this->getTable();

		// check isNew
		$key = $table->getKeyName();
		$pk = (!empty($data[$key])) ? $data[$key] : (int) $this->getState($this->getName() . '.id');
		$isNew = true;
		if ($pk > 0)
		{
			$table->load($pk);
			$isNew = false;
		}

		// bind
		if (!$table->bind($data))
		{
			$this->setError($table->getError());
			return false;
		}

		// check
		if (!$table->check())
		{
			$this->setError($table->getError());
			return false;
		}

		// check if the user exists
		$joomla_id = $table->joomla_id ? $table->joomla_id : 0;

		// check, save or update joomla user before store
		$juser = $this->saveJoomlaUser($joomla_id, $data);
		if (!$juser)
		{
			return false;
		}

		// save chpanel user
		$table->joomla_id = $juser->id;
		if (!$table->store())
		{
			$this->setError($table->getError());
			return false;
		}

		// set state
		$pkName = $table->getKeyName();
		if (isset($table->$pkName))
		{
			$this->setState($this->getName() . '.id', $table->$pkName);
		}
		$this->setState($this->getName() . '.new', $isNew);

		return true;
	}

	/**
	 * Create or update a joomla user
	 */
	private function saveJoomlaUser($joomla_id, $data)
	{

		// prepare to save    
		$juser_data = [];

		// get the user
		$juser = JFactory::getUser($joomla_id);
		if ($joomla_id)
		{
			$juser_data['groups'] = false; // do not update groups
		}
		else
		{
			$params = JComponentHelper::getParams('com_users');
			$juser_data['groups'][1] = $params->get('new_usertype', 2); // set default user group
		}

		// save email, username & name
		$juser_data['email'] = $data['email'];
		if ($data['password'])
		{
			$juser_data['password'] = $data['password'];
			$juser_data['password1'] = $data['password'];
			$juser_data['password2'] = $data['password'];
		}
		$juser_data['username'] = $data['email'];
		$juser_data['name'] = $data['first_name'] . ' ' . $data['last_name'];

		// bind joomla user the data
		if (!$juser->bind($juser_data))
		{
			$this->setError($juser->getError());
			return false;
		}

		// save joomla user data
		if (!$juser->save())
		{
			$this->setError($juser->getError());
			return false;
		}

		return $juser;
	}

}
