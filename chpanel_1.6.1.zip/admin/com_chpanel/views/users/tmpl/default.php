<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

JHtml::_('formbehavior.chosen', 'select');

$context = 'users';
$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn = $this->escape($this->state->get('list.direction'));
$archived = $this->state->get('filter.state') == 2 ? true : false;
$trashed = $this->state->get('filter.state') == -2 ? true : false;
?>

<!-- adminForm -->
<form action="<?php echo JRoute::_('index.php?option=com_chpanel&view=' . $context); ?>" method="post" name="adminForm" id="adminForm">

    <!-- sidebar -->
    <div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
    </div>

    <!-- main -->
    <div id="j-main-container" class="span12">

        <!-- search tools -->
		<?php echo JLayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>

        <!-- no items -->
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-no-items">
				You need to create at least one super user
			</div>
		<?php endif; ?>

        <!-- items table -->
		<?php if ($this->items) : ?>

			<table class="table table-striped" id="articleList">

				<thead>
					<tr>
						<th width="1%" class="nowrap hidden-phone">
							<?php echo JHtml::_('grid.checkall'); ?>
						</th> 
						<th class="nowrap">
							Name
						</th>
						<th class="nowrap">
							Email
						</th>      
						<th class="nowrap">
							Language
						</th>      
						<th class="nowrap center">
							Created
						</th>
						<th class="nowrap center">
							Last access
						</th>
						<th class="nowrap center" width="1%">
							<?php echo JHtml::_('searchtools.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
						</th>
					</tr>
				</thead>

				<tfoot>
					<tr>
						<td colspan="30">
							<?php echo $this->pagination->getListFooter(); ?>
						</td>
					</tr>
				</tfoot>

				<tbody>

					<?php foreach ($this->items as $i => $item) : ?>

						<?php
						$canChange = true;
						$canCheckin = true;
						?>

						<tr class="row<?php echo $i % 2; ?>" sortable-group-id="<?php echo $item->catid; ?>">

							<td class="nowrap center hidden-phone">
								<?php echo JHtml::_('grid.id', $i, $item->id); ?>
							</td>

							<td class="nowrap">
								<div class="pull-left">
									<?php if ($item->checked_out) : ?>
										<?php echo JHtml::_('jgrid.checkedout', $i, $item->editor, $item->checked_out_time, $context . '.', $canCheckin); ?>
									<?php endif; ?>
									<a href="<?php echo JRoute::_('index.php?option=com_chpanel&task=user.edit&id=' . $item->id); ?>">
										<?php echo $this->escape($item->title); ?>
									</a>
								</div>
							</td>

							<td class="nowrap small">
								<?php echo $this->escape($item->email); ?>
							</td>   

							<td class="nowrap small">
								<?php echo $this->escape($item->language); ?>
							</td>

							<td class="nowrap center small">
								<?php echo JHtml::_('date', $item->created, JText::_('DATE_FORMAT_LC4')); ?>
							</td>

							<td class="nowrap center small">
								<?php if ($item->lastvisitDate != '0000-00-00 00:00:00'): ?>
									<?php echo JHtml::_('date', $item->lastvisitDate, 'Y-m-d H:i:s'); ?>
								<?php else: ?>
									<?php echo JText::_('JNEVER'); ?>
								<?php endif; ?>
							</td>

							<td class="nowrap center small">
								<?php echo $item->id; ?>
							</td>

						</tr>

					<?php endforeach; ?>

				</tbody>


			</table>

		<?php endif; ?>

    </div>

    <!-- form fields -->
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="boxchecked" value="0" />
	<?php echo JHtml::_('form.token'); ?>

</form>