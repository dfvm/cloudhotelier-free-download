<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

// behavior
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');
?>

<!-- adminForm -->
<form action="<?php echo JRoute::_('index.php?option=com_chpanel&view=user&layout=edit&id=' . (int) $this->item->id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate" enctype="multipart/form-data">

    <!-- form fields -->
    <input type="hidden" name="task" value="" />
	<?php echo JHtml::_('form.token'); ?>

    <!-- fake auto-fill password -->
    <div class="hidden">
        <input name="fake-username" type="text">
        <input name="fake-password" type="password">
    </div>

    <!-- main -->
    <div class="row-fluid">

        <div class="span9">

            <!-- info -->
            <div class="form-horizontal">
                <fieldset>
					<?php foreach (array('first_name', 'last_name', 'email', 'password', 'language', 'type') as $field): ?>
						<?php echo $this->form->getControlGroup($field); ?>
					<?php endforeach; ?>
                </fieldset>
            </div>

            <div class="form-horizontal">
                <fieldset>
					<?php foreach (array('status') as $field): ?>
						<?php echo $this->form->getControlGroup($field); ?>
					<?php endforeach; ?>
                </fieldset>
            </div>

        </div>

        <!-- sidebar -->
        <div class="span3">

            <!-- publishing -->
            <div class="well">
                <h3>Registro</h3>
				<?php foreach (array('joomla_id', 'created', 'id') as $field): ?>
					<?php echo $this->form->getControlGroup($field); ?>
				<?php endforeach; ?>
            </div>

        </div>
        <!-- /sidebar -->

    </div>
    <!-- /main -->

</form>
<!-- /adminForm -->
