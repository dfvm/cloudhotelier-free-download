<?php
/**
 * @package		CHPanel
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

JLoader::import('joomla.filesystem.folder');
JLoader::import('joomla.filesystem.file');

class Com_CHPanelInstallerScript
{

	private $php_version = '5.4.3';

	/**
	 * installation_queue
	 * @var array 
	 */
	private $installation_queue = array(
		'modules' => array(
			'admin' => array(),
			'site' => array()
		),
		'plugins' => array(
			'chpanel' => array(
				'stripe' => 1,
			),
			'system' => array(
				'chassets' => 1,
				'chmailgun' => 1,
			)
		),
		'libraries' => array(
			'chlib',
			'chassets',
			'chapi',
			'chadmin',
		),
		'templates' => array(
			'chadmin'
		)
	);

	/**
	 * uninstallation_queue
	 * @var array 
	 */
	private $uninstallation_queue = array(
		'modules' => array(
			'admin' => array(),
			'site' => array()
		),
		'plugins' => array(
			'chpanel' => array(
				'stripe' => 1
			)
		),
		'libraries' => array(
			'chapi',
		),
		'templates' => array(
			'chadmin'
		)
	);

	/**
	 * Check the database
	 */
	function update($parent)
	{
		$db = JFactory::getDBO();
		$prefix = $db->getPrefix();
		$tables = $db->getTableList();

		// check apps_hotels table
		if (!in_array("{$prefix}chpanel_apps_hotels", $tables))
		{
			$db->setQuery("CREATE TABLE `#__chpanel_apps_hotels` (`app_id` int(10) NOT NULL, `hotel_id` int(10) NOT NULL, KEY `app_id` (`app_id`), KEY `hotel_id` (`hotel_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();
		}

		// check token in users
		$users_columns = $db->getTableColumns('#__chpanel_users');
		if (!isset($users_columns['token']))
		{
			$db->setQuery('ALTER TABLE `#__chpanel_users` ADD `token` TEXT NOT NULL AFTER `data`')->execute();
		}

		// check suspended in users
		if (!isset($users_columns['suspended']))
		{
			// get suspended apps ids
			$suspended_apps_ids = $db->setQuery('SELECT a.id FROM #__chpanel_apps AS a WHERE a.suspended = 1')->loadColumn();

			// alter database
			$db->setQuery("ALTER TABLE `#__chpanel_users` ADD `suspended` TINYINT(1) NOT NULL DEFAULT '0' AFTER `token`")->execute();
			$db->setQuery("ALTER TABLE `#__chpanel_apps` DROP `suspended`")->execute();

			if (!$suspended_apps_ids)
			{
				return;
			}

			// get users with suspended apps
			$q_suspended_apps_ids = implode(', ', $suspended_apps_ids);
			$users_width_suspended_apps = $db->setQuery("SELECT a.user_id FROM #__chpanel_users_apps AS a WHERE a.app_id IN ($q_suspended_apps_ids)")->loadColumn();
			if (!$users_width_suspended_apps)
			{
				return;
			}

			// suspend users
			$q_users_width_suspended_apps = implode(', ', array_unique($users_width_suspended_apps));
			$db->setQuery("UPDATE #__chpanel_users SET suspended=1 WHERE id IN ($q_users_width_suspended_apps)")->execute();
		}

		// v 1.6.1
		$apps_columns = $db->getTableColumns('#__chpanel_apps');
		if (!isset($apps_columns['log_search']))
		{
			$db->setQuery('ALTER TABLE `#__chpanel_apps` ADD `log_search` TINYINT(1) NOT NULL AFTER `reference`')->execute();
			$db->setQuery('ALTER TABLE `#__chpanel_alogs` ADD INDEX(`created`)')->execute();
			$db->setQuery('ALTER TABLE `#__chpanel_ulogs` ADD INDEX(`created`)')->execute();
			$db->setQuery('ALTER TABLE `#__chpanel_alogs` ADD INDEX(`task`)')->execute();
			$db->setQuery('ALTER TABLE `#__chpanel_ulogs` ADD INDEX(`task`)')->execute();
		}
	}

	/**
	 * Check php version
	 */
	function preflight($type, $parent)
	{
		if (version_compare(PHP_VERSION, $this->php_version, '<'))
		{
			Jerror::raiseWarning(null, 'Sorry, you are using and old php version: ' . PHP_VERSION . '. At least php version ' . $this->php_version . ' is required.');
			return false;
		}
	}

	/**
	 * Postflight
	 */
	function postflight($type, $parent)
	{
		// Install subextensions
		$status = $this->_installSubextensions($parent);

		// Install status
		echo '<div class="alert alert-info">';
		echo '<p><span class="icon-checkmark-circle">&nbsp;</span> Main Extension</p>';
		foreach (array('modules', 'plugins', 'libraries', 'templates') as $type)
		{
			if ($status->$type)
			{
				echo '<p>' . ucfirst($type) . ': ';
				foreach ($status->$type as $item)
				{
					echo '<br> ' . ($item['result'] ? '<span class="icon-checkmark-circle">&nbsp;</span>' : '<span class="icon-cancel-circle">&nbsp;</span>') . ' ' . $item['name'];
				}
				echo '</p>';
			}
		}
		echo '</div>';
	}

	/**
	 * Uninstall
	 */
	function uninstall($parent)
	{

		// Uninstall subextensions
		$status = $this->_uninstallSubextensions($parent);

		// Install status
		echo '<div class="alert alert-info">';
		echo '<p><span class="icon-checkmark-circle">&nbsp;</span> Main Extension</p>';
		foreach (array('modules', 'plugins', 'libraries', 'templates') as $type)
		{
			if ($status->$type)
			{
				echo '<p>' . ucfirst($type) . ': ';
				foreach ($status->$type as $item)
				{
					echo '<br> ' . ($item['result'] ? '<span class="icon-checkmark-circle">&nbsp;</span>' : '<span class="icon-cancel-circle">&nbsp;</span>') . ' ' . $item['name'];
				}
				echo '</p>';
			}
		}
		echo '</div>';
	}

	/**
	 * Installs subextensions (modules, plugins) bundled with the main extension
	 *
	 * @param JInstaller $parent
	 *
	 * @return JObject The subextension installation status
	 */
	private function _installSubextensions($parent)
	{

		$src = $parent->getParent()->getPath('source');

		$db = JFactory::getDbo();

		$status = new JObject();
		$status->modules = array();
		$status->plugins = array();
		$status->libraries = array();
		$status->templates = array();

		// Modules installation
		if (count($this->installation_queue['modules']))
		{
			foreach ($this->installation_queue['modules'] as $folder => $modules)
			{
				if (count($modules))
				{
					foreach ($modules as $module => $modulePreferences)
					{
						// Install the module
						if (empty($folder))
						{
							$folder = 'site';
						}

						$path = "$src/modules/$folder/$module";

						if (!is_dir($path))
						{
							$path = "$src/modules/$folder/mod_$module";
						}

						if (!is_dir($path))
						{
							$path = "$src/modules/$module";
						}

						if (!is_dir($path))
						{
							$path = "$src/modules/mod_$module";
						}

						if (!is_dir($path))
						{
							continue;
						}

						// Was the module already installed?
						$sql = $db->getQuery(true)
							->select('COUNT(*)')
							->from('#__modules')
							->where($db->qn('module') . ' = ' . $db->q('mod_' . $module));
						$db->setQuery($sql);

						try
						{
							$count = $db->loadResult();
						}
						catch (Exception $exc)
						{
							$count = 0;
						}

						$installer = new JInstaller;
						$result = $installer->install($path);
						$status->modules[] = array(
							'name' => 'mod_' . $module,
							'client' => $folder,
							'result' => $result
						);

						// Modify where it's published and its published state
						if (!$count)
						{
							// A. Position and state
							list($modulePosition, $modulePublished) = $modulePreferences;

							if ($modulePosition == 'cpanel')
							{
								$modulePosition = 'icon';
							}

							$sql = $db->getQuery(true)
								->update($db->qn('#__modules'))
								->set($db->qn('position') . ' = ' . $db->q($modulePosition))
								->where($db->qn('module') . ' = ' . $db->q('mod_' . $module));

							if ($modulePublished)
							{
								$sql->set($db->qn('published') . ' = ' . $db->q('1'));
							}

							$db->setQuery($sql);

							try
							{
								$db->execute();
							}
							catch (Exception $exc)
							{
								// Nothing
							}

							// B. Change the ordering of back-end modules to 1 + max ordering
							if ($folder == 'admin')
							{
								try
								{
									$query = $db->getQuery(true);
									$query->select('MAX(' . $db->qn('ordering') . ')')
										->from($db->qn('#__modules'))
										->where($db->qn('position') . '=' . $db->q($modulePosition));
									$db->setQuery($query);
									$position = $db->loadResult();
									$position++;

									$query = $db->getQuery(true);
									$query->update($db->qn('#__modules'))
										->set($db->qn('ordering') . ' = ' . $db->q($position))
										->where($db->qn('module') . ' = ' . $db->q('mod_' . $module));
									$db->setQuery($query);
									$db->execute();
								}
								catch (Exception $exc)
								{
									// Nothing
								}
							}

							// C. Link to all pages
							try
							{
								$query = $db->getQuery(true);
								$query->select('id')->from($db->qn('#__modules'))
									->where($db->qn('module') . ' = ' . $db->q('mod_' . $module));
								$db->setQuery($query);
								$moduleid = $db->loadResult();

								$query = $db->getQuery(true);
								$query->select('*')->from($db->qn('#__modules_menu'))
									->where($db->qn('moduleid') . ' = ' . $db->q($moduleid));
								$db->setQuery($query);
								$assignments = $db->loadObjectList();
								$isAssigned = !empty($assignments);
								if (!$isAssigned)
								{
									$o = (object) array(
											'moduleid' => $moduleid,
											'menuid' => 0
									);
									$db->insertObject('#__modules_menu', $o);
								}
							}
							catch (Exception $exc)
							{
								// Nothing
							}
						}
					}
				}
			}
		}

		// Plugins installation
		if (count($this->installation_queue['plugins']))
		{
			foreach ($this->installation_queue['plugins'] as $folder => $plugins)
			{
				if (count($plugins))
				{
					foreach ($plugins as $plugin => $published)
					{
						$path = "$src/plugins/$folder/$plugin";

						if (!is_dir($path))
						{
							$path = "$src/plugins/$folder/plg_$plugin";
						}

						if (!is_dir($path))
						{
							$path = "$src/plugins/$plugin";
						}

						if (!is_dir($path))
						{
							$path = "$src/plugins/plg_$plugin";
						}

						if (!is_dir($path))
						{
							continue;
						}

						// Was the plugin already installed?
						$query = $db->getQuery(true)
							->select('COUNT(*)')
							->from($db->qn('#__extensions'))
							->where($db->qn('element') . ' = ' . $db->q($plugin))
							->where($db->qn('folder') . ' = ' . $db->q($folder));
						$db->setQuery($query);

						try
						{
							$count = $db->loadResult();
						}
						catch (Exception $exc)
						{
							$count = 0;
						}

						$installer = new JInstaller;
						$result = $installer->install($path);

						$status->plugins[] = array('name' => 'plg_' . $folder . '_' . $plugin, 'group' => $folder, 'result' => $result);

						if ($published && !$count)
						{
							$query = $db->getQuery(true)
								->update($db->qn('#__extensions'))
								->set($db->qn('enabled') . ' = ' . $db->q('1'))
								->where($db->qn('element') . ' = ' . $db->q($plugin))
								->where($db->qn('folder') . ' = ' . $db->q($folder));
							$db->setQuery($query);

							try
							{
								$db->execute();
							}
							catch (Exception $exc)
							{
								// Nothing
							}
						}
					}
				}
			}
		}

		// Libraries installation
		if (count($this->installation_queue['libraries']))
		{
			foreach ($this->installation_queue['libraries'] as $library)
			{

				$path = "$src/libraries/$library";

				if (!is_dir($path))
				{
					continue;
				}

				$installer = new JInstaller;
				$result = $installer->install($path);

				$status->libraries[] = array('name' => $library, 'result' => $result);
			}
		}

		// Templates installation
		if (count($this->installation_queue['templates']))
		{
			foreach ($this->installation_queue['templates'] as $template)
			{

				$path = "$src/templates/$template";

				if (!is_dir($path))
				{
					continue;
				}

				$installer = new JInstaller;
				$result = $installer->install($path);

				$status->templates[] = array('name' => $template, 'result' => $result);
			}
		}

		return $status;
	}

	/**
	 * Uninstalls subextensions (modules, plugins) bundled with the main extension
	 *
	 * @param JInstaller $parent
	 *
	 * @return JObject The subextension uninstallation status
	 */
	private function _uninstallSubextensions($parent)
	{

		JLoader::import('joomla.installer.installer');

		$db = JFactory::getDBO();

		$status = new JObject();
		$status->modules = array();
		$status->plugins = array();

		$src = $parent->getParent()->getPath('source');

		// Modules uninstallation
		if (count($this->uninstallation_queue['modules']))
		{
			foreach ($this->uninstallation_queue['modules'] as $folder => $modules)
			{
				if (count($modules))
				{
					foreach ($modules as $module => $modulePreferences)
					{
						// Find the module ID
						$sql = $db->getQuery(true)
							->select($db->qn('extension_id'))
							->from($db->qn('#__extensions'))
							->where($db->qn('element') . ' = ' . $db->q($module))
							->where($db->qn('type') . ' = ' . $db->q('module'));
						$db->setQuery($sql);

						try
						{
							$id = $db->loadResult();
						}
						catch (Exception $exc)
						{
							$id = 0;
						}

						// Uninstall the module
						if ($id)
						{
							$installer = new JInstaller;
							$result = $installer->uninstall('module', $id, 1);
							$status->modules[] = array(
								'name' => 'mod_' . $module,
								'client' => $folder,
								'result' => $result
							);
						}
					}
				}
			}
		}

		// Plugins uninstallation
		if (count($this->uninstallation_queue['plugins']))
		{
			foreach ($this->uninstallation_queue['plugins'] as $folder => $plugins)
			{
				if (count($plugins))
				{
					foreach ($plugins as $plugin => $published)
					{
						$sql = $db->getQuery(true)
							->select($db->qn('extension_id'))
							->from($db->qn('#__extensions'))
							->where($db->qn('type') . ' = ' . $db->q('plugin'))
							->where($db->qn('element') . ' = ' . $db->q($plugin))
							->where($db->qn('folder') . ' = ' . $db->q($folder));
						$db->setQuery($sql);

						try
						{
							$id = $db->loadResult();
						}
						catch (Exception $exc)
						{
							$id = 0;
						}

						if ($id)
						{
							$installer = new JInstaller;
							$result = $installer->uninstall('plugin', $id, 1);
							$status->plugins[] = array(
								'name' => 'plg_' . $plugin,
								'group' => $folder,
								'result' => $result
							);
						}
					}
				}
			}
		}

		// Libraries uninstallation
		if (count($this->uninstallation_queue['libraries']))
		{
			foreach ($this->uninstallation_queue['libraries'] as $library)
			{

				$sql = $db->getQuery(true)
					->select($db->qn('extension_id'))
					->from($db->qn('#__extensions'))
					->where($db->qn('type') . ' = ' . $db->q('library'))
					->where($db->qn('element') . ' = ' . $db->q($library));
				$db->setQuery($sql);

				try
				{
					$id = $db->loadResult();
				}
				catch (Exception $exc)
				{
					$id = 0;
				}

				if ($id)
				{
					$installer = new JInstaller;
					$result = $installer->uninstall('library', $id, 1);
					$status->libraries[] = array(
						'name' => $library,
						'result' => $result
					);
				}
			}
		}


		// Templates uninstallation
		if (count($this->uninstallation_queue['templates']))
		{
			foreach ($this->uninstallation_queue['templates'] as $template)
			{

				$sql = $db->getQuery(true)
					->select($db->qn('extension_id'))
					->from($db->qn('#__extensions'))
					->where($db->qn('type') . ' = ' . $db->q('template'))
					->where($db->qn('element') . ' = ' . $db->q($template));
				$db->setQuery($sql);

				try
				{
					$id = $db->loadResult();
				}
				catch (Exception $exc)
				{
					$id = 0;
				}

				if ($id)
				{
					$installer = new JInstaller;
					$result = $installer->uninstall('template', $id, 1);
					$status->templates[] = array(
						'name' => $template,
						'result' => $result
					);
				}
			}
		}

		return $status;
	}

}
