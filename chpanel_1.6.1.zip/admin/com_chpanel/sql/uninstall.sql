# ************************************************************
# CHPanel - Admin Panel Pro
# Copyright (C) CloudHotelier. All rights reserved.
# ************************************************************

DROP TABLE IF EXISTS `#__chpanel_alogs`;
DROP TABLE IF EXISTS `#__chpanel_apps`;
DROP TABLE IF EXISTS `#__chpanel_ari`;
DROP TABLE IF EXISTS `#__chpanel_ari_rates`;
DROP TABLE IF EXISTS `#__chpanel_bookings`;
DROP TABLE IF EXISTS `#__chpanel_bookings_charges`;
DROP TABLE IF EXISTS `#__chpanel_bookings_discounts`;
DROP TABLE IF EXISTS `#__chpanel_bookings_extras`;
DROP TABLE IF EXISTS `#__chpanel_bookings_rooms`;
DROP TABLE IF EXISTS `#__chpanel_discounts`;
DROP TABLE IF EXISTS `#__chpanel_extras`;
DROP TABLE IF EXISTS `#__chpanel_hotels`;
DROP TABLE IF EXISTS `#__chpanel_inventory`;
DROP TABLE IF EXISTS `#__chpanel_packs`;
DROP TABLE IF EXISTS `#__chpanel_photos`;
DROP TABLE IF EXISTS `#__chpanel_rates`;
DROP TABLE IF EXISTS `#__chpanel_rooms`;
DROP TABLE IF EXISTS `#__chpanel_ulogs`;
DROP TABLE IF EXISTS `#__chpanel_users`;
DROP TABLE IF EXISTS `#__chpanel_users_apps`;
DROP TABLE IF EXISTS `#__chpanel_users_hotels`;