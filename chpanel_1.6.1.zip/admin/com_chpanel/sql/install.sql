# ************************************************************
# CHPanel - Admin Panel Pro
# Copyright (C) CloudHotelier. All rights reserved.
# ************************************************************



# chpanel_alogs
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_alogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `app_id` int(10) unsigned NOT NULL,
  `log` bigint(20) unsigned NOT NULL,
  `ip` varchar(1024) NOT NULL,
  `task` varchar(100) NOT NULL,
  `ref_table` varchar(100) NOT NULL,
  `ref_id` int(10) unsigned NOT NULL,
  `request` mediumtext NOT NULL,
  `response` mediumtext NOT NULL,
  `errors` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_app_id` (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_apps
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_apps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `data` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_apps_hotels
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_apps_hotels` (
  `app_id` int(10) NOT NULL,
  `hotel_id` int(10) NOT NULL,
  KEY `app_id` (`app_id`),
  KEY `hotel_id` (`hotel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_ari
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_ari` (
  `room_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `units` smallint(6) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  KEY `idx_room_id` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_ari_rates
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_ari_rates` (
  `room_id` int(10) unsigned NOT NULL,
  `rate_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `available` tinyint(1) NOT NULL,
  `minstay` smallint(6) NOT NULL,
  `anticipation` smallint(6) NOT NULL,
  KEY `idx_rate_id` (`rate_id`),
  KEY `idx_room_id` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_bookings
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `confirmed` datetime NOT NULL,
  `cancelled` datetime NOT NULL,
  `voucher` varchar(10) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `nights` tinyint(3) NOT NULL,
  `promo_code` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `currency` char(7) NOT NULL,
  `customer_first_name` varchar(255) NOT NULL,
  `customer_last_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_phone` varchar(255) NOT NULL,
  `customer_country` char(2) NOT NULL,
  `customer_currency` char(7) NOT NULL,
  `customer_newsletter` tinyint(1) NOT NULL,
  `hotel_id` int(10) unsigned NOT NULL,
  `hotel_reference` varchar(255) NOT NULL,
  `rooms` int(2) NOT NULL,
  `rooms_ids` varchar(1024) NOT NULL,
  `rooms_references` varchar(2048) NOT NULL,
  `pay_full` tinyint(1) NOT NULL,
  `confirmation_method` varchar(255) NOT NULL,
  `confirmation_plugin` varchar(255) NOT NULL,
  `amount_board` decimal(10,2) NOT NULL,
  `amount_rate` decimal(10,2) NOT NULL,
  `amount_discount_board` decimal(10,2) NOT NULL,
  `amount_discount_rate` decimal(10,2) NOT NULL,
  `amount_discount` decimal(10,2) NOT NULL,
  `amount_stay` decimal(10,2) NOT NULL,
  `amount_extras` decimal(10,2) NOT NULL,
  `amount_total` decimal(10,2) NOT NULL,
  `deposit_amount` decimal(10,2) NOT NULL,
  `deposit_status` tinyint(1) NOT NULL,
  `app_id` int(10) unsigned NOT NULL,
  `app_ip` varchar(255) NOT NULL,
  `app_user_id` int(10) unsigned NOT NULL,
  `app_user_ip` varchar(1024) NOT NULL,
  `app_user_ip2long` int(10) unsigned NOT NULL,
  `app_user_session_id` varchar(255) NOT NULL,
  `tracking_referer` varchar(1024) NOT NULL,
  `tracking_gclid` varchar(1024) NOT NULL,
  `tracking_aid` varchar(1024) NOT NULL,
  `tracking_said` varchar(1024) NOT NULL,
  `tracking_utm_source` varchar(1024) NOT NULL,
  `tracking_utm_medium` varchar(1024) NOT NULL,
  `tracking_utm_term` varchar(1024) NOT NULL,
  `tracking_utm_content` varchar(1024) NOT NULL,
  `tracking_utm_campaign` varchar(1024) NOT NULL,
  `data` mediumtext NOT NULL,
  `notes` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hotel_id` (`hotel_id`),
  KEY `idx_app_id` (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


# chpanel_bookings_charges
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_bookings_charges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `plugin` varchar(255) NOT NULL,
  `plugin_charge_id` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_booking_id` (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_bookings_discounts
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_bookings_discounts` (
  `booking_id` int(10) NOT NULL,
  `room_unit` int(3) NOT NULL,
  `room_id` int(10) NOT NULL,
  `id` int(10) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `amount_board` decimal(10,2) NOT NULL,
  `amount_rate` decimal(10,2) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  KEY `idx_booking_id` (`booking_id`),
  KEY `idx_room_id` (`room_id`),
  KEY `idx_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_bookings_extras
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_bookings_extras` (
  `booking_id` int(10) NOT NULL,
  `room_unit` int(3) NOT NULL,
  `room_id` int(10) NOT NULL,
  `id` int(10) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `units` int(3) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  KEY `idx_booking_id` (`booking_id`),
  KEY `idx_room_id` (`room_id`),
  KEY `idx_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_bookings_rooms
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_bookings_rooms` (
  `booking_id` int(10) unsigned NOT NULL,
  `room_unit` int(3) NOT NULL,
  `id` int(10) unsigned NOT NULL,
  `reference` varchar(255) NOT NULL DEFAULT '',
  `room_adults` int(3) NOT NULL,
  `room_children` int(3) NOT NULL,
  `room_babies` int(3) NOT NULL,
  `boards_adults` int(3) NOT NULL,
  `boards_children` int(3) NOT NULL,
  `board` char(3) NOT NULL DEFAULT '',
  `rate_id` int(10) unsigned NOT NULL,
  `rate_reference` varchar(255) NOT NULL DEFAULT '',
  `rate_conditions` varchar(255) DEFAULT NULL,
  `amount_board` decimal(10,2) NOT NULL,
  `amount_rate` decimal(10,2) NOT NULL,
  `amount_discount_board` decimal(10,2) NOT NULL,
  `amount_discount_rate` decimal(10,2) NOT NULL,
  `amount_discount` decimal(10,2) NOT NULL,
  `amount_stay` decimal(10,2) NOT NULL,
  `amount_extras` decimal(10,2) NOT NULL,
  `amount_total` decimal(10,2) NOT NULL,
  `deposit_amount` decimal(10,2) NOT NULL,
  KEY `idx_booking_id` (`booking_id`),
  KEY `idx_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_discounts
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_discounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `visible` tinyint(1) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  `ordering` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hotel_id` (`hotel_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_extras
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_extras` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `data` mediumtext NOT NULL,
  `ordering` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hotel_id` (`hotel_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_hotels
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_hotels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `data` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_inventory
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_inventory` (
  `hotel_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  UNIQUE KEY `idx_hotel_id` (`hotel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_packs
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_packs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `data` mediumtext NOT NULL,
  `ordering` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hotel_id` (`hotel_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_photos
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `data` mediumtext NOT NULL,
  `ordering` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hotel_id` (`hotel_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_rates
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_rates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `visible` tinyint(4) NOT NULL,
  `data` mediumtext NOT NULL,
  `ordering` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hotel_id` (`hotel_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_rooms
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_rooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `data` mediumtext NOT NULL,
  `ordering` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hotel_id` (`hotel_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_ulogs
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_ulogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `ip` varchar(1024) NOT NULL,
  `task` varchar(100) NOT NULL,
  `ref_table` varchar(100) NOT NULL,
  `ref_id` int(10) unsigned NOT NULL,
  `raw_post` mediumtext NOT NULL,
  `prev_data` mediumtext NOT NULL,
  `new_data` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_users
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `joomla_id` int(11) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL,
  `type` tinyint(3) NOT NULL,
  `first_name` varchar(1024) NOT NULL,
  `last_name` varchar(1024) NOT NULL,
  `language` char(7) NOT NULL,
  `users_limit` int(255) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  `token` text NOT NULL,
  `suspended` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `checked_out` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_joomla_id` (`joomla_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_checked_out` (`checked_out`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_users_apps
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_users_apps` (
  `user_id` int(10) unsigned NOT NULL,
  `app_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;



# chpanel_users_hotels
# ------------------------------------------------------------

CREATE TABLE `#__chpanel_users_hotels` (
  `user_id` int(10) unsigned NOT NULL,
  `hotel_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`hotel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


# auto_increment
# ------------------------------------------------------------

ALTER TABLE `#__chpanel_apps` auto_increment = 100001;
ALTER TABLE `#__chpanel_bookings` auto_increment = 100001;
ALTER TABLE `#__chpanel_bookings_charges` auto_increment = 100001;
ALTER TABLE `#__chpanel_discounts` auto_increment = 100001;
ALTER TABLE `#__chpanel_extras` auto_increment = 100001;
ALTER TABLE `#__chpanel_hotels` auto_increment = 100001;
ALTER TABLE `#__chpanel_packs` auto_increment = 100001;
ALTER TABLE `#__chpanel_photos` auto_increment = 100001;
ALTER TABLE `#__chpanel_rates` auto_increment = 100001;
ALTER TABLE `#__chpanel_rooms` auto_increment = 100001;
ALTER TABLE `#__chpanel_users` auto_increment = 100001;