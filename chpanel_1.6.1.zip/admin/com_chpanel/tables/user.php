<?php
/**
 * @package		CHAdminPro
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

/**
 * User Table
 */
class CHPanelTableUser extends JTable
{

	/**
	 * Constructor
	 */
	function __construct(&$db)
	{
		parent::__construct('#__chpanel_users', 'id', $db);
	}

	/**
	 * Store data
	 */
	public function store($updateNulls = false)
	{

		$date = JFactory::getDate();
		$user = JFactory::getUser();

		if (!$this->id)
		{
			$this->created = $date->toSql();
			$this->created_by = $user->get('id');
		}

		return parent::store($updateNulls);
	}

	/**
	 * Publish method (yeah this is sad but we are on J!3)
	 */
	public function publish($pks = null, $state = 1, $userId = 0)
	{

		$k = $this->_tbl_key;

		// sanitize input
		JArrayHelper::toInteger($pks);
		$userId = (int) $userId;
		$state = (int) $state;

		// if there are no primary keys set check if the instance key is set already
		if (empty($pks))
		{
			if ($this->$k)
			{
				$pks = array($this->$k);
			}
			else
			{
				$this->setError(JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
				return false;
			}
		}

		// get table instance
		$table = JTable::getInstance('User', 'CHPanelTable');

		foreach ($pks as $pk)
		{

			// Load the item
			if (!$table->load($pk))
			{
				$this->setError($table->getError());
			}

			// verify checkout
			if ($table->checked_out == 0 || $table->checked_out == $userId)
			{

				// change the state
				$table->state = $state;
				$table->checked_out = 0;
				$table->checked_out_time = $this->_db->getNullDate();

				// check the row
				$table->check();

				// store the row
				if (!$table->store())
				{
					$this->setError($table->getError());
				}
			}
		}

		return count($this->getErrors()) == 0;
	}

}
