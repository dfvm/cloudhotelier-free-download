<?php
/**
 * @package		CHMailgun
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

// import jplugin
jimport('joomla.plugin.plugin');

/**
 * CloudHotelier Mailgun
 */
class plgSystemCHMailgun extends JPlugin
{

	/**
	 * onNotify example
	 * 
	 * @param type $booking
	 */
	public function onCHLibSendEmail($emails, $subject, $html, $options = false)
	{
		// load config
		$config = JFactory::getConfig();

		// load params
		$domain = $this->params->get('domain');
		$api_key = $this->params->get('api_key');
		if (!$domain || !$api_key)
		{
			return false;
		}

		// init data
		$data = [
			'to' => $emails,
			'subject' => $subject,
			'html' => $html
		];

		// mailgun recipient variables for batch sending
		// send a separated message to each recipient with a single API Call
		if (is_array($emails))
		{
			$recipient_variables = [];
			foreach ($emails as $email)
			{
				$recipient_variables[$email] = (object) [];
			}
			$data['recipient-variables'] = json_encode($recipient_variables);
		}

		// from
		$from = isset($options->from) ? $options->from : $config->get('mailfrom');

		// from name
		$from_name = isset($options->from_name) ? $options->from_name : $config->get('fromname', $config->get('sitename'));

		// set from
		$data['from'] = "$from_name <$from>";

		// cc
		if (isset($options->cc))
		{
			$data['cc'] = $options->cc;
		}

		// blind cc
		if (isset($options->bcc))
		{
			$data['bcc'] = $options->bcc;
		}

		// reply header
		if (isset($options->reply))
		{
			$data['h:Reply-To'] = is_array($options->reply) ? "{$options->reply[1]} <{$options->reply[0]}>" : $options->reply;
		}

		// api call
		$headers = ['Authorization' => 'Basic ' . base64_encode('api:' . $api_key)];
		$url = "https://api.mailgun.net/v3/$domain/messages";
		$result = JHttpFactory::getHttp()->post($url, $data, $headers);
		if (!isset($result->code) || $result->code != 200)
		{
			CHLib::log(json_encode(['plgSystemCHMailgun - api send fail', $url, $data, $result], JSON_PRETTY_PRINT), 'warning', 'plg_chmailgun');
			return false;
		}

		return true;
	}

}
