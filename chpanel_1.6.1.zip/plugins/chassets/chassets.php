<?php
/**
 * @package		CHAssets
 * @copyright	Copyright (C) CloudHotelier. All rights reserved.
 * @license		GNU GPLv2 <http://www.gnu.org/licenses/gpl.html>
 * @author		Xavier Pallicer <xpallicer@cloudhotelier.com>
 */
defined('_JEXEC') or die();

// import jplugin
jimport('joomla.plugin.plugin');

/**
 * CloudHotelier Assets Plugin
 */
class plgSystemCHAssets extends JPlugin
{

	/**
	 * Load Uikit, CH extensions assets, and CH theme assets if needed
	 */
	public function onBeforeCompileHead()
	{
		// load app
		$app = JFactory::getApplication();

		// front-end only
		if ($app->isAdmin())
		{
			return;
		}

		// check chassets
		if (!isset($app->chassets))
		{
			return;
		}

		// load uikit assets
		$this->loadUikit();

		// check for CH template
		$chtheme = isset($app->chassets->tpl_options);

		// no CH theme: load extensions assets and return 
		if (!$chtheme)
		{
			return $this->loadCHAssets(false);
		}

		// theme assets
		$tpl_options = $app->chassets->tpl_options;
		$tpl_url = "templates/$tpl_options->template";
		$tpl_path = JPATH_ROOT . "/templates/$tpl_options->template";

		// prepare arrays
		$this->theme_styles = [];
		$this->theme_scripts = [];

		// add theme uikit css
		foreach ($this->uikit_styles as $i => $asset)
		{
			$style = !$i ? $asset->style : 'uikit-' . $asset->style;
			$this->theme_styles[] = (object) ['asset' => $asset->uikit_item, 'url' => "$tpl_url/assets/theme/css/$style"];
		}

		// add theme main css & script
		$this->theme_styles[] = (object) ['asset' => 'theme', 'url' => "$tpl_url/assets/theme/css/theme.min.css"];
		$this->theme_scripts[] = (object) ['asset' => 'theme', 'url' => "$tpl_url/assets/theme/js/theme.min.js"];

		// check theme style overrides
		$theme_style_path = "$tpl_path/styles/$tpl_options->style";
		$theme_style_url = "$tpl_url/styles/$tpl_options->style";
		foreach ($this->theme_styles as $asset)
		{
			$override = false;

			// uikit core & theme css
			if (in_array($asset->asset, ['uikit', 'theme']))
			{
				$override = file_exists("$theme_style_path/css/$asset->asset.min.css");
				$asset_url = "$theme_style_url/css/$asset->asset.min.css";
			}

			// uikit components
			if (!in_array($asset->asset, ['uikit', 'theme']))
			{
				$override = file_exists("$theme_style_path/css/uikit-components/$asset->asset.min.css");
				$asset_url = "$theme_style_url/css/uikit-components/$asset->asset.min.css";
			}

			if ($override)
			{
				$asset->url = $asset_url;
			}
		}

		// add custom css
		if ($tpl_options->custom)
		{
			if (file_exists("$theme_style_path/css/custom.min.css"))
			{
				$this->theme_styles[] = (object) ['asset' => 'custom', 'url' => "$theme_style_url/css/custom.min.css"];
			}
			elseif (file_exists("$theme_style_path/css/custom.css"))
			{
				$this->theme_styles[] = (object) ['asset' => 'custom', 'url' => "$theme_style_url/css/custom.css"];
			}
		}

		// check for theme style js overrides
		foreach ($this->theme_scripts as $asset)
		{
			if (file_exists("$theme_style_path/js/$asset->asset.min.js"))
			{
				$asset->url = "$theme_style_url/js/$asset->asset.min.js";
			}
		}

		return $this->loadCHAssets(true);
	}

	/**
	 * Add the assets to Joomla head the classic style
	 * 
	 * @param bool $chtheme
	 * 
	 * @return boolean
	 */
	private function loadCHAssets($chtheme)
	{
		// load chassets
		$chassets = CHAssets::getApp()->chassets;

		/*
		 * Styles
		 */

		// no CH theme: add uikit and extensions from media folder
		if (!$chtheme)
		{
			foreach (array_merge($this->uikit_styles, $chassets->styles) as $item)
			{
				$item->media ? JHtml::stylesheet("$item->media/$item->style", false, true, false) : JHtml::stylesheet($item->style);
			}
		}

		// CH theme: add uikit from template, and extensions from media folder
		if ($chtheme)
		{
			foreach ($this->theme_styles as $asset)
			{
				JHtml::stylesheet($asset->url);
			}
			foreach ($chassets->styles as $item)
			{
				$item->media ? JHtml::stylesheet("$item->media/$item->style", false, true, false) : JHtml::stylesheet($item->style);
			}
		}

		/*
		 * Scripts
		 */

		// always load jquery
		JHtml::_('jquery.framework', false);

		// first add uikit and extensions JS from media folder
		$scripts = array_merge($this->uikit_scripts, $chassets->scripts);
		foreach ($scripts as $item)
		{
			$item->media ? JHtml::script("$item->media/$item->script", false, true) : JHtml::script($item->script);
		}

		// add theme js last
		if ($chtheme)
		{
			foreach ($this->theme_scripts as $asset)
			{
				JHtml::script($asset->url);
			}
		}

		/*
		 * Inline styles and scripts
		 */

		// add style declarations
		if ($chassets->style_declarations)
		{
			JFactory::getDocument()->addStyleDeclaration("\n        " . implode("\n        ", $chassets->style_declarations));
		}

		// add script declarations
		if ($chassets->script_declarations)
		{
			JFactory::getDocument()->addScriptDeclaration("\n        " . implode("\n        ", $chassets->script_declarations));
		}

		return true;
	}

	/**
	 * Load uikit components css and js files
	 */
	private function loadUikit()
	{
		// init uikit styles and scripts
		$this->uikit_styles = [(object) ['media' => 'chassets', 'uikit_item' => 'uikit', 'style' => 'uikit.min.css']];
		$this->uikit_scripts = [(object) ['media' => 'chassets', 'uikit_item' => 'uikit', 'script' => 'uikit.min.js']];

		// check components
		$chassets = CHAssets::getApp()->chassets;
		if (!$chassets->uikit_components)
		{
			return;
		}

		// prepare assets loading
		array_unique($chassets->uikit_components);
		$uikit_css = $this->uikitComponentsCss();
		$uikit_js = $this->uikitComponentsJs();

		// load components assets
		foreach ($chassets->uikit_components as $component)
		{
			if (in_array($component, $uikit_css))
			{
				$this->uikit_styles[] = (object) ['media' => 'chassets', 'uikit_item' => $component, 'style' => "components/$component.min.css"];
			}
			if (in_array($component, $uikit_js))
			{
				$this->uikit_scripts[] = (object) ['media' => 'chassets', 'uikit_item' => $component, 'script' => "components/$component.min.js"];
			}
		}
	}

	/**
	 * Uikit css components
	 */
	private function uikitComponentsCss()
	{
		return [
			'accordion',
			'autocomplete',
			'datepicker',
			'dotnav',
			'form-advanced',
			'form-file',
			'form-password',
			'form-select',
			'htmleditor',
			'nestable',
			'notify',
			'placeholder',
			'progress',
			'search',
			'slidenav',
			'slider',
			'slideshow',
			'sortable',
			'sticky',
			'tooltip',
			'upload',
		];
	}

	/**
	 * Uikit js components
	 */
	private function uikitComponentsJs()
	{
		return [
			'accordion',
			'autocomplete',
			'datepicker',
			'form-password',
			'form-select',
			'grid',
			//'htmleditor',
			'lightbox',
			'nestable',
			'notify',
			'pagination',
			'parallax',
			'search',
			'slider',
			'slideset',
			'slideshow-fx',
			'slideshow',
			'sortable',
			'sticky',
			'timepicker',
			'tooltip',
			'upload',
		];
	}

}
